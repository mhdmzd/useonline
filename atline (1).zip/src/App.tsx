import React, { useState, useEffect } from 'react';
import { DeviceFrame } from './components/DeviceFrame';
import { CodeExplorer } from './components/CodeExplorer';
import { ArchitectureDiagram } from './components/ArchitectureDiagram';
import { AuthFlow } from './components/screens/AuthFlow';
import { HomeTab } from './components/screens/HomeTab';
import { CategoriesTab } from './components/screens/CategoriesTab';
import { CartTab } from './components/screens/CartTab';
import { ProfileTab } from './components/screens/ProfileTab';
import { PaymentHub } from './components/screens/PaymentHub';
import { Product, Category, CartItem, Order, NotificationItem, ArchLog, VendorShop, UserAddress } from './types';
import { mockNotifications, mockProducts, mockCategories } from './data/mockProducts';
import { ShieldAlert, BookOpen, Smartphone, Activity, Download, Heart, ShoppingBag, ShoppingCart, FolderGit, Sparkles, MessageSquare, AlertTriangle, X } from 'lucide-react';
import { VendorConsole } from './components/screens/VendorConsole';
import { AdminConsole, AdminReport } from './components/screens/AdminConsole';
import { ReleaseConsole } from './components/screens/ReleaseConsole';
import { AiEngineConsole } from './components/screens/AiEngineConsole';
import { Brain } from 'lucide-react';

export default function App() {
  // 1. Core Emulator States
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userName, setUserName] = useState('');
  const [userPhone, setUserPhone] = useState('09123456789');
  const [userEmail, setUserEmail] = useState('info@useonline.shop');
  const [addresses, setAddresses] = useState<UserAddress[]>([
    {
      id: 'addr_1',
      title: 'محل کار (دفتر تهران)',
      receiverName: 'کاربر یوزآنلاین',
      phoneNumber: '09123456789',
      zipCode: '1911953211',
      province: 'تهران',
      city: 'تهران',
      details: 'اتوبان صدر، خیابان قیطریه، کوچه احمدی، پلاک ۱۲، زنگ سوم'
    }
  ]);
  const [activeAddressId, setActiveAddressId] = useState('addr_1');

  const [activeTab, setActiveTab] = useState(0); // 0: Home, 1: Category, 2: Cart, 3: Wishlist, 4: Profile
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [favorites, setFavorites] = useState<string[]>(['p1', 'p3']); // Seed some initial favorites
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // 1.1 Vendor / Merchant States
  const [vendorMode, setVendorMode] = useState(false);
  const [products, setProducts] = useState<Product[]>(mockProducts);
  const [categories, setCategories] = useState<Category[]>(mockCategories);
  const [rightSideView, setRightSideView] = useState<'CODE' | 'ADMIN' | 'RELEASE' | 'AI_ENGINE'>('AI_ENGINE');
  const [shop, setShop] = useState<VendorShop | null>(null);

  // Reports & Feedback list
  const [reports, setReports] = useState<AdminReport[]>([
    { id: 'rep_1', title: 'تاخیر در ارسال تبلت شیائومی', reporterName: 'کاوه مهرآیین', targetType: 'VENDOR', targetName: 'گالری شیک‌‌پوش', description: 'سفارش ثبت شده من پس از ۴ روز هنوز ارسال نشده و غرفه‌دار پاسخگو نیست.', severity: 'HIGH', date: '۱۴۰۵/۰۳/۱۵', status: 'PENDING' },
    { id: 'rep_2', title: 'اشتباه بودن فرکانس تراشه پردازنده', reporterName: 'زهرا محمدی', targetType: 'PRODUCT', targetName: 'iPhone 15 Pro Max', description: 'توضیحات فیلد پردازنده ثبت شده فرکانس ۳.۲ گیگاهرتز دارد در صورتیکه نسخه اصلی ۳.۴۶ گیگاهرتز است.', severity: 'LOW', date: '۱۴۰۵/۰۳/۱۰', status: 'RESOLVED' },
    { id: 'rep_3', title: 'شکایت از عدم تطابق تصویر عطر با کالا', reporterName: 'وحید ناصری', targetType: 'PRODUCT', targetName: 'ادو پرفیوم مردانه بلو د شنل', description: 'تصویر شیشه ۱۰۰ میل است اما عطر ارسالی ۵۰ میل است. تقاضای خسارت دارم.', severity: 'MEDIUM', date: '۱۴۰۵/۰۳/۰۴', status: 'PENDING' },
    { id: 'rep_4', title: 'نامناسب بودن لحن پشتیبان در بخش پیام', reporterName: 'گلناز راد', targetType: 'USER', targetName: 'پشتیبانی فنی', description: 'پشتیبان شماره دو رفتاری عصبانی و لحنی غیرحرفه‌ای داشت.', severity: 'LOW', status: 'DISMISSED', date: 'یک هفته پیش' }
  ]);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);
  
  // 2. Alert Shade lists
  const [showNotificationShade, setShowNotificationShade] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>(mockNotifications);
  
  // 3. User Order histories
  const [orders, setOrders] = useState<Order[]>([
    {
      id: 'AT-8321',
      date: '۲ روز پیش',
      status: 'SHIPPED',
      itemsCount: 3,
      totalPrice: 420000,
      trackingNumber: '390198754125'
    },
    {
      id: 'AT-1940',
      date: '۵ روز پیش',
      status: 'DELIVERED',
      itemsCount: 1,
      totalPrice: 185000,
      trackingNumber: '390145214782'
    }
  ]);

  // 3.1 Advanced Payment States
  const [activePaymentSession, setActivePaymentSession] = useState<{
    amount: number;
    orderId: string;
    discountPercent: number;
    cartSnapshot: CartItem[];
  } | null>(null);

  const [showTransactionsHistory, setShowTransactionsHistory] = useState(false);

  const handleUpdateOrderStatus = (orderId: string, nextStatus: Order['status']) => {
    setOrders((prev) =>
      prev.map((o) => (o.id === orderId ? { ...o, status: nextStatus } : o))
    );
  };

  // 4. Trace Log State Management
  const [logs, setLogs] = useState<ArchLog[]>([]);

  // Helper: Append a new synchronized clean architecture trace log
  const addLog = (layer: ArchLog['layer'], message: string, details = '') => {
    const timestamp = new Date().toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }) + '.' + String(new Date().getMilliseconds()).padStart(3, '0');

    const newLog: ArchLog = {
      id: Math.random().toString(),
      timestamp,
      layer,
      message,
      details
    };
    setLogs((prev) => [...prev, newLog]);
  };

  // Setup initial build system log triggers on applet mount
  useEffect(() => {
    // Seed standard traces describing Android compilation
    addLog('DATASOURCE', 'همگام‌سازی دیتابیس محلی اتاق (Room SQLite Database)');
    addLog('REPOSITORY', 'راه‌اندازی پایگاه کپی محلی با موفقیت', 'Local sources active');
    addLog('USECASE', 'تزریق وابستگی‌های گیت Hilt Injection با موفقیت به پایان رسید');
    addLog('VIEWMODEL', 'بارگذاری اکتیوشوهای AuthViewModel و HomeViewModel', 'ViewModels initialized');
    addLog('UI', 'بارگذاری موفق قالب متغیر Material Design 3 و قلم فارسی وزیرمتن');
  }, []);

  const handleAuthSuccess = (name: string) => {
    setUserName(name);
    setIsLoggedIn(true);
    setActiveTab(0);
    addLog('UI', 'سیستم تغییر یافت به حالت ورود معتبر', `داشبورد کاربر: ${name}`);
  };

  const handleLogout = () => {
    setUserName('');
    setIsLoggedIn(false);
    setCartItems([]);
    setOrders([]);
    setActiveTab(0);
    addLog('UI', 'کاربر خارج شد - پاکسازی حافظه سشن هیلت');
  };

  const handleAddCategory = (newCat: Category) => {
    setCategories((prev) => [...prev, newCat]);
  };

  const handleEditCategory = (updatedCat: Category) => {
    setCategories((prev) => prev.map((c) => c.id === updatedCat.id ? updatedCat : c));
  };

  const handleDeleteCategory = (catId: string) => {
    setCategories((prev) => prev.filter((c) => c.id !== catId));
  };

  // Cart operations
  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        addLog('DATASOURCE', 'به‌روزرسانی تعداد محصول در جدول سبدخرید (SQLite)', `productId=${product.id}, quantity=${existing.quantity + 1}`);
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      addLog('DATASOURCE', 'افزودن رکورد جدید به سبدخرید دیتابیس محلی', `productId=${product.id}`);
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCartItems((prev) => {
      const item = prev.find((i) => i.product.id === productId);
      if (!item) return prev;
      
      const newQty = item.quantity + delta;
      if (newQty <= 0) {
        addLog('DATASOURCE', 'حذف رکورد کالا از سبدخرید دیتابیس', `productId=${productId}`);
        return prev.filter((i) => i.product.id !== productId);
      }
      
      addLog('DATASOURCE', 'تغییر تعداد کالا در دیتابیس محلی', `productId=${productId}, New Qty: ${newQty}`);
      return prev.map((i) =>
        i.product.id === productId ? { ...i, quantity: newQty } : i
      );
    });
  };

  const handleClearCart = () => {
    setCartItems([]);
    addLog('DATASOURCE', 'تخلیه کامل جدول سبدخرید (TRUNCATE table_cart)');
  };

  const handleCheckout = (discountPercent: number) => {
    const trackingAndId = Math.floor(100000 + Math.random() * 900000).toString();
    const rawSubtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
    const discountAmount = Math.round((rawSubtotal * discountPercent) / 100);
    const shippingFee = rawSubtotal > 15000000 ? 0 : 49000;
    const finalAmount = rawSubtotal - discountAmount + shippingFee;
    const mockOrderId = `UO-${trackingAndId.substring(0, 4)}`;

    addLog('VIEWMODEL', 'تولید پیش‌نشست شارژ فاکتور یوزآنلاین و ارجاع به درگاه هوشمند شتاب', `سفارش موقت: ${mockOrderId}`);

    setActivePaymentSession({
      amount: finalAmount,
      orderId: mockOrderId,
      discountPercent,
      cartSnapshot: [...cartItems]
    });
  };

  const handlePaymentSuccess = (transaction: any) => {
    if (!activePaymentSession) return;

    const trackingAndId = Math.floor(100000 + Math.random() * 900000).toString();
    const newOrder: Order = {
      id: activePaymentSession.orderId,
      date: 'امروز، ' + new Date().toLocaleDateString('fa-IR'),
      status: 'PREPARING',
      itemsCount: activePaymentSession.cartSnapshot.reduce((acc, item) => acc + item.quantity, 0),
      totalPrice: activePaymentSession.amount,
      trackingNumber: `3901${trackingAndId}`
    };

    setOrders((prev) => [newOrder, ...prev]);
    setCartItems([]);
    
    // Add custom dispatch alert notification in android drawer
    const newNotif: NotificationItem = {
      id: Math.random().toString(),
      title: 'تسویه سفارش موفقیت‌آمیز بود 🎉',
      body: `سفارش ${newOrder.id} به مبلغ ${newOrder.totalPrice.toLocaleString()} تومان با موفقیت پرداخت و تایید شد. کد پیگیری شتاب: ${transaction.refId || 'مستقیم'}`,
      time: 'هم‌اکنون',
      type: 'ORDER',
      isRead: false
    };

    setNotifications((prev) => [newNotif, ...prev]);

    addLog('DATASOURCE', 'کامیت سفارش بازارچه نهایی در انبار ابری سرور (COMMIT Order SQL)', `شناسه سفارش: ${newOrder.id}`);
    
    setActivePaymentSession(null);
    setActiveTab(4); // Navigate to Profile Tab to view status
  };

  const handlePaymentCancel = () => {
    addLog('UI', 'انصراف کاربر از پرداخت و بازگشت به سبد خرید بدون ریزش کالا', 'نشست تراکنش باطل شد');
    setActivePaymentSession(null);
    setShowTransactionsHistory(false);
  };

  // Favorites (Wishlist) toggle
  const handleToggleFavorite = (product: Product) => {
    setFavorites((prev) => {
      const exists = prev.includes(product.id);
      if (exists) {
        addLog('DATASOURCE', 'حذف محصول از جدول علاقه‌مندی‌ها (Favorites SQL Table)', `productId=${product.id}`);
        return prev.filter((id) => id !== product.id);
      }
      addLog('DATASOURCE', 'ثبت محصول در جدول علاقه‌مندی‌ها', `productId=${product.id}`);
      return [...prev, product.id];
    });
  };

  // Notifications clear
  const handleClearNotification = (id: string) => {
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  const handleClearAllNotifications = () => {
    setNotifications([]);
  };

  const handleAddNotification = (notif: NotificationItem) => {
    setNotifications((prev) => [notif, ...prev]);
  };

  const handleResolveReport = (reportId: string, action: 'RESOLVED' | 'DISMISSED') => {
    setReports((prev) =>
      prev.map((rep) => {
        if (rep.id === reportId) {
          addLog('USECASE', 'بروزرسانی تیکت شکایتی رول پشتیبانی ادمین', `شناسه شکایت: ${reportId}, وضعیت جدید: ${action}`);
          
          setNotifications((notifs) => [
            {
              id: Math.random().toString(),
              title: `پاسخگویی به گزارشات ادمین 📨`,
              body: `گزارش ثبت شده شما با عنوان "${rep.title}" پس از بررسی ادمین به وضعیت "${action === 'RESOLVED' ? 'رفع شد' : 'بایگانی‌شده'}" درآمد.`,
              time: 'هم‌اکنون',
              type: 'SYSTEM',
              isRead: false
            } as NotificationItem,
            ...notifs
          ]);

          return { ...rep, status: action };
        }
        return rep;
      })
    );
  };

  // Numeric converters for Persian typography formatting
  const toPersianDigits = (num: number | string) => {
    const id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/[0-9]/g, (w) => id[+w]);
  };

  const formatPrice = (price: number) => {
    const formatted = price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return toPersianDigits(formatted);
  };

  const FeedbackModal = () => {
    const [title, setTitle] = useState('');
    const [targetType, setTargetType] = useState<'PRODUCT' | 'VENDOR' | 'USER'>('USER');
    const [targetName, setTargetName] = useState('');
    const [description, setDescription] = useState('');
    const [severity, setSeverity] = useState<'LOW' | 'MEDIUM' | 'HIGH'>('MEDIUM');
    const [reporter, setReporter] = useState(userName || 'کاربر مهمان');

    const handleSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      if (!title.trim() || !description.trim()) return;

      const newReport: AdminReport = {
        id: `rep_${Math.floor(100 + Math.random() * 900)}`,
        title: title.trim(),
        reporterName: reporter.trim(),
        targetType,
        targetName: targetName.trim() || (targetType === 'USER' ? 'سیستم عمومی' : 'نامشخص'),
        description: description.trim(),
        severity,
        date: 'امروز، ' + new Date().toLocaleDateString('fa-IR'),
        status: 'PENDING'
      };

      setReports((prev) => [newReport, ...prev]);
      addLog('UI', 'ثبت بازخورد جدید توسط کاربر از شبیه‌ساز', `موضوع: ${title.trim()} | شدت: ${severity}`);
      
      setNotifications((prev) => [
        {
          id: Math.random().toString(),
          title: '📬 بازخورد شما دریافت شد',
          body: `موضوع "${title.trim()}" برای بررسی تیم مدیریت بازارچه یوزآنلاین به پنل ادمین ارسال گردید. تشکر از شما!`,
          time: 'هم‌اکنون',
          type: 'SYSTEM',
          isRead: false
        } as NotificationItem,
        ...prev
      ]);

      setIsFeedbackModalOpen(false);
    };

    return (
      <div className="fixed inset-0 bg-[#0d0f12]/85 backdrop-blur-sm z-[100] flex items-center justify-center p-4 font-vazir text-right" dir="rtl" id="feedback-modal-overlay">
        <div className="bg-[#12161a] border border-[#212831] rounded-3xl w-full max-w-md overflow-hidden shadow-2xl p-6 flex flex-col gap-4 relative">
          
          <button 
            type="button"
            onClick={() => setIsFeedbackModalOpen(false)}
            className="absolute left-4 top-4 hover:bg-white/10 p-1.5 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
            id="close-feedback-btn"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 pb-3 border-b border-[#212831]">
            <div className="w-8 h-8 rounded-lg bg-pink-500/15 flex items-center justify-center text-pink-500">
              <MessageSquare className="w-4.5 h-4.5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">ثبت گزارش خطا و بازخورد توسعه‌دهنده</h3>
              <p className="text-[10px] text-slate-400 mt-0.5">این بازخوردها مستقیماً به کنسول مدیریت ادمین ارسال می‌شوند.</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-3 text-xs">
            {/* Subject */}
            <div className="flex flex-col gap-1">
              <label className="text-slate-400 font-bold text-[10px]">موضوع گزارش / پیشنهاد *</label>
              <input
                type="text"
                required
                placeholder="مثال: مشکل لودینگ تصاویر، کندی سبد خرید"
                value={title}
                onChange={e => setTitle(e.target.value)}
                className="bg-[#171c22] border border-[#212831] px-3 py-2 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-pink-500 font-medium"
              />
            </div>

            {/* Reporter Name */}
            <div className="flex flex-col gap-1">
              <label className="text-slate-400 font-bold text-[10px]">نام شما (گزارش‌دهنده)</label>
              <input
                type="text"
                placeholder="نام کامل خود را وارد کنید"
                value={reporter}
                onChange={e => setReporter(e.target.value)}
                className="bg-[#171c22] border border-[#212831] px-3 py-2 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-pink-500 font-medium"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              {/* Target Type */}
              <div className="flex flex-col gap-1">
                <label className="text-slate-400 font-bold text-[10px]">نوع گزارش</label>
                <select
                  value={targetType}
                  onChange={e => setTargetType(e.target.value as any)}
                  className="bg-[#171c22] border border-[#212831] px-3 py-2 rounded-xl text-slate-100 focus:outline-none focus:ring-1 focus:ring-pink-500 font-bold cursor-pointer"
                >
                  <option value="USER">پیشنهاد / خطا عمومی</option>
                  <option value="PRODUCT">خطای مرتبط با کالا</option>
                  <option value="VENDOR">گزارش درباره غرفه‌دار</option>
                </select>
              </div>

              {/* Target Subject Name */}
              <div className="flex flex-col gap-1">
                <label className="text-slate-400 font-bold text-[10px]">نام هدف (جزء مربوطه)</label>
                <input
                  type="text"
                  placeholder="مثال: آیفون ۱۵، غرفه دیجیتال"
                  value={targetName}
                  onChange={e => setTargetName(e.target.value)}
                  className="bg-[#171c22] border border-[#212831] px-3 py-2 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-pink-500 font-medium"
                />
              </div>
            </div>

            {/* Severity selection */}
            <div className="flex flex-col gap-1">
              <label className="text-slate-400 font-bold text-[10px]">سطح بحرانی بودن (اهمیت)</label>
              <div className="grid grid-cols-3 gap-2 mt-0.5">
                {[
                  { value: 'LOW', label: 'کم (Low)', color: 'border-emerald-500/30 text-emerald-400 bg-emerald-500/5 hover:bg-emerald-500/10' },
                  { value: 'MEDIUM', label: 'متوسط (Medium)', color: 'border-amber-500/30 text-amber-400 bg-amber-500/5 hover:bg-amber-500/10' },
                  { value: 'HIGH', label: 'بالا (High)', color: 'border-rose-500/30 text-rose-400 bg-rose-500/5 hover:bg-rose-500/10' }
                ].map((item) => (
                  <button
                    key={item.value}
                    type="button"
                    onClick={() => setSeverity(item.value as any)}
                    className={`border px-2.5 py-1.5 rounded-xl font-bold transition flex items-center justify-center cursor-pointer ${
                      severity === item.value 
                        ? item.value === 'LOW' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500 shadow-md'
                          : item.value === 'MEDIUM' ? 'bg-amber-500/20 text-amber-300 border-amber-500 shadow-md'
                          : 'bg-rose-500/20 text-rose-300 border-rose-500 shadow-md animate-pulse'
                        : 'border-[#212831] bg-[#171c22]/50 text-slate-400'
                    }`}
                  >
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Description Area */}
            <div className="flex flex-col gap-1">
              <label className="text-slate-400 font-bold text-[10px]">شرح کامل مشکل یا پیشنهاد *</label>
              <textarea
                required
                rows={3}
                placeholder="توضیحات و رخداد خطا را گزارش کنید..."
                value={description}
                onChange={e => setDescription(e.target.value)}
                className="bg-[#171c22] border border-[#212831] p-3 rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-pink-500 font-medium leading-relaxed resize-none"
              />
            </div>

            {/* Buttons row */}
            <div className="flex items-center gap-2 mt-2 pt-2 border-t border-white/5">
              <button
                type="submit"
                className="flex-1 bg-gradient-to-r from-pink-600 to-indigo-600 hover:from-pink-700 hover:to-indigo-700 text-white font-black py-2.5 rounded-xl cursor-pointer active:scale-95 transition flex items-center justify-center gap-1.5 shadow-md shadow-pink-500/10"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>ثبت نهایی و ارسال به ادمین</span>
              </button>
              <button
                type="button"
                onClick={() => setIsFeedbackModalOpen(false)}
                className="px-4 py-2.5 rounded-xl text-slate-400 hover:text-white bg-[#171c22] border border-[#212831] font-bold transition hover:bg-slate-800 cursor-pointer"
              >
                انصراف
              </button>
            </div>
          </form>

        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-[#0d0f12] text-slate-100 flex flex-col font-vazir text-right selection:bg-blue-600 selection:text-white" dir="rtl" id="applet-dashboard">
      
      {/* Upper Global Navigation */}
      <header className="bg-[#12161a] border-b border-[#1b2228] px-6 py-4 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-tr from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-md shadow-blue-500/20">
            ی
          </div>
          <div>
            <h1 className="text-base font-black text-white flex items-center gap-1.5">
              بازارچه چندفروشگاهی یوزآنلاین (UseOnline Shop)
              <span className="bg-blue-600/10 text-blue-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-blue-500/20">
                پروژه کاتلین و جت‌پک کامپوز
              </span>
            </h1>
            <p className="text-[11px] text-slate-400 mt-0.5">شبیه‌ساز پیشرفته اندروید، کد بیس تمیز و ردیاب معماری MVVM</p>
          </div>
        </div>

        {/* Developer Action Buttons */}
        <div className="flex items-center gap-2 text-xs flex-wrap md:flex-nowrap">
          <div className="bg-[#1c222c] p-1 rounded-xl border border-white/5 flex gap-1">
            <button
              onClick={() => {
                setRightSideView('AI_ENGINE');
                addLog('UI', 'تغییر نمای کنسول توسعه‌دهنده به: موتور هوش مصنوعی یوزآنلاین');
              }}
              className={`font-bold px-3 py-1.5 rounded-lg transition active:scale-95 flex items-center gap-1 cursor-pointer ${
                rightSideView === 'AI_ENGINE'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Brain className="w-3.5 h-3.5 animate-pulse" />
              <span>🧠 موتور هوش مصنوعی (AICE)</span>
            </button>

            <button
              onClick={() => {
                setRightSideView('CODE');
                addLog('UI', 'تغییر نمای کنسول توسعه‌دهنده به: سورس کدهای کاتلین');
              }}
              className={`font-bold px-3 py-1.5 rounded-lg transition active:scale-95 flex items-center gap-1 cursor-pointer ${
                rightSideView === 'CODE'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Activity className="w-3.5 h-3.5" />
              <span>💻 سورس کاتلین</span>
            </button>

            <button
              onClick={() => {
                setRightSideView('ADMIN');
                addLog('UI', 'تغییر نمای کنسول توسعه‌دهنده به: پنل ادمین بازارچه');
              }}
              className={`font-bold px-3 py-1.5 rounded-lg transition active:scale-95 flex items-center gap-1 cursor-pointer ${
                rightSideView === 'ADMIN'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>📊 پنل ادمین بازارچه</span>
            </button>

            <button
              onClick={() => {
                setRightSideView('RELEASE');
                addLog('UI', 'تغییر نمای کنسول توسعه‌دهنده به: مرکز انتشار و کارایی رلیز بازار');
              }}
              className={`font-bold px-3 py-1.5 rounded-lg transition active:scale-95 flex items-center gap-1.5 cursor-pointer ${
                rightSideView === 'RELEASE'
                  ? 'bg-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span className="flex items-center gap-1">
                🚀 کارایی و سند رلیز
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              </span>
            </button>
          </div>

          {!isLoggedIn && (
            <button
              onClick={() => handleAuthSuccess('کاوه مهرآیین')}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-4 py-2 rounded-xl transition border border-slate-700/50 active:scale-95"
            >
              🚀 دور زدن ورود (تست سریع)
            </button>
          )}

          {/* New Global Header Shopping Cart Button */}
          <button
            onClick={() => {
              if (!isLoggedIn) {
                addLog('UI', 'تلاش برای بازکردن سبد خرید - لطفا ابتدا وارد شوید', 'رویداد رد شد');
                return;
              }
              addLog('UI', 'ناوبری هدایت مستقیم کاربر به سبد خرید از هدر سراسری وب‌سایت', 'تغییر تب فعال به تب خرید');
              setActiveTab(2);
              setVendorMode(false);
            }}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2.5 rounded-xl transition shadow-md shadow-blue-500/10 hover:shadow-lg flex items-center gap-2 active:scale-95 cursor-pointer"
            title="پل مستقیم به سبد خرید"
            id="global-header-cart-btn"
          >
            <ShoppingCart className="w-4 h-4 text-white" />
            <span className="hidden sm:inline">سبد خرید (Cart)</span>
            <span className="bg-red-500 text-white font-sans text-xs font-black min-w-[20px] h-5 rounded-full flex items-center justify-center px-1 border border-white/20">
              {toPersianDigits(cartItems.reduce((acc, item) => acc + item.quantity, 0))}
            </span>
          </button>

          <a
            href="https://github.com"
            target="_blank"
            rel="noreferrer"
            className="bg-slate-800/40 hover:bg-slate-800 text-slate-400 hover:text-white font-bold px-3 py-2.5 rounded-xl border border-slate-800 transition flex items-center gap-1.5"
          >
            <FolderGit className="w-3.5 h-3.5" />
            مخزن محصول (GitHub)
          </a>
        </div>
      </header>

      {/* Main interactive split page layout */}
      <main className="flex-1 grid grid-cols-1 xl:grid-cols-12 gap-6 p-6 overflow-hidden max-w-7xl mx-auto w-full">
        
        {/* Left Side: Phone Device Emulator (Renders Iranian UI Marketplace) */}
        <div className="xl:col-span-4 flex flex-col items-center justify-center bg-[#111418] border border-[#191e24] p-6 rounded-[2.5rem] relative shadow-lg min-w-0">
          <div className="absolute top-4 right-4 bg-white/5 text-slate-400 text-[10px] font-bold px-2.5 py-1 rounded-full border border-white/10 flex items-center gap-1">
            <Smartphone className="w-3.5 h-3.5" />
            شبیه‌ساز زنده اندروید ۱۴
          </div>

          <DeviceFrame
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            isLoggedIn={isLoggedIn}
            cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
            favoritesCount={favorites.length}
            showNotificationShade={showNotificationShade}
            setShowNotificationShade={setShowNotificationShade}
            notifications={notifications}
            onClearNotification={handleClearNotification}
            onClearAllNotifications={handleClearAllNotifications}
            onAddNotification={handleAddNotification}
            selectedProduct={selectedProduct}
            onCloseProductDetails={() => setSelectedProduct(null)}
            onAddToCart={handleAddToCart}
            onToggleFavorite={handleToggleFavorite}
            favorites={favorites}
            addLog={addLog}
            vendorMode={vendorMode}
          >
            {isLoggedIn ? (
              /* Tab Render Switch Engine */
              <>
                {vendorMode ? (
                  <VendorConsole
                    onBackToBuyer={() => {
                      addLog('UI', 'خروج از پنل غرفه‌داری همکار به مد خرید', 'تغییر به بازارچه مشتریان');
                      setVendorMode(false);
                    }}
                    products={products}
                    onAddProduct={(p) => {
                      setProducts((prev) => [p, ...prev]);
                      addLog('REPOSITORY', 'محصول جدید با موفقیت درج گشت و پیوند داده شد', p.title);
                    }}
                    onEditProduct={(updated) => {
                      setProducts((prev) => prev.map((p) => p.id === updated.id ? updated : p));
                      addLog('REPOSITORY', 'محصول با موفقیت ویرایش گشت و همگام‌سازی شد', updated.title);
                    }}
                    onDeleteProduct={(id) => {
                      setProducts((prev) => prev.filter((p) => p.id !== id));
                      addLog('REPOSITORY', 'محصول از دیتابیس کاتالوگ با موفقیت حذف گردید', `شناسه: ${id}`);
                    }}
                    addLog={addLog}
                    shop={shop}
                    onRegisterShop={(s) => {
                      setShop(s);
                      addLog('REPOSITORY', 'غرفه با موفقیت ثبت و پیوند داده شد', s.name);
                    }}
                    onUpdateShop={setShop}
                    categories={categories}
                  />
                ) : activePaymentSession ? (
                  <PaymentHub
                    amount={activePaymentSession.amount}
                    orderId={activePaymentSession.orderId}
                    onPaymentSuccess={handlePaymentSuccess}
                    onPaymentCancel={handlePaymentCancel}
                    addLog={addLog}
                  />
                ) : showTransactionsHistory ? (
                  <PaymentHub
                    amount={0}
                    orderId=""
                    onPaymentSuccess={() => {}}
                    onPaymentCancel={handlePaymentCancel}
                    addLog={addLog}
                    historyModeOnly={true}
                  />
                ) : (
                  <>
                    {activeTab === 0 && (
                      <HomeTab
                        onProductSelect={setSelectedProduct}
                        favorites={favorites}
                        toggleFavorite={handleToggleFavorite}
                        onNavigateToTab={setActiveTab}
                        addLog={addLog}
                        onOpenNotifications={() => setShowNotificationShade(true)}
                        notificationCount={notifications.filter((n) => !n.isRead).length}
                        products={products}
                        cartCount={cartItems.reduce((acc, item) => acc + item.quantity, 0)}
                      />
                    )}
                    {activeTab === 1 && (
                      <CategoriesTab
                        onProductSelect={setSelectedProduct}
                        favorites={favorites}
                        toggleFavorite={handleToggleFavorite}
                        addLog={addLog}
                        products={products}
                        categories={categories}
                      />
                    )}
                    {activeTab === 2 && (
                      <CartTab
                        cartItems={cartItems}
                        onUpdateQuantity={handleUpdateQuantity}
                        onClear={handleClearCart}
                        onCheckout={handleCheckout}
                        addLog={addLog}
                      />
                    )}
                    {activeTab === 3 && (
                      /* Custom lightweight interactive Favorites Screen */
                      <div className="flex flex-col bg-slate-50 h-full pb-20 font-vazir text-right" dir="rtl" id="wishlist-scroller">
                        <div className="sticky top-0 z-10 bg-white shadow-sm px-4 py-3 flex items-center gap-1.5">
                          <Heart className="w-4 h-4 text-red-500 fill-red-500" />
                          <h2 className="text-sm font-black text-gray-950">محصولات نشان‌شده شما</h2>
                        </div>

                        {favorites.length === 0 ? (
                          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-gray-400">
                            <span className="text-4xl mb-3">💔</span>
                            <h4 className="text-xs font-bold text-gray-900">هیچ محصولی نشان نشده است</h4>
                            <p className="text-[10px] text-gray-500 mt-1 max-w-xs leading-normal">
                              محصولات را لایک کنید تا برای دسترسی سریع در این بخش نمایش داده شوند.
                            </p>
                          </div>
                        ) : (
                          <div className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-2.5">
                            {products
                              .filter((p) => favorites.includes(p.id))
                              .map((product) => (
                                <div 
                                  key={product.id}
                                  className="bg-white border border-gray-100 rounded-2xl p-3 flex gap-3 shadow-sm hover:shadow relative select-none"
                                >
                                  <img src={product.image} alt={product.title} className="w-16 h-16 object-cover rounded-xl shrink-0" />
                                  <div className="flex-1 flex flex-col justify-between py-1">
                                    <div>
                                      <h4 className="text-[10px] font-black text-gray-800 line-clamp-1 leading-snug">{product.title}</h4>
                                      <span className="text-[8px] text-gray-400 block mt-0.5">فروشنده: {product.vendor.name}</span>
                                    </div>
                                    <div className="flex items-center justify-between">
                                      <span className="text-xs font-black text-gray-950">
                                        {formatPrice(product.price)} <span className="text-[8px] font-medium text-gray-400">تومان</span>
                                      </span>

                                      <div className="flex gap-1.5">
                                        <button
                                          onClick={() => {
                                            addLog('UI', 'انتقال کالا از برگه نشان‌ها به سبدخرید', `کالا: ${product.title}`);
                                            handleAddToCart(product);
                                          }}
                                          className="bg-blue-600 hover:bg-blue-700 text-white font-black text-[9px] px-2.5 py-1.5 rounded-lg active:scale-95 transition"
                                        >
                                          خرید کالا
                                        </button>
                                        <button
                                          onClick={() => {
                                            addLog('UI', 'رویداد حذف از علاقه‌مندی‌ها', `محصول: ${product.title}`);
                                            handleToggleFavorite(product);
                                          }}
                                          className="text-red-500 hover:bg-red-50 p-1.5 rounded-lg border border-red-100"
                                          title="حذف"
                                        >
                                          <Heart className="w-3.5 h-3.5 fill-red-500" />
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              ))}
                          </div>
                        )}
                      </div>
                    )}
                     {activeTab === 4 && (
                      <ProfileTab
                        userName={userName}
                        userPhone={userPhone}
                        userEmail={userEmail}
                        onUpdateProfile={(name, phone, email) => {
                          setUserName(name);
                          setUserPhone(phone);
                          setUserEmail(email);
                          addLog('REPOSITORY', 'به‌روزرسانی موفق اطلاعات کاربری در دیتابیس محلی', `نام: ${name}`);
                        }}
                        addresses={addresses}
                        onUpdateAddresses={(newAddrs) => {
                          setAddresses(newAddrs);
                          addLog('REPOSITORY', 'همگام‌سازی نشانی‌های کاربر انجام شد', `تعداد نشانی‌ها: ${newAddrs.length}`);
                        }}
                        activeAddressId={activeAddressId}
                        onSetActiveAddressId={setActiveAddressId}
                        addLog={addLog}
                        orders={orders}
                        onLogout={handleLogout}
                        vendorMode={vendorMode}
                        onToggleVendorMode={setVendorMode}
                        onUpdateOrderStatus={handleUpdateOrderStatus}
                        onOpenPaymentHistory={() => setShowTransactionsHistory(true)}
                      />
                    )}
                  </>
                )}
              </>
            ) : (
              <AuthFlow onAuthSuccess={handleAuthSuccess} addLog={addLog} />
            )}
          </DeviceFrame>

          {/* Persistent Feedback Floating Button */}
          <button
            type="button"
            onClick={() => setIsFeedbackModalOpen(true)}
            className="absolute -bottom-3 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white text-[11px] font-black px-4 py-2.5 rounded-full shadow-lg hover:shadow-red-500/30 active:scale-95 transition flex items-center gap-1.5 cursor-pointer z-40 select-none border border-white/10 animate-pulse"
            id="open-feedback-floating-btn"
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>ثبت بازخورد و گزارش خطا</span>
          </button>
        </div>

        {/* Right Side: IDE Codebase Explorer & Arch Trace consoles */}
        <div className="xl:col-span-8 flex flex-col gap-6 overflow-hidden h-[670px] min-w-0" id="developer-workspace-container">
          
          {/* Top of Right side: Flutter-style codebase Explorer / Dynamic Admin Dashboard */}
          <div className="flex-1 min-h-0">
            {rightSideView === 'AI_ENGINE' ? (
              <AiEngineConsole products={products} addLog={addLog} />
            ) : rightSideView === 'CODE' ? (
              <CodeExplorer addLog={addLog} />
            ) : rightSideView === 'ADMIN' ? (
              <AdminConsole
                products={products}
                onAddProduct={(p) => {
                  setProducts((prev) => [p, ...prev]);
                  addLog('REPOSITORY', 'ثبت محصول جدید در دیتابیس ادمین', p.title);
                }}
                onEditProduct={(updated) => {
                  setProducts((prev) => prev.map((p) => p.id === updated.id ? updated : p));
                  addLog('REPOSITORY', 'ویرایش محصول از پنل ادمین', updated.title);
                }}
                onDeleteProduct={(id) => {
                  setProducts((prev) => prev.filter((p) => p.id !== id));
                  addLog('REPOSITORY', 'حذف محصول با دسترسی ادمین', `ID: ${id}`);
                }}
                categories={categories}
                onAddCategory={handleAddCategory}
                onEditCategory={handleEditCategory}
                onDeleteCategory={handleDeleteCategory}
                orders={orders}
                onUpdateOrderStatus={handleUpdateOrderStatus}
                addLog={addLog}
                onAddNotification={(notif) => {
                  setNotifications((prev) => [notif, ...prev]);
                }}
                reports={reports}
                onResolveReport={handleResolveReport}
                shop={shop}
                onApproveShop={(decision) => setShop(prev => prev ? { ...prev, status: decision } : null)}
              />
            ) : (
              <ReleaseConsole
                products={products}
                addLog={addLog}
                onAddNotification={(notif) => {
                  setNotifications((prev) => [notif, ...prev]);
                }}
              />
            )}
          </div>

          {/* Bottom of Right side: Live trace architecture diagrams */}
          <div className="h-[230px] shrink-0">
            <ArchitectureDiagram logs={logs} onClearLogs={() => setLogs([])} />
          </div>

        </div>

      </main>

      {/* Foot system description metadata */}
      <footer className="bg-[#0b0c0e] border-t border-[#14181c] py-5 px-6 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-medium text-slate-400">
            بازارچه یوزآنلاین — ارائه‌شده با کاتلین، جت‌پک کامپوز و پالت رنگی رسمی Material Design 3. طراحی چیدمان RTL همراه با فونت وزیرمتن.
          </p>
          <div className="flex items-center gap-4 text-[11px] text-slate-500 font-mono">
            <span>Package Name: ir.useonline.shop</span>
            <span>•</span>
            <span>Architecture: MVVM + Clean</span>
            <span>•</span>
            <span>Date: 2026</span>
          </div>
        </div>
      </footer>
      {isFeedbackModalOpen && <FeedbackModal />}
    </div>
  );
}
