export interface Product {
  id: string;
  title: string; // Persian title
  englishTitle: string;
  price: number; // in Tomans
  originalPrice?: number;
  discountPercentage?: number;
  image: string;
  category: string;
  categoryId: string;
  rating: number;
  reviewsCount: number;
  vendor: {
    name: string;
    rating: number;
    logo: string;
  };
  description: string;
  specifications: { [key: string]: string };
  stock?: number; // Product Inventory count
}

export interface UserAddress {
  id: string;
  title: string; // "خانه‌ مرودشت" یا "محل کار"
  receiverName: string;
  phoneNumber: string;
  zipCode: string;
  province: string;
  city: string;
  details: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  subcategories: Array<{ id: string; name: string; image: string }>;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  date: string;
  status: 'PENDING' | 'PREPARING' | 'SHIPPED' | 'DELIVERED';
  itemsCount: number;
  totalPrice: number;
  trackingNumber: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  body: string;
  time: string;
  type: 'ORDER' | 'PROMO' | 'SYSTEM';
  isRead: boolean;
}

export interface ArchLog {
  id: string;
  timestamp: string;
  layer: 'UI' | 'VIEWMODEL' | 'USECASE' | 'REPOSITORY' | 'DATASOURCE';
  message: string;
  details: string;
}

export interface UserProfile {
  name: string;
  phoneNumber: string;
  email: string;
  balance: number;
  address: string;
  orders: Order[];
}

export interface VendorShop {
  id?: string;
  name: string;
  category: string;
  description: string;
  logo: string;
  rating: number;
  balance: number;
  ordersCount: number;
  
  // High-fidelity Multi-Vendor Extensions
  status?: 'PENDING_APPROVAL' | 'APPROVED' | 'REJECTED';
  email?: string;
  phone?: string;
  address?: string;
  shaba?: string;
  joinedDate?: string;
  bannerColor?: string;
}

