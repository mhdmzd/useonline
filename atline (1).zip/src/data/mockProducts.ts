import { Product, Category, NotificationItem } from '../types';

export const mockCategories: Category[] = [
  {
    id: 'digital',
    name: 'کالای دیجیتال',
    icon: 'Smartphone',
    subcategories: [
      { id: 'phones', name: 'گوشی موبایل', image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&auto=format&fit=crop&q=80' },
      { id: 'laptops', name: 'لپ‌تاپ و تبلت', image: 'https://images.unsplash.com/photo-1496181130204-755241544e3f?w=300&auto=format&fit=crop&q=80' },
      { id: 'audio', name: 'هدفون و تجهیزات صوتی', image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300&auto=format&fit=crop&q=80' },
      { id: 'accessories', name: 'لوازم جانبی دیجیتال', image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=300&auto=format&fit=crop&q=80' },
    ]
  },
  {
    id: 'apparel',
    name: 'مد و پوشاک',
    icon: 'Shirt',
    subcategories: [
      { id: 'men-clothing', name: 'پوشاک مردانه', image: 'https://images.unsplash.com/photo-1488161628813-04466f872be2?w=300&auto=format&fit=crop&q=80' },
      { id: 'women-clothing', name: 'پوشاک زنانه', image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=300&auto=format&fit=crop&q=80' },
      { id: 'shoes', name: 'کفش و کتانی', image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=300&auto=format&fit=crop&q=80' },
      { id: 'bags', name: 'کیف و کوله‌پشتی', image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?w=300&auto=format&fit=crop&q=80' },
    ]
  },
  {
    id: 'home',
    name: 'خانه و آشپزخانه',
    icon: 'Home',
    subcategories: [
      { id: 'kitchen', name: 'لوازم آشپزخانه', image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?w=300&auto=format&fit=crop&q=80' },
      { id: 'decor', name: 'دکوراسیون داخلی', image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=300&auto=format&fit=crop&q=80' },
      { id: 'furniture', name: 'مبلمان و صندلی', image: 'https://images.unsplash.com/photo-1592078615290-033ee584e267?w=300&auto=format&fit=crop&q=80' },
    ]
  },
  {
    id: 'cosmetics',
    name: 'آرایشی و بهداشتی',
    icon: 'Sparkles',
    subcategories: [
      { id: 'skincare', name: 'مراقبت از پوست', image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=300&auto=format&fit=crop&q=80' },
      { id: 'perfume', name: 'عطر و ادکلن', image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=300&auto=format&fit=crop&q=80' },
      { id: 'makeup', name: 'لوازم آرایشی', image: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=300&auto=format&fit=crop&q=80' },
    ]
  },
  {
    id: 'supermarket',
    name: 'کالاهای سوپرمارکتی',
    icon: 'ShoppingBag',
    subcategories: [
      { id: 'beverages', name: 'نوشیدنی‌ها', image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=300&auto=format&fit=crop&q=80' },
      { id: 'snacks', name: 'تنقلات و شیرینیجات', image: 'https://images.unsplash.com/photo-1599490659213-e2b9527ec0cf?w=300&auto=format&fit=crop&q=80' },
      { id: 'staples', name: 'کالاهای اساسی', image: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=300&auto=format&fit=crop&q=80' },
    ]
  }
];

export const mockProducts: Product[] = [
  {
    id: 'p1',
    title: 'گوشی موبایل سامسونگ گلکسی S24 Ultra دو سیم‌کارت ظرفیت 256 گیگابایت',
    englishTitle: 'Samsung Galaxy S24 Ultra 5G Dual SIM 256GB',
    price: 68900000,
    originalPrice: 72500000,
    discountPercentage: 5,
    image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=500&auto=format&fit=crop&q=80',
    category: 'گوشی موبایل',
    categoryId: 'phones',
    rating: 4.8,
    reviewsCount: 124,
    vendor: {
      name: 'یوزآنلاین دیجیتال',
      rating: 4.9,
      logo: 'UD'
    },
    description: 'پرچمدار جدید سامسونگ مجهز به هوش مصنوعی پیشرفته Galaxy AI، دوربین فوق‌العاده ۲۰۰ مگاپیکسلی، نمایشگر روشن با روکش شیشه‌ای مقاوم گوریلا آرمور و بدنه تیتانیومی بی‌نظیر. قلم S-Pen اختصاصی کارایی را دوچندان می‌کند.',
    specifications: {
      'ابعاد صفحه فایل': '۶.۸ اینچ Dynamic AMOLED 2X',
      'رزولوشن دوربین': '۲۰۰ + ۵۰ + ۱۲ + ۱۰ مگاپیکسل',
      'حافظه رم اولیه': '۱۲ گیگابایت',
      'باتری و شارژ': '۵۰۰۰ میلی‌آمپر ساعت - ۴۵ وات',
      'جنس بدنه': 'تیتانیوم درجه یک',
      'پردازنده مرکزی': 'Snapdragon 8 Gen 3 (4nm)'
    }
  },
  {
    id: 'p2',
    title: 'هدفون بی‌سیم اپل مدل Airpods Pro 2 (USB-C) نویزکنسلینگ',
    englishTitle: 'Apple AirPods Pro 2nd Gen USB-C ANC',
    price: 13200000,
    originalPrice: 14500000,
    discountPercentage: 9,
    image: 'https://images.unsplash.com/photo-1588444837495-c6cfeb53f32d?w=500&auto=format&fit=crop&q=80',
    category: 'هدفون و تجهیزات صوتی',
    categoryId: 'audio',
    rating: 4.9,
    reviewsCount: 89,
    vendor: {
      name: 'پردیس کالا',
      rating: 4.7,
      logo: 'PK'
    },
    description: 'نسل دوم هدفون جادویی ایرپادز پرو با درگاه تایپ‌سی، تراشه جدید H2 برای تفکیک صدای پیشرفته، تا دو برابر لغو نویز فعال (ANC) بهتر، حالت شفافیت تطبیقی، و کیس شارژ مجهز به بلندگو همراه با حلقه بندآویز.',
    specifications: {
      'تراشه پردازش صوتی': 'H2 در هدفون‌ها / U1 در کیس',
      'عمر باتری کل': 'تا ۳۰ ساعت همراه باساز کیس شارژ',
      'نوع مقاومت محیطی': 'IP54 مقاوم در برابر گرد و غبار و رطوبت',
      'اتصال و سنسورها': 'بلوتوث نسخه ۵.۳، لمسی حرکتی'
    }
  },
  {
    id: 'p3',
    title: 'ساعت هوشمند شیائومی مدل Redmi Watch 4 صفحه مستطیلی',
    englishTitle: 'Xiaomi Redmi Watch 4 Smart Watch',
    price: 4350000,
    originalPrice: 4800000,
    discountPercentage: 10,
    image: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=500&auto=format&fit=crop&q=80',
    category: 'لوازم جانبی دیجیتال',
    categoryId: 'accessories',
    rating: 4.5,
    reviewsCount: 215,
    vendor: {
      name: 'هوشمند شاپ',
      rating: 4.6,
      logo: 'HS'
    },
    description: 'ساعت هوشمند ردمی واچ ۴ مجهز به فریم آلومینیومی مستحکم، نمایشگر امولد بزرگ و شارپ، GPS چندسیستمی مجزا برای ردیابی دقیق‌تر مسافت، تست ۲۴ ساعته اکسیژن خون و ضربان قلب، با نگهداری باتری فوق‌العاده ۲۰ روزه.',
    specifications: {
      'اندازه صفحه': '۱.۹۷ اینچ AMOLED ۶۰ هرتز',
      'ظرفیت باتری': '۴۷۰ میلی‌آمپر (تا ۲۰ روز)',
      'سنسورهای سلامت': 'سنسور ضربان، اکسیژن خون (SpO2)، شتاب‌سنج',
      'پشتیبانی ورزشی': 'بیش از ۱۵۰ حالت ورزشی متنوع'
    }
  },
  {
    id: 'p4',
    title: 'کفش رانینگ مردانه نایک پگاسوس Air Zoom Pegasus 40',
    englishTitle: 'Nike Air Zoom Pegasus 40 Running Shoes',
    price: 6400000,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&auto=format&fit=crop&q=80',
    category: 'کفش و کتانی',
    categoryId: 'shoes',
    rating: 4.7,
    reviewsCount: 63,
    vendor: {
      name: 'ورزش‌سرا',
      rating: 4.8,
      logo: 'VS'
    },
    description: 'کفش دویدن نمادین نایک پگاسوس ۴۰ با رویه‌ای از جنس مش مهندسی‌شده تنفس‌پذیر، بهره‌مندی از فوم سبک‌وزن Nike React در سراسر کفی و دو واحد Air Zoom مجزا در پاشنه و پنجه برای حداکثر برگشت انرژی.',
    specifications: {
      'تکنولوژی کفی': 'فوم ضربه‌گیر نایک React',
      'جنس رویه': 'پارچه تاروپود مشبک تنفس سریع',
      'مناسب سناریوهای': 'دویدن طولانی‌مدت، پیاده‌روی، تمرین باشگاه'
    }
  },
  {
    id: 'p5',
    title: 'ادو پرفیوم مردانه بلو د شنل مدل Bleu de Chanel حجم 100 میلی‌لیتر',
    englishTitle: 'Bleu de Chanel Eau de Parfum 100ml',
    price: 8900000,
    originalPrice: 9500000,
    discountPercentage: 6,
    image: 'https://images.unsplash.com/photo-1541643600914-78b084683601?w=500&auto=format&fit=crop&q=80',
    category: 'عطر و ادکلن',
    categoryId: 'perfume',
    rating: 4.9,
    reviewsCount: 78,
    vendor: {
      name: 'لوکس گالری',
      rating: 4.9,
      logo: 'LG'
    },
    description: 'یکی از درخشان‌ترین و جاودانه‌ترین روایح چوبی و آروماتیک جهان. بلو د شنل با ترکیب قدرتمند گریپ‌فروت، لیمو، نعناع هندی، سدر، یاس متمایز و کهربای گرم، امضای مردانه همیشگی شما در فصول مختلف خواهد بود.',
    specifications: {
      'نوع دقیق رایحه': 'خنک، تلخ و چوبی معطر',
      'نت‌های اولیه چاپی': 'گریپ‌فروت، فلفل صورتی، نعناع، لیمو ترش',
      'نت‌های پایه مانا': 'کهربا، بخور خوشبو، صندل، لادن، سدر عمقی',
      'غلظت اسانس فرار': 'Eau de Parfum (EDP)'
    }
  },
  {
    id: 'p6',
    title: 'لپ‌تاپ 14 اینچی ایسوس ZenBook Duo مدل UX3405 نسل جدید Core Ultra 7',
    englishTitle: 'ASUS ZenBook Duo OLED Intel Core Ultra 7',
    price: 92400000,
    originalPrice: 94000000,
    discountPercentage: 2,
    image: 'https://images.unsplash.com/photo-1496181130204-755241544e3f?w=500&auto=format&fit=crop&q=80',
    category: 'لپ‌تاپ و تبلت',
    categoryId: 'laptops',
    rating: 4.6,
    reviewsCount: 15,
    vendor: {
      name: 'آرتان رایانه',
      rating: 4.8,
      logo: 'AR'
    },
    description: 'نوآوری منحصربه‌فرد ایسوس با دو نمایشگر لمسی خارق‌العاده OLED مجزا که فضای کاری بزرگی در اختیار تان می‌گذارد. مجهز به پردازنده هوشمند اینتل کور الترا ۷ با پردازنده گرافیکی پیشرفته Intel Arc و کیبورد جداشونده مغناطیسی.',
    specifications: {
      'پردازنده مرکزی': 'Intel Core Ultra 7 155H (16 Cores)',
      'حافظه رم داخلی': '۳۲ گیگابایت LPDDR5X',
      'فضای ذخیره فایل': '۱ ترابایت SSD NVMe PCIe 4.0',
      'مشخصات نمایشگرها': 'دو پنل ۱۴ اینچ OLED لمسی 3K با نرخ ۱۲۰ هرتز'
    }
  }
];

export const mockNotifications: NotificationItem[] = [
  {
    id: 'n1',
    title: 'سفارش شما ارسال شد 🚀',
    body: 'سفارش شماره AT-87612 با مرسوله پست پیشتاز شماره ۳۹۰۱۸۲۷۳ به مامور پست تحویل داده شد. ممنون از خرید شما!',
    time: '۱۰ دقیقه پیش',
    type: 'ORDER',
    isRead: false
  },
  {
    id: 'n2',
    title: 'اعتبار رایگان هدیه یوزآنلاین 🎁',
    body: 'همراه گرامی، مبلغ ۵۰,۰۰۰ تومان اعتبار هدیه به کیف‌پول شما افزوده شد. همین حالا می‌توانید در خرید بعدی از آن استفاده کنید.',
    time: '۲ ساعت پیش',
    type: 'SYSTEM',
    isRead: false
  },
  {
    id: 'n3',
    title: 'تخفیف شگفت‌انگیز برای شما 🔥',
    body: 'گوشی موبایل سامسونگ Galaxy S24 Ultra هم‌اکنون با تخفیف ویژه ۵ درصدی و گارانتی ۱۸ ماهه در صفحه شگفت‌انگیزهای یوزآنلاین موجود است.',
    time: '۱ روز پیش',
    type: 'PROMO',
    isRead: true
  }
];

export const mockBanners = [
  {
    id: 'b1',
    title: 'تخفیف‌های استثنایی تابستانی یوزآنلاین',
    subtitle: 'تا ۴۰٪ تخفیف روی داغ‌ترین کالاهای دیجیتال بازار',
    image: 'https://images.unsplash.com/photo-1542751371-adc38448a05e?w=800&auto=format&fit=crop&q=80',
    color: 'from-blue-600 to-indigo-800'
  },
  {
    id: 'b2',
    title: 'سبک خودت رو بساز با برندهای برتر پوشاک',
    subtitle: 'ارسال رایگان + ضمانت بازگشت بی‌قید و شرط ۷ روزه',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?w=800&auto=format&fit=crop&q=80',
    color: 'from-pink-600 to-rose-800'
  }
];
