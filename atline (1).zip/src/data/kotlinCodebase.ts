export interface KotlinFile {
  path: string;
  name: string;
  layer: 'domain' | 'data' | 'presentation' | 'config';
  content: string;
  description: string;
}

export const kotlinCodebase: KotlinFile[] = [
  {
    path: 'domain/model/Product.kt',
    name: 'Product.kt',
    layer: 'domain',
    description: 'کلاس موجودیت (Entity) محصول در لایه دامنه. مستقل از فریمورک‌ها.',
    content: `package ir.useonline.shop.domain.model

data class Product(
    val id: String,
    val title: String,
    val englishTitle: String,
    val price: Long,
    val originalPrice: Long? = null,
    val discountPercentage: Int? = null,
    val imageUrl: String,
    val category: String,
    val categoryId: String,
    val rating: Float,
    val reviewsCount: Int,
    val vendor: Vendor,
    val description: String,
    val specifications: Map<String, String>
)

data class Vendor(
    val id: String,
    val name: String,
    val rating: Float,
    val logoUrl: String
)`
  },
  {
    path: 'domain/repository/ProductRepository.kt',
    name: 'ProductRepository.kt',
    layer: 'domain',
    description: 'واسط (Interface) مخزن محصولات که لایه دیتا باید آن را پیاده‌سازی کند.',
    content: `package ir.useonline.shop.domain.repository

import ir.useonline.shop.domain.model.Product
import kotlinx.coroutines.flow.Flow

interface ProductRepository {
    fun getProducts(): Flow<List<Product>>
    fun getProductsByCategory(categoryId: String): Flow<List<Product>>
    fun getProductDetails(productId: String): Flow<Product?>
    suspend fun searchProducts(query: String): List<Product>
}`
  },
  {
    path: 'domain/usecase/GetProductsUseCase.kt',
    name: 'GetProductsUseCase.kt',
    layer: 'domain',
    description: 'مورد استفاده (UseCase) برای دریافت لیست محصولات فروشگاه یوزآنلاین از مخزن.',
    content: `package ir.useonline.shop.domain.usecase

import ir.useonline.shop.domain.model.Product
import ir.useonline.shop.domain.repository.ProductRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class GetProductsUseCase @Inject constructor(
    private val productRepository: ProductRepository
) {
    operator fun invoke(categoryId: String? = null): Flow<List<Product>> {
        return if (categoryId == null) {
            productRepository.getProducts()
        } else {
            productRepository.getProductsByCategory(categoryId)
        }
    }
}`
  },
  {
    path: 'data/repository/ProductRepositoryImpl.kt',
    name: 'ProductRepositoryImpl.kt',
    layer: 'data',
    description: 'پیاده‌سازی واسط مخزن محصولات در لایه داده با ارتباط با سرویس شبکه و پایگاه‌داده محلی.',
    content: `package ir.useonline.shop.data.repository

import ir.useonline.shop.data.remote.UseOnlineApiService
import ir.useonline.shop.domain.model.Product
import ir.useonline.shop.domain.repository.ProductRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject

class ProductRepositoryImpl @Inject constructor(
    private val apiService: UseOnlineApiService
) : ProductRepository {

    override fun getProducts(): Flow<List<Product>> = flow {
        // ابتدا داده‌های کش محلی یا حالت لودینگ
        val response = apiService.getAllProducts()
        if (response.isSuccessful) {
            emit(response.body()?.map { it.toDomain() } ?: emptyList())
        }
    }

    override fun getProductsByCategory(categoryId: String): Flow<List<Product>> = flow {
        val response = apiService.getProductsByCategory(categoryId)
        if (response.isSuccessful) {
            emit(response.body()?.map { it.toDomain() } ?: emptyList())
        }
    }

    override fun getProductDetails(productId: String): Flow<Product?> = flow {
        val response = apiService.getProductById(productId)
        if (response.isSuccessful) {
            emit(response.body()?.toDomain())
        }
    }

    override suspend fun searchProducts(query: String): List<Product> {
        val response = apiService.searchProducts(query)
        return if (response.isSuccessful) {
            response.body()?.map { it.toDomain() } ?: emptyList()
        } else {
            emptyList()
        }
    }
}`
  },
  {
    path: 'presentation/navigation/Screen.kt',
    name: 'Screen.kt',
    layer: 'presentation',
    description: 'تعریف مسیرها و آرگومان‌های ناوبری در Jetpack Compose برای صفحات برنامه.',
    content: `package ir.useonline.shop.presentation.navigation

sealed class Screen(val route: String) {
    object Auth : Screen("auth_route")
    object Login : Screen("login_screen")
    object Register : Screen("register_screen")
    object ForgotPassword : Screen("forgot_password_screen")
    
    object Main : Screen("main_route")
    object Home : Screen("home_screen")
    object Categories : Screen("categories_screen")
    object Cart : Screen("cart_screen")
    object Favorites : Screen("favorites_screen")
    object Profile : Screen("profile_screen")
    
    object ProductDetail : Screen("product_detail_screen/{productId}") {
        fun createRoute(productId: String) = "product_detail_screen/$productId"
    }
}`
  },
  {
    path: 'presentation/theme/Type.kt',
    name: 'Type.kt',
    layer: 'presentation',
    description: 'تنظیمات فونت وزیرمتن (Vazirmatn) برای انطباق کامل با زبان شیرین فارسی در Material 3.',
    content: `package ir.useonline.shop.presentation.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import ir.useonline.shop.R

private val VazirmatnFontFamily = FontFamily(
    Font(R.font.vazirmatn_thin, FontWeight.Thin),
    Font(R.font.vazirmatn_light, FontWeight.Light),
    Font(R.font.vazirmatn_regular, FontWeight.Normal),
    Font(R.font.vazirmatn_medium, FontWeight.Medium),
    Font(R.font.vazirmatn_bold, FontWeight.Bold),
    Font(R.font.vazirmatn_black, FontWeight.Black)
)

val UseOnlineTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp
    ),
    titleLarge = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 22.sp,
        lineHeight = 28.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp
    ),
    labelMedium = TextStyle(
        fontFamily = VazirmatnFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 12.sp,
        lineHeight = 16.sp
    )
)`
  },
  {
    path: 'presentation/home/HomeViewModel.kt',
    name: 'HomeViewModel.kt',
    layer: 'presentation',
    description: 'ViewModel صفحه اصلی که حالت محصولات، فیلترها و بنرها را ذخیره کرده و به کامپوز پاس می‌دهد.',
    content: `package ir.useonline.shop.presentation.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.useonline.shop.domain.model.Product
import ir.useonline.shop.domain.usecase.GetProductsUseCase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val getProductsUseCase: GetProductsUseCase
) : ViewModel() {

    private val _uiState = MutableStateFlow<HomeUiState>(HomeUiState.Loading)
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    init {
        fetchHomeData()
    }

    fun fetchHomeData() {
        viewModelScope.launch {
            _uiState.value = HomeUiState.Loading
            getProductsUseCase()
                .catch { exception ->
                    _uiState.value = HomeUiState.Error(exception.message ?: "خطای ناشناخته رخ داده است")
                }
                .collect { products ->
                    _uiState.value = HomeUiState.Success(
                        products = products,
                        banners = getMockBanners()
                    )
                }
        }
    }

    private fun getMockBanners(): List<String> = listOf(
        "https://images.unsplash.com/photo-1542751371-adc38448a05e",
        "https://images.unsplash.com/photo-1483985988355-763728e1935b"
    )
}

sealed interface HomeUiState {
    object Loading : HomeUiState
    data class Success(val products: List<Product>, val banners: List<String>) : HomeUiState
    data class Error(val message: String) : HomeUiState
}`
  },
  {
    path: 'presentation/home/HomeScreen.kt',
    name: 'HomeScreen.kt',
    layer: 'presentation',
    description: 'نمای صفحه اصلی فروشگاه یوزآنلاین شامل سایدبارهای لایه‌ای، بنرها و لیست فروشگاه با طرح راست‌چین.',
    content: `package ir.useonline.shop.presentation.home

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import ir.useonline.shop.presentation.navigation.Screen

@Composable
fun HomeScreen(
    navController: NavController,
    viewModel: HomeViewModel = hiltViewModel()
) {
    // اجبار چیدمان به حالتِ راست‌چین (RTL) برای زبان فارسی
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val uiState by viewModel.uiState.collectAsState()

        Scaffold(
            topBar = {
                HomeSearchBar(
                    onSearchClick = { /* ناوبری به صفحه جستجو */ },
                    onNotificationClick = { /* باز کردن اعلانات */ }
                )
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentAlignment = Alignment.Center
            ) {
                when (uiState) {
                    is HomeUiState.Loading -> CircularProgressIndicator()
                    is HomeUiState.Success -> {
                        val state = uiState as HomeUiState.Success
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(bottom = 80.dp)
                        ) {
                            item { DynamicBannerCarousel(state.banners) }
                            item { CategoryQuickGrid(onCategorySelected = { cat -> 
                                navController.navigate(Screen.Categories.route)
                            }) }
                            item { SectionTitle(title = "تخفیف شگفت‌انگیز یوزآنلاین") }
                            item { 
                                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp)) {
                                    items(state.products.filter { it.discountPercentage != null }) { prod ->
                                        ProductItemCard(product = prod, onClick = {
                                            navController.navigate(Screen.ProductDetail.createRoute(prod.id))
                                        })
                                    }
                                }
                            }
                            item { SectionTitle(title = "پرطرفدارترین کالاها") }
                            items(state.products.chunked(2)) { pair ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    pair.forEach { prod ->
                                        Box(modifier = Modifier.weight(1f).padding(8.dp)) {
                                            ProductItemCard(product = prod, onClick = {
                                                navController.navigate(Screen.ProductDetail.createRoute(prod.id))
                                            })
                                        }
                                    }
                                    if (pair.size == 1) Box(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                    is HomeUiState.Error -> {
                        val message = (uiState as HomeUiState.Error).message
                        ErrorWidget(message = message, onRetry = { viewModel.fetchHomeData() })
                    }
                }
            }
        }
    }
}`
  },
  {
    path: 'presentation/cart/CartViewModel.kt',
    name: 'CartViewModel.kt',
    layer: 'presentation',
    description: 'کنترلر سبد خرید که افزودن، حذف و تعداد کالاهای سبد خرید یوزآنلاین را مدیریت می‌کند.',
    content: `package ir.useonline.shop.presentation.cart

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import ir.useonline.shop.domain.model.Product
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class CartItemState(val product: Product, val quantity: Int)

@HiltViewModel
class CartViewModel @Inject constructor() : ViewModel() {

    private val _cartItems = MutableStateFlow<List<CartItemState>>(emptyList())
    val cartItems: StateFlow<List<CartItemState>> = _cartItems.asStateFlow()

    val totalAmount: Flow<Long> = _cartItems.map { items ->
        items.sumOf { item ->
            val finalPrice = item.product.price
            finalPrice * item.quantity
        }
    }

    fun addProduct(product: Product) {
        val currentList = _cartItems.value.toMutableList()
        val existingIndex = currentList.indexOfFirst { it.product.id == product.id }
        if (existingIndex != -1) {
            currentList[existingIndex] = currentList[existingIndex].copy(
                quantity = currentList[existingIndex].quantity + 1
            )
        } else {
            currentList.add(CartItemState(product, 1))
        }
        _cartItems.value = currentList
    }

    fun removeProduct(productId: String) {
        val currentList = _cartItems.value.toMutableList()
        val existingIndex = currentList.indexOfFirst { it.product.id == productId }
        if (existingIndex != -1) {
            val item = currentList[existingIndex]
            if (item.quantity > 1) {
                currentList[existingIndex] = item.copy(quantity = item.quantity - 1)
            } else {
                currentList.removeAt(existingIndex)
            }
        }
        _cartItems.value = currentList
    }

    fun clearCart() {
        _cartItems.value = emptyList()
    }
}`
  },
  {
    path: 'presentation/theme/Color.kt',
    name: 'Color.kt',
    layer: 'presentation',
    description: 'پالت رنگی رسمی برند یوزآنلاین مبتنی بر استانداردهای متریال دیزاین ۳.',
    content: `package ir.useonline.shop.presentation.theme

import androidx.compose.ui.graphics.Color

// UseOnline Official M3 Color Palette
val UseOnlinePrimary = Color(0xFF0073E6)
val UseOnlineOnPrimary = Color(0xFFFFFFFF)
val UseOnlinePrimaryContainer = Color(0xFFD6E4FF)
val UseOnlineOnPrimaryContainer = Color(0xFF001B3D)

val UseOnlineSecondary = Color(0xFF535F70)
val UseOnlineOnSecondary = Color(0xFFFFFFFF)

val UseOnlineTertiary = Color(0xFFFF5252)
val UseOnlineOnTertiary = Color(0xFFFFFFFF)

val UseOnlineBackground = Color(0xFFF9FAFC)
val UseOnlineOnBackground = Color(0xFF191C20)
val UseOnlineSurface = Color(0xFFFFFFFF)
val UseOnlineOnSurface = Color(0xFF191C20)`
  },
  {
    path: 'package_info/UseOnlineShopApp.kt',
    name: 'UseOnlineShopApp.kt',
    layer: 'config',
    description: 'کلاس اصلی اپلیکیشن جهت به کارگیری Hilt برای تزریق وابستگی‌ها.',
    content: `package ir.useonline.shop

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class UseOnlineShopApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // تنظیمات اولیه‌ی کرش لیتیک، پوش نوتیفیکیشن یا کش‌گذاری تصاویر
    }
}`
  }
];
