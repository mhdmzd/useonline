export type PaymentStatus = 'PENDING' | 'SUCCESSFUL' | 'FAILED' | 'REFUNDED' | 'PROCESSING';

export interface PaymentMethodInfo {
  id: string;
  name: string;
  englishName: string;
  logo: string; // Emoji or Lucide icon name description
  description: string;
  type: 'GATEWAY' | 'INSTALLMENT' | 'WALLET' | 'BANK';
  accentColor: string; // Tailwind bg color class
  textAccentColor: string; // Tailwind text color class
}

export interface PaymentSession {
  token: string; // Cryptographic secure token
  authority: string; // Gateway authority/RefID
  actionUrl: string; // Sandbox redirect URL
  expiresAt: string; // Expiration ISO string
  amount: number;
  paymentMethodId: string;
  orderId: string;
}

export interface PaymentVerificationResult {
  isSuccess: boolean;
  refId?: string;
  cardPan?: string; // Masked PAN
  errorMessage?: string;
  errorCode?: string;
  verifiedAt: string;
}

export interface PaymentRefundResult {
  isSuccess: boolean;
  refundRefId?: string;
  refundedAmount: number;
  errorMessage?: string;
  refundedAt: string;
}

export interface PaymentTransaction {
  id: string; // Local transaction tracking code
  orderId: string;
  amount: number;
  status: PaymentStatus;
  paymentMethodId: string;
  token: string;
  authority: string;
  cardPan?: string;
  refId?: string;
  createdAt: string;
  verifiedAt?: string;
  refundedAt?: string;
  refundReason?: string;
  errorMessage?: string;
}

/**
 * Standard Modular Contract Interface for all UseOnline Payment Gateways.
 * Following DI / Dependency Injection patterns, any gateway matching this contract
 * can be plugged into the central Payment Manager/Processor dynamically.
 */
export interface IPaymentGateway {
  getInfo(): PaymentMethodInfo;
  
  initializePayment(
    amount: number, 
    orderId: string, 
    callbackUrl: string, 
    metadata?: any
  ): Promise<PaymentSession>;
  
  verifyPayment(
    authority: string, 
    amount: number, 
    paymentToken: string
  ): Promise<PaymentVerificationResult>;
  
  refundPayment(
    transactionId: string, 
    amount: number, 
    reason: string
  ): Promise<PaymentRefundResult>;
}
