import { 
  IPaymentGateway, 
  PaymentMethodInfo, 
  PaymentSession, 
  PaymentVerificationResult, 
  PaymentRefundResult 
} from './types';

// Helper for cryptographic mock token generation
const generateMockToken = (prefix: string): string => {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let token = prefix + '_';
  for (let i = 0; i < 24; i++) {
    token += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return token;
};

// Helper for numerical authority/RefID generation
const generateNumericRef = (length: number): string => {
  let result = '';
  for (let i = 0; i < length; i++) {
    result += Math.floor(Math.random() * 10).toString();
  }
  return result;
};

/**
 * ZarinPal Gateway Sandbox Integration (IPG)
 */
export class ZarinPalGateway implements IPaymentGateway {
  getInfo(): PaymentMethodInfo {
    return {
      id: 'zarinpal',
      name: 'درگاه پرداخت اینترنتی زرین‌پال',
      englishName: 'ZarinPal Payment Gateway',
      logo: '💳',
      description: 'پرداخت سریع با کلیه کارت‌های عضو شتاب، تسویه پایدار و مطمئن ریالی',
      type: 'GATEWAY',
      accentColor: 'bg-amber-500/10 border-amber-500/20 text-amber-700',
      textAccentColor: 'text-amber-500',
    };
  }

  async initializePayment(amount: number, orderId: string, callbackUrl: string, metadata?: any): Promise<PaymentSession> {
    const authority = '0000000000000000000000000000' + generateNumericRef(8);
    const token = generateMockToken('zp_sec');
    
    // Simulate payment session generation with secure authority token
    return {
      token,
      authority,
      actionUrl: `https://sandbox.zarinpal.com/pg/StartPay/${authority}`,
      expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString(), // 30 mins
      amount,
      paymentMethodId: 'zarinpal',
      orderId,
    };
  }

  async verifyPayment(authority: string, amount: number, paymentToken: string): Promise<PaymentVerificationResult> {
    const isSuccess = !authority.endsWith('000'); // Let's make "000" suffix stand for cancellation/fail
    
    return {
      isSuccess,
      refId: 'ZP_REF_' + generateNumericRef(10),
      cardPan: '۶۰۳۷-۹۹**-****-۱۲۳۴',
      verifiedAt: new Date().toISOString(),
      errorMessage: isSuccess ? undefined : 'پرداخت توسط کاربر لغو گردید یا تراکنش ناموفق بود.',
      errorCode: isSuccess ? undefined : 'CANCELED_BY_USER'
    };
  }

  async refundPayment(transactionId: string, amount: number, reason: string): Promise<PaymentRefundResult> {
    return {
      isSuccess: true,
      refundRefId: 'ZP_RFD_' + generateNumericRef(9),
      refundedAmount: amount,
      refundedAt: new Date().toISOString()
    };
  }
}

/**
 * SnappPay Buy-Now-Pay-Later (BNPL) Integration
 */
export class SnappPayGateway implements IPaymentGateway {
  getInfo(): PaymentMethodInfo {
    return {
      id: 'snapppay',
      name: 'اسنپ‌پی (پرداخت قسطی ۴ مرحله‌ای)',
      englishName: 'SnappPay BNPL Service',
      logo: '💚',
      description: 'الان بخر، در ۴ قسط بدون کارمزد پرداخت کن! (اعتبارسنجی آنی شماره همراه)',
      type: 'INSTALLMENT',
      accentColor: 'bg-emerald-500/10 border-emerald-500/20 text-emerald-700',
      textAccentColor: 'text-emerald-500',
    };
  }

  async initializePayment(amount: number, orderId: string, callbackUrl: string, metadata?: any): Promise<PaymentSession> {
    const authority = 'SP_AUTH_' + generateNumericRef(12);
    const token = generateMockToken('spy_token');
    
    return {
      token,
      authority,
      actionUrl: `https://api.snapppay.ir/v1/payment/checkout?authority=${authority}`,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // 15 mins
      amount,
      paymentMethodId: 'snapppay',
      orderId,
    };
  }

  async verifyPayment(authority: string, amount: number, paymentToken: string): Promise<PaymentVerificationResult> {
    return {
      isSuccess: true,
      refId: 'SP_TRX_' + generateNumericRef(10),
      cardPan: 'تسهیلات ۴ مرحله‌ای اسنپ‌پی',
      verifiedAt: new Date().toISOString()
    };
  }

  async refundPayment(transactionId: string, amount: number, reason: string): Promise<PaymentRefundResult> {
    return {
      isSuccess: true,
      refundRefId: 'SP_RFD_' + generateNumericRef(9),
      refundedAmount: amount,
      refundedAt: new Date().toISOString()
    };
  }
}

/**
 * DigiPay Wallet & Smart Installments Support
 */
export class DigiPayGateway implements IPaymentGateway {
  getInfo(): PaymentMethodInfo {
    return {
      id: 'digipay',
      name: 'دیجی‌پی (کیف پول و خرید اقساطی)',
      englishName: 'DigiPay Smart Payment',
      logo: '🔵',
      description: 'پرداخت امن با کیف پول دیجی‌پی یا اعتبارهای اقساطی دیجی‌کالا',
      type: 'WALLET',
      accentColor: 'bg-blue-500/10 border-blue-500/20 text-blue-700',
      textAccentColor: 'text-blue-500',
    };
  }

  async initializePayment(amount: number, orderId: string, callbackUrl: string, metadata?: any): Promise<PaymentSession> {
    const authority = 'DP_' + generateNumericRef(14);
    const token = generateMockToken('dp_secure');
    
    return {
      token,
      authority,
      actionUrl: `https://gateway.mydigipay.com/payment/initiate?authority=${authority}`,
      expiresAt: new Date(Date.now() + 20 * 60 * 1000).toISOString(),
      amount,
      paymentMethodId: 'digipay',
      orderId,
    };
  }

  async verifyPayment(authority: string, amount: number, paymentToken: string): Promise<PaymentVerificationResult> {
    return {
      isSuccess: true,
      refId: 'DP_REF_' + generateNumericRef(11),
      cardPan: 'اعتبار کیف پول هوشمند دیجی‌پی',
      verifiedAt: new Date().toISOString()
    };
  }

  async refundPayment(transactionId: string, amount: number, reason: string): Promise<PaymentRefundResult> {
    return {
      isSuccess: true,
      refundRefId: 'DP_RFD_' + generateNumericRef(9),
      refundedAmount: amount,
      refundedAt: new Date().toISOString()
    };
  }
}

/**
 * Bank Melli (SADAD IPG gateway)
 */
export class MelliGateway implements IPaymentGateway {
  getInfo(): PaymentMethodInfo {
    return {
      id: 'melli',
      name: 'درگاه بانک ملی ایران (سداد)',
      englishName: 'Bank Melli Sadad IPG',
      logo: '🦁',
      description: 'سریع‌ترین درگاه اتصال مستقیم شتاب با پروتکل رمزنگاری سداد بانک ملی',
      type: 'BANK',
      accentColor: 'bg-indigo-500/10 border-indigo-500/20 text-indigo-700',
      textAccentColor: 'text-indigo-600',
    };
  }

  async initializePayment(amount: number, orderId: string, callbackUrl: string, metadata?: any): Promise<PaymentSession> {
    // Generate secure token like SADAD (combination of TerminalId and SignData)
    const authority = 'SADAD_REF_' + generateNumericRef(12);
    const token = generateMockToken('melli_sadad');
    
    return {
      token,
      authority,
      actionUrl: `https://sadad.shaparak.ir/VPG/Purchase?authority=${authority}`,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000).toISOString(), // 10 mins (secure/fast)
      amount,
      paymentMethodId: 'melli',
      orderId,
    };
  }

  async verifyPayment(authority: string, amount: number, paymentToken: string): Promise<PaymentVerificationResult> {
    return {
      isSuccess: true,
      refId: generateNumericRef(12), // SADAD numeric Retrive No
      cardPan: '۶۰۳۷-۹۹**-****-۴۳۲۱',
      verifiedAt: new Date().toISOString()
    };
  }

  async refundPayment(transactionId: string, amount: number, reason: string): Promise<PaymentRefundResult> {
    return {
      isSuccess: true,
      refundRefId: 'SADAD_RFD_' + generateNumericRef(10),
      refundedAmount: amount,
      refundedAt: new Date().toISOString()
    };
  }
}

/**
 * Bank Mellat (BehPardakht IPG)
 */
export class MellatGateway implements IPaymentGateway {
  getInfo(): PaymentMethodInfo {
    return {
      id: 'mellat',
      name: 'درگاه به‌پرداخت ملت',
      englishName: 'Bank Mellat BehPardakht',
      logo: '🔴',
      description: 'پایداری بالا، کمترین خطای قطعی تراکنش زیر نظر شرکت به‌پرداخت ملت',
      type: 'BANK',
      accentColor: 'bg-rose-500/10 border-rose-500/20 text-rose-700',
      textAccentColor: 'text-rose-600',
    };
  }

  async initializePayment(amount: number, orderId: string, callbackUrl: string, metadata?: any): Promise<PaymentSession> {
    const authority = 'BP_REF_' + generateNumericRef(15);
    const token = generateMockToken('mellat_bp');
    
    return {
      token,
      authority,
      actionUrl: `https://bpm.shaparak.ir/pgwchannel/startpay.mellat?RefId=${authority}`,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
      amount,
      paymentMethodId: 'mellat',
      orderId,
    };
  }

  async verifyPayment(authority: string, amount: number, paymentToken: string): Promise<PaymentVerificationResult> {
    return {
      isSuccess: true,
      refId: generateNumericRef(14),
      cardPan: '۶۱۰۴-۳۳**-****-۸۸۹۹',
      verifiedAt: new Date().toISOString()
    };
  }

  async refundPayment(transactionId: string, amount: number, reason: string): Promise<PaymentRefundResult> {
    return {
      isSuccess: true,
      refundRefId: 'BP_RFD_' + generateNumericRef(12),
      refundedAmount: amount,
      refundedAt: new Date().toISOString()
    };
  }
}

/**
 * Asan Pardakht (UP) Mobile Wallet & IPG
 */
export class AsanPardakhtGateway implements IPaymentGateway {
  getInfo(): PaymentMethodInfo {
    return {
      id: 'asanpardakht',
      name: 'آسان‌پرداخت (آپ)',
      englishName: 'Asan Pardakht Wallet',
      logo: '🧡',
      description: 'شارژ و کسر مستقیم از کیف پول آپ یا پرداخت از طریق رمز پویا کد USSD',
      type: 'WALLET',
      accentColor: 'bg-orange-500/10 border-orange-500/20 text-orange-700',
      textAccentColor: 'text-orange-500',
    };
  }

  async initializePayment(amount: number, orderId: string, callbackUrl: string, metadata?: any): Promise<PaymentSession> {
    const authority = 'UP_TOKEN_' + generateNumericRef(10);
    const token = generateMockToken('up_secure_shaping');
    
    return {
      token,
      authority,
      actionUrl: `https://asan.shaparak.ir/up/purchase?token=${authority}`,
      expiresAt: new Date(Date.now() + 20 * 60 * 1000).toISOString(),
      amount,
      paymentMethodId: 'asanpardakht',
      orderId,
    };
  }

  async verifyPayment(authority: string, amount: number, paymentToken: string): Promise<PaymentVerificationResult> {
    return {
      isSuccess: true,
      refId: 'UP_REF_' + generateNumericRef(10),
      cardPan: 'کیف پول آنلاین آپ',
      verifiedAt: new Date().toISOString()
    };
  }

  async refundPayment(transactionId: string, amount: number, reason: string): Promise<PaymentRefundResult> {
    return {
      isSuccess: true,
      refundRefId: 'UP_RFD_' + generateNumericRef(9),
      refundedAmount: amount,
      refundedAt: new Date().toISOString()
    };
  }
}

/**
 * Tara Organizational Wallet & Instalment Plan
 */
export class TaraGateway implements IPaymentGateway {
  getInfo(): PaymentMethodInfo {
    return {
      id: 'tara',
      name: 'سامانه تارا (سازمانی و اعتباری)',
      englishName: 'Tara Wallet & Loyalty Credit',
      logo: '⭐',
      description: 'خرید اعتباری اختصاصی کسر از حقوق در توافق‌نامه سازمانی تارا',
      type: 'INSTALLMENT',
      accentColor: 'bg-violet-500/10 border-violet-500/20 text-violet-700',
      textAccentColor: 'text-violet-600',
    };
  }

  async initializePayment(amount: number, orderId: string, callbackUrl: string, metadata?: any): Promise<PaymentSession> {
    const authority = 'TARA_TRX_' + generateNumericRef(11);
    const token = generateMockToken('tara_crypt_payload');
    
    return {
      token,
      authority,
      actionUrl: `https://tara360.ir/v2/payment/auth?token=${authority}`,
      expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(),
      amount,
      paymentMethodId: 'tara',
      orderId,
    };
  }

  async verifyPayment(authority: string, amount: number, paymentToken: string): Promise<PaymentVerificationResult> {
    return {
      isSuccess: true,
      refId: 'TARA_REF_' + generateNumericRef(11),
      cardPan: 'اعتبار سازمانی تارا',
      verifiedAt: new Date().toISOString()
    };
  }

  async refundPayment(transactionId: string, amount: number, reason: string): Promise<PaymentRefundResult> {
    return {
      isSuccess: true,
      refundRefId: 'TARA_RFD_' + generateNumericRef(10),
      refundedAmount: amount,
      refundedAt: new Date().toISOString()
    };
  }
}
