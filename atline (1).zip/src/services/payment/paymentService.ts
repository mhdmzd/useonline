import { 
  IPaymentGateway, 
  PaymentMethodInfo, 
  PaymentSession, 
  PaymentTransaction, 
  PaymentVerificationResult, 
  PaymentRefundResult,
  PaymentStatus 
} from './types';
import { 
  ZarinPalGateway, 
  SnappPayGateway, 
  DigiPayGateway, 
  MelliGateway, 
  MellatGateway, 
  AsanPardakhtGateway, 
  TaraGateway 
} from './gateways';

export class PaymentManager {
  private gateways: Map<string, IPaymentGateway> = new Map();
  private transactions: PaymentTransaction[] = [];
  private onLog?: (layer: 'UI' | 'VIEWMODEL' | 'USECASE' | 'REPOSITORY' | 'DATASOURCE', message: string, details: string) => void;

  /**
   * Dependency Injection constructor: Inject array of available payment gateways
   */
  constructor(
    gateways: IPaymentGateway[],
    onLog?: (layer: 'UI' | 'VIEWMODEL' | 'USECASE' | 'REPOSITORY' | 'DATASOURCE', message: string, details: string) => void
  ) {
    this.onLog = onLog;
    gateways.forEach(g => {
      const info = g.getInfo();
      this.gateways.set(info.id, g);
    });

    this.loadTransactions();
  }

  private saveLog(layer: 'UI' | 'VIEWMODEL' | 'USECASE' | 'REPOSITORY' | 'DATASOURCE', message: string, details: string) {
    if (this.onLog) {
      this.onLog(layer, message, details);
    }
  }

  /**
   * Load history from standard client storage
   */
  private loadTransactions() {
    try {
      const stored = localStorage.getItem('useonline_payment_transactions');
      if (stored) {
        this.transactions = JSON.parse(stored);
      } else {
        // Seed some history for realistic experience
        this.transactions = [
          {
            id: 'TXN-902381',
            orderId: 'AT-8392',
            amount: 12450000,
            status: 'SUCCESSFUL',
            paymentMethodId: 'zarinpal',
            token: 'zp_sec_seeded1',
            authority: '000000000000000000000000000010293021',
            cardPan: '۶۰۳۷-۹۹**-****-۵۵۲۱',
            refId: 'ZP_REF_5520192801',
            createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
            verifiedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
          },
          {
            id: 'TXN-401920',
            orderId: 'AT-1120',
            amount: 4350000,
            status: 'SUCCESSFUL',
            paymentMethodId: 'snapppay',
            token: 'spy_token_seeded2',
            authority: 'SP_AUTH_220192830192',
            cardPan: 'تسهیلات ۴ مرحله‌ای اسنپ‌پی',
            refId: 'SP_TRX_9920194021',
            createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
            verifiedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
          },
          {
            id: 'TXN-773019',
            orderId: 'AT-5102',
            amount: 890000,
            status: 'FAILED',
            paymentMethodId: 'melli',
            token: 'melli_sadad_failed',
            authority: 'SADAD_REF_881920381023',
            createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
            errorMessage: 'انصراف خریدار از طی فرآیند شتاب',
          }
        ];
        this.saveTransactions();
      }
    } catch (e) {
      this.transactions = [];
    }
  }

  private saveTransactions() {
    try {
      localStorage.setItem('useonline_payment_transactions', JSON.stringify(this.transactions));
    } catch (e) {
      console.error('Failed to persist payment history to local storage', e);
    }
  }

  /**
   * Get all registered payment gateways
   */
  public getSupportedMethods(): PaymentMethodInfo[] {
    return Array.from(this.gateways.values()).map(g => g.getInfo());
  }

  public getPaymentMethodById(id: string): PaymentMethodInfo | undefined {
    return this.gateways.get(id)?.getInfo();
  }

  /**
   * Get total transactions list
   */
  public getTransactions(): PaymentTransaction[] {
    return [...this.transactions];
  }

  /**
   * 1. INITIALIZE PAYMENT SESSION
   * Initiates gateway connection and stores the pending transaction
   */
  public async checkout(amount: number, orderId: string, paymentMethodId: string): Promise<PaymentSession> {
    const gateway = this.gateways.get(paymentMethodId);
    if (!gateway) {
      throw new Error(`payment_gateway_not_found: ${paymentMethodId}`);
    }

    this.saveLog('UI', 'آغاز اتصال امن بانکی و رمزگذاری هدر تاییدیه', `مبلغ: ${amount} ریال/تومان، درگاه: ${paymentMethodId}`);
    this.saveLog('VIEWMODEL', 'تولید شناسه موقت تراکنش در PaymentViewModel', `درگاه مقصد: ${paymentMethodId}`);

    // Call concrete gateway implementation
    const session = await gateway.initializePayment(amount, orderId, window.location.href);

    // Save pending transaction to log & local database
    const newTxn: PaymentTransaction = {
      id: 'TXN-' + Math.floor(100000 + Math.random() * 900000).toString(),
      orderId,
      amount,
      status: 'PENDING',
      paymentMethodId,
      token: session.token,
      authority: session.authority,
      createdAt: new Date().toISOString(),
    };

    this.transactions = [newTxn, ...this.transactions];
    this.saveTransactions();

    this.saveLog('REPOSITORY', 'تراکنش معلق با توکن توزیع شده ذخیره شد', `کد تراکنش: ${newTxn.id}`);
    this.saveLog('DATASOURCE', 'درج سطر تراکنش (INSERT INTO payment_transactions)', `مبلغ: ${amount}`);

    return session;
  }

  /**
   * 2. VERIFY TRANSACTION STATUS (SANDBOX SIMULATION)
   * Completes payment verification after gateway return, supporting test success/failure routes
   */
  public async verify(
    txnId: string, 
    verifyMode: 'SUCCESS' | 'FAIL' | 'CANCEL' = 'SUCCESS'
  ): Promise<PaymentTransaction> {
    const txn = this.transactions.find(t => t.id === txnId);
    if (!txn) {
      throw new Error(`transaction_not_found: ${txnId}`);
    }

    const gateway = this.gateways.get(txn.paymentMethodId);
    if (!gateway) {
      throw new Error(`gateway_not_found: ${txn.paymentMethodId}`);
    }

    this.saveLog('UI', 'دریافت پاسخ بازگشتی از گیت‌وی ملی شاداب', `کد: ${txnId}`);
    this.saveLog('VIEWMODEL', 'احراز امضای امن تراکنش با سرور مرجع', `تاییدیه: ${txn.authority}`);

    // Wait for simulated network delay (e.g. 1000ms) to mirror banking APIs
    await new Promise(resolve => setTimeout(resolve, 800));

    let verification: PaymentVerificationResult;

    if (verifyMode === 'SUCCESS') {
      verification = await gateway.verifyPayment(txn.authority, txn.amount, txn.token);
    } else if (verifyMode === 'CANCEL') {
      verification = {
        isSuccess: false,
        errorMessage: 'انصراف تعمدی خریدار از تسویه در پایانه درگاه',
        errorCode: 'USER_CANCELED',
        verifiedAt: new Date().toISOString()
      };
    } else {
      verification = {
        isSuccess: false,
        errorMessage: 'خطای سیستمی تراکنش بانکی: قطعی ارتباط با شبکه صادرکننده کارت (سوئیچ شتاب)',
        errorCode: 'SHATAB_TIMEOUT',
        verifiedAt: new Date().toISOString()
      };
    }

    // Update internal status based on API response
    this.transactions = this.transactions.map(t => {
      if (t.id === txnId) {
        return {
          ...t,
          status: verification.isSuccess ? 'SUCCESSFUL' : 'FAILED',
          cardPan: verification.cardPan,
          refId: verification.refId,
          verifiedAt: verification.verifiedAt,
          errorMessage: verification.errorMessage,
        };
      }
      return t;
    });

    this.saveTransactions();

    const finalizedTxn = this.transactions.find(t => t.id === txnId)!;

    this.saveLog(
      'REPOSITORY', 
      verification.isSuccess ? 'تراکنش با وضعیت کامیت نهایی شد' : 'ثبت خطای تایید تراکنش در لاگ مرکزی', 
      `وضعیت: ${finalizedTxn.status} - کد رهگیری: ${finalizedTxn.refId || 'ندارد'}`
    );

    return finalizedTxn;
  }

  /**
   * 3. REFUND AND REVERSE AMOUNT
   */
  public async refund(txnId: string, reason: string): Promise<PaymentTransaction> {
    const txn = this.transactions.find(t => t.id === txnId);
    if (!txn) {
      throw new Error(`transaction_not_found: ${txnId}`);
    }

    if (txn.status !== 'SUCCESSFUL') {
      throw new Error('refund_invalid_status: Only successful transactions can be refunded');
    }

    const gateway = this.gateways.get(txn.paymentMethodId);
    if (!gateway) {
      throw new Error(`gateway_not_found: ${txn.paymentMethodId}`);
    }

    this.saveLog('UI', 'درخواست استرداد آنلاین وجه ثبت شد', `تراکنش: ${txnId}`);
    this.saveLog('VIEWMODEL', 'فراخوانی متد بازگشت استخر بانکی RefundUseCases', `دلیل: ${reason}`);

    // Network delay mock
    await new Promise(resolve => setTimeout(resolve, 600));

    const refundRes = await gateway.refundPayment(txnId, txn.amount, reason);

    if (refundRes.isSuccess) {
      this.transactions = this.transactions.map(t => {
        if (t.id === txnId) {
          return {
            ...t,
            status: 'REFUNDED',
            refundedAt: refundRes.refundedAt,
            refundReason: reason,
          };
        }
        return t;
      });

      this.saveTransactions();
      this.saveLog('REPOSITORY', 'ثبت سند برگشت شارژ تسویه شده با امضا', `شماره استرداد: ${refundRes.refundRefId}`);
    } else {
      this.saveLog('REPOSITORY', 'عدم توافق ارائه‌کننده با برگشت وجه', refundRes.errorMessage || 'Unknown fail');
      throw new Error(refundRes.errorMessage || 'Refund rejected by gateway');
    }

    return this.transactions.find(t => t.id === txnId)!;
  }
}

/**
 * Dependency Injection factory function to bootstrapper client setup
 */
export function createDefaultPaymentManager(
  onLog?: (layer: 'UI' | 'VIEWMODEL' | 'USECASE' | 'REPOSITORY' | 'DATASOURCE', message: string, details: string) => void
): PaymentManager {
  const registeredGateways = [
    new ZarinPalGateway(),
    new SnappPayGateway(),
    new DigiPayGateway(),
    new MelliGateway(),
    new MellatGateway(),
    new AsanPardakhtGateway(),
    new TaraGateway(),
  ];

  return new PaymentManager(registeredGateways, onLog);
}
