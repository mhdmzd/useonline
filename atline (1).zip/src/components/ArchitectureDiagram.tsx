import React, { useEffect, useRef } from 'react';
import { Terminal, Shield, RefreshCw, Layers, ArrowLeft, Database, Code, Activity } from 'lucide-react';
import { ArchLog } from '../types';

interface ArchitectureDiagramProps {
  logs: ArchLog[];
  onClearLogs: () => void;
}

export function ArchitectureDiagram({ logs, onClearLogs }: ArchitectureDiagramProps) {
  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Auto-scroll logs terminal
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  // Determine latest active layer to highlight visually in the block flow chart
  const latestLog = logs[logs.length - 1];
  const activeLayer = latestLog ? latestLog.layer : null;

  return (
    <div className="flex flex-col h-full bg-slate-900 border border-slate-800 rounded-3xl p-5 shadow-xl select-none" id="architecture-tracer-container">
      {/* Header bar */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
          <span className="font-mono font-black text-xs text-white uppercase tracking-wider">Clean MVVM Flow Tracer</span>
        </div>
        <button
          onClick={onClearLogs}
          className="text-[10px] font-mono text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 px-2.5 py-1 rounded transition"
        >
          پاکسازی گزارش‌ها
        </button>
      </div>

      {/* 1. Layers visual block diagram */}
      <div className="grid grid-cols-5 gap-2.5 mb-5 select-none" id="architecture-diagram-flow">
        {[
          { key: 'UI', name: 'Presentation (UI)', color: 'border-purple-500 text-purple-400 bg-purple-500/10 shadow-purple-500/20', icon: Code },
          { key: 'VIEWMODEL', name: 'ViewModel', color: 'border-pink-500 text-pink-400 bg-pink-500/10 shadow-pink-500/20', icon: Layers },
          { key: 'USECASE', name: 'Domain UseCase', color: 'border-blue-500 text-blue-400 bg-blue-500/10 shadow-blue-500/20', icon: Shield },
          { key: 'REPOSITORY', name: 'Repository', color: 'border-amber-500 text-amber-400 bg-amber-500/10 shadow-amber-500/20', icon: RefreshCw },
          { key: 'DATASOURCE', name: 'Data Source', color: 'border-emerald-500 text-emerald-400 bg-emerald-500/10 shadow-emerald-500/20', icon: Database },
        ].map((layer) => {
          const isActive = activeLayer === layer.key;
          const LayerIcon = layer.icon;
          return (
            <div
              key={layer.key}
              className={`border rounded-xl p-2.5 flex flex-col items-center justify-center text-center gap-1.5 transition-all duration-300 ${
                isActive
                  ? `${layer.color} border-2 scale-105 shadow-lg ring-1 ring-white/10`
                  : 'border-slate-800 text-slate-500 hover:border-slate-700'
              }`}
            >
              <LayerIcon className={`w-4 h-4 ${isActive ? 'animate-bounce' : ''}`} />
              <span className="text-[9px] font-mono font-black leading-tight">{layer.name}</span>
              {isActive && (
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping absolute top-1.5 right-1.5" />
              )}
            </div>
          );
        })}
      </div>

      {/* 2. Log trace shell terminal */}
      <div className="flex-1 bg-slate-950 rounded-2xl border border-slate-800/60 p-4 font-mono text-[11px] leading-relaxed flex flex-col overflow-hidden min-h-0">
        <div className="flex items-center gap-1.5 text-slate-500 border-b border-slate-900 pb-2 mb-2 select-none">
          <Terminal className="w-3.5 h-3.5" />
          <span className="text-[10px] font-bold uppercase tracking-widest">useonline-shopd-tracer::logs</span>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-1 select-text">
          {logs.map((log) => {
            const layerColors: Record<string, string> = {
              UI: 'text-purple-400 bg-purple-500/15',
              VIEWMODEL: 'text-pink-400 bg-pink-500/15',
              USECASE: 'text-blue-400 bg-blue-500/15',
              REPOSITORY: 'text-amber-400 bg-amber-500/15',
              DATASOURCE: 'text-emerald-400 bg-emerald-500/15',
            };

            return (
              <div key={log.id} className="border-b border-slate-900/60 pb-1.5 select-text hover:bg-slate-900/10 px-1 rounded transition">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[9px] text-slate-600">{log.timestamp}</span>
                  <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded ${layerColors[log.layer] || 'text-slate-300'}`}>
                    {log.layer}
                  </span>
                  <span className="text-slate-300 font-extrabold">{log.message}</span>
                </div>
                {log.details && (
                  <p className="text-[10px] text-slate-500 mt-1 pl-4 border-l border-slate-800">
                    ➔ {log.details}
                  </p>
                )}
              </div>
            );
          })}
          <div ref={terminalEndRef} />
        </div>
      </div>
    </div>
  );
}
