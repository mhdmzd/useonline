import React, { useState } from 'react';
import { 
  Folder, 
  FolderOpen, 
  FileCode, 
  Check, 
  Copy, 
  Search, 
  Terminal, 
  Download, 
  Code2, 
  Database, 
  Globe, 
  TrendingUp, 
  Play, 
  RefreshCw, 
  ChevronRight, 
  ShieldCheck, 
  Layers,
  Sparkles,
  Lock,
  ArrowRightLeft
} from 'lucide-react';
import { kotlinCodebase, KotlinFile } from '../data/kotlinCodebase';

// 1. Definition of Ecosystem APIs for the Interactive Gateway Tester
interface EcosystemApiEndpoint {
  id: string;
  method: 'POST' | 'GET' | 'PUT';
  path: string;
  title: string;
  desc: string;
  params: { name: string; type: string; placeholder: string; defaultValue: string; isRequired: boolean }[];
  defaultResponse: any;
  layer: 'DATASOURCE' | 'REPOSITORY' | 'USECASE' | 'VIEWMODEL' | 'UI';
}

const ecosystemEndpoints: EcosystemApiEndpoint[] = [
  {
    id: 'send_otp',
    method: 'POST',
    path: '/api/v1/auth/otp/send',
    title: 'ارسال پیامک ا‌تی‌پی (OTP SMS)',
    desc: 'احراز هویت و ورود دو مرحله‌ای کاربر به کمک سرور مخابراتی UseOnline',
    params: [
      { name: 'phone_number', type: 'string', placeholder: 'مثال: 09123456789', defaultValue: '09123456789', isRequired: true },
      { name: 'app_signature', type: 'string', placeholder: 'هش کافه بازار جهت خواندن خودکار', defaultValue: 'USEONLINE9482XJ', isRequired: false }
    ],
    defaultResponse: {
      status: 'success',
      message: 'رمز یکبار مصرف با موفقیت فرستاده شد',
      data: {
        session_id: 'sess_993a4bc8',
        expires_in_seconds: 120,
        gateway_provider: 'kaveh_negar_sms'
      }
    },
    layer: 'DATASOURCE'
  },
  {
    id: 'verify_otp',
    method: 'POST',
    path: '/api/v1/auth/otp/verify',
    title: 'تایید رمز یکبار مصرف',
    desc: 'اعتبارسنجی کد ۵ رقمی و بازیابی سشن JWT خریدار یا غرفه‌دار زرین‌تراکنش',
    params: [
      { name: 'phone_number', type: 'string', placeholder: 'ثبت شماره همکلاسی', defaultValue: '09123456789', isRequired: true },
      { name: 'code', type: 'string', placeholder: 'کد ۵ رقمی', defaultValue: '48231', isRequired: true }
    ],
    defaultResponse: {
      status: 'success',
      message: 'حساب با موفقیت احراز گشت',
      data: {
        access_token: 'jwt_eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
        user: {
          id: 'usr_f8cbeb22-38be',
          phone_number: '09123456789',
          name: 'کاربر سیستم یوزآنلاین',
          role: 'BUYER',
          status: 'ACTIVE',
          wallet_balance_tomans: 250000
        }
      }
    },
    layer: 'REPOSITORY'
  },
  {
    id: 'vendor_register',
    method: 'POST',
    path: '/api/v1/vendor/register',
    title: 'درخواست ثبت غرفه همکار (UseOnline Panel)',
    desc: 'ثبت نام متقاضی جدید برای فعالیت چندفروشگاهی همراه با بارگذاری کد ملی و شبا',
    params: [
      { name: 'shop_name', type: 'string', placeholder: 'نام غرفه', defaultValue: 'گالری مدرن مهرآیین', isRequired: true },
      { name: 'category', type: 'string', placeholder: 'دسته اصلی فعالیت', defaultValue: 'کالای دیجیتال', isRequired: true },
      { name: 'shaba_number', type: 'string', placeholder: 'شماره شبا بانک', defaultValue: 'IR820170000000123456789012', isRequired: true },
      { name: 'national_code', type: 'string', placeholder: 'کد ملی مدیر فروشگاه', defaultValue: '0019865431', isRequired: true }
    ],
    defaultResponse: {
      status: 'success',
      message: 'درخواست مدارک غرفه با موفقیت ثبت شد و در صف تایید مدیر سامانه قرار گرفت',
      data: {
        store_id: 'store_3bc84102',
        status: 'PENDING_APPROVAL',
        verification_tier: 'BASIC',
        commission_percentage: 2.5
      }
    },
    layer: 'USECASE'
  },
  {
    id: 'wallet_settle',
    method: 'POST',
    path: '/api/v1/wallet/settle',
    title: 'تسویه حساب نقدی غرفه‌دار مبارک',
    desc: 'درخواست پایا پورتال فروشندگان برای انتقال کارمزدهای نقدی غرفه به حساب شبا خریدار',
    params: [
      { name: 'store_id', type: 'string', placeholder: 'شناسه غرفه همکار', defaultValue: 'store_3bc84102', isRequired: true },
      { name: 'amount_tomans', type: 'number', placeholder: 'مبلغ تسویه (تومان)', defaultValue: '1250000', isRequired: true }
    ],
    defaultResponse: {
      status: 'success',
      message: 'درخواست تسویه با موفقیت به پروتکل پایا بانک مرکزی حواله یافت',
      data: {
        settlement_id: 'stl_44129x83',
        amount_processed: 1250000,
        bank_ref_id: 'PAYA_941019234851Z',
        commission_applied: 0
      }
    },
    layer: 'DATASOURCE'
  },
  {
    id: 'track_order',
    method: 'GET',
    path: '/api/v1/shipment/track',
    title: 'رهگیری وضعیت مرسوله (Snapbox/Tipax)',
    desc: 'استعلام اطلاعات زنده ارسال فیزیکی کالاها از مبدا انبار مرکزی غرفه تا تحویل فیزیکی',
    params: [
      { name: 'tracking_number', type: 'string', placeholder: 'کد ۱۲ رقمی پست/تیپاکس', defaultValue: '390198754125', isRequired: true }
    ],
    defaultResponse: {
      status: 'success',
      message: 'رهگیری بار فیزیکی با موفقیت از سروران لجستیک فراخوانی شد',
      data: {
        tracking_number: '390198754125',
        carrier_service: 'تیپاکس اکسپرس',
        courier_name: 'اصغر راد',
        courier_phone: '09121111111',
        history_events: [
          { status: 'DELIVERED_TO_HUB', location: 'انبار مرکزی تهران', time: '۱۴۰۵/۰۳/۱۵ ۱۰:۳۰' },
          { status: 'SORTING', location: 'هاب توزیع غرب', time: '۱۴۰۵/۰۳/۱۶ ۰۸:۱۵' },
          { status: 'OUT_FOR_DELIVERY', location: 'منطقه ۴ تهران', time: 'امروز، ۱۰:۰۰' }
        ],
        estimated_delivery: 'امروز قبل از ساعت ۱۸:۰۰'
      }
    },
    layer: 'VIEWMODEL'
  },
  {
    id: 'create_ticket',
    method: 'POST',
    path: '/api/v1/support/ticket',
    title: 'ثبت تیکت پشتیبانی مشترکین',
    desc: 'ارسال شکایت، بازخورد یا درخواست فنی کاربران به هاب داوری و ادمین‌های یوزآنلاین',
    params: [
      { name: 'title', type: 'string', placeholder: 'موضوع تیکت', defaultValue: 'عدم تطابق کالای ارسال غرفه با عکس محصول', isRequired: true },
      { name: 'category', type: 'string', placeholder: 'دسته‌بندی (فنی / مالی / مرجوعی)', defaultValue: 'مرجوعی کالا', isRequired: true },
      { name: 'description', type: 'string', placeholder: 'توضیحات تکمیلی کابر', defaultValue: 'ادکلن ارسالی ۵۰ میل است در حالی که در کاتالوگ ۱۰۰ میل قید شده بود.', isRequired: true },
      { name: 'priority', type: 'string', placeholder: 'اولویت (HIGH / MEDIUM / LOW)', defaultValue: 'HIGH', isRequired: true }
    ],
    defaultResponse: {
      status: 'success',
      message: 'تیکت شما با موفقیت ایجاد و به پشتیبانی شماره ۴ ارجاع شد',
      data: {
        ticket_id: 'tkt_8a391df2',
        queue_number: 14,
        status: 'OPEN',
        assigned_agent: 'سارا رضایی'
      }
    },
    layer: 'UI'
  }
];

// 2. PostgreSQL Tables Structures Representation
interface DbTableColumn {
  name: string;
  type: string;
  modifiers: string;
  desc: string;
}

interface DbTableDefinition {
  name: string;
  desc: string;
  columns: DbTableColumn[];
}

const dbTables: DbTableDefinition[] = [
  {
    name: 'users',
    desc: 'اطلاعات یکپارچه مشتریان، غرفه‌داران و مدیران کل اکوسیستم UseOnline',
    columns: [
      { name: 'id', type: 'UUID', modifiers: 'PRIMARY KEY DEFAULT gen_random_uuid()', desc: 'شناسه منحصر به فرد کاربر' },
      { name: 'phone_number', type: 'VARCHAR(15)', modifiers: 'UNIQUE NOT NULL', desc: 'شماره همراه احراز هویت شده موبایل' },
      { name: 'name', type: 'VARCHAR(100)', modifiers: 'NOT NULL', desc: 'نام و نام خانوادگی کاربر به فارسی' },
      { name: 'email', type: 'VARCHAR(150)', modifiers: 'UNIQUE NULLABLE', desc: 'پست الکترونیکی کابر جهت بازیابی' },
      { name: 'role', type: 'VARCHAR(20)', modifiers: 'DEFAULT \'BUYER\' CHECK(role IN (\'BUYER\', \'VENDOR\', \'ADMIN\'))', desc: 'نقش دسترسی کاربر در اکوسیستم چندفروشگاهی' },
      { name: 'status', type: 'VARCHAR(20)', modifiers: 'DEFAULT \'ACTIVE\' CHECK(status IN (\'ACTIVE\', \'BANNED\'))', desc: 'وضعیت حساب جهت فیلتر دسترسی تیک‌زدن فلوها' },
      { name: 'wallet_balance', type: 'BIGINT', modifiers: 'DEFAULT 0', desc: 'اعتبار ریالی/تومانی کیف‌پول لوکال کاربر' },
      { name: 'created_at', type: 'TIMESTAMP', modifiers: 'DEFAULT CURRENT_TIMESTAMP', desc: 'تاریخ ثبت‌نام نهایی کابر' }
    ]
  },
  {
    name: 'stores',
    desc: 'جدول انحصاری غرفه‌ها و فروشگاه‌های همکار متصل به سیستم کمیسیون (Vendors)',
    columns: [
      { name: 'id', type: 'UUID', modifiers: 'PRIMARY KEY DEFAULT gen_random_uuid()', desc: 'شناسه غرفه' },
      { name: 'user_id', type: 'UUID', modifiers: 'REFERENCES users(id) ON DELETE CASCADE', desc: 'سازنده فیزیکی و غرفه‌دار مسئول' },
      { name: 'name', type: 'VARCHAR(100)', modifiers: 'NOT NULL', desc: 'عنوان رسمی پارسی غرفه' },
      { name: 'category', type: 'VARCHAR(50)', modifiers: 'NOT NULL', desc: 'دسته‌بندی انحصاری محصولات غرفه' },
      { name: 'logo_url', type: 'VARCHAR(255)', modifiers: 'NULLABLE', desc: 'لینک فایل لوگوی گرافیکی غرفه' },
      { name: 'rating', type: 'DECIMAL(3,2)', modifiers: 'DEFAULT 0.00', desc: 'میانگین امتیاز غرفه حاصل از فیدبک‌ها' },
      { name: 'status', type: 'VARCHAR(30)', modifiers: 'DEFAULT \'PENDING_APPROVAL\' CHECK(status IN (\'PENDING_APPROVAL\', \'APPROVED\', \'REJECTED\'))', desc: 'وضعیت احراز هویت تجاری غرفه‌دار پس از ثبت صنف' },
      { name: 'shaba_number', type: 'VARCHAR(34)', modifiers: 'NOT NULL', desc: 'کد شبای رسمی پایا غرفه‌دار جهت تسویه‌حساب ثبتی' },
      { name: 'commission_rate', type: 'DECIMAL(5,2)', modifiers: 'DEFAULT 2.50', desc: 'درصد کمیسیون بازارچه روی فروش اقلام' },
      { name: 'created_at', type: 'TIMESTAMP', modifiers: 'DEFAULT CURRENT_TIMESTAMP', desc: 'زمان درج فروشگاه در هاب' }
    ]
  },
  {
    name: 'products',
    desc: 'لیست محصولات و انبار فیزیکی زنده چندفروشگاهی (Multi-Product Catalog)',
    columns: [
      { name: 'id', type: 'UUID', modifiers: 'PRIMARY KEY DEFAULT gen_random_uuid()', desc: 'شناسه یکتای کالا' },
      { name: 'store_id', type: 'UUID', modifiers: 'REFERENCES stores(id) ON DELETE CASCADE', desc: 'غرفه ثبت‌کننده و توزیع‌کننده محصول' },
      { name: 'title', type: 'VARCHAR(200)', modifiers: 'NOT NULL', desc: 'عنوان پارسی کالا مناسب سرچ کاربران' },
      { name: 'english_title', type: 'VARCHAR(200)', modifiers: 'NULLABLE', desc: 'عنوان انگلیسی جهت مشخصات سئو' },
      { name: 'price', type: 'BIGINT', modifiers: 'NOT NULL', desc: 'قیمت فروش کالا (تومان)' },
      { name: 'original_price', type: 'BIGINT', modifiers: 'NULLABLE', desc: 'قیمت بازار قبل از تخفیف فروشگاهی' },
      { name: 'discount_percentage', type: 'INT', modifiers: 'DEFAULT 0 CHECK (discount_percentage BETWEEN 0 AND 100)', desc: 'میزان تخفیف فعال روی کالا' },
      { name: 'image_url', type: 'VARCHAR(255)', modifiers: 'NOT NULL', desc: 'لینک تصویر کاتالوگ' },
      { name: 'description', type: 'TEXT', modifiers: 'NULLABLE', desc: 'توضیحات و نقد و بررسی محصول' },
      { name: 'specifications', type: 'JSONB', modifiers: 'DEFAULT \'{}\'::jsonb', desc: 'مشخصات فنی کالا به صورت ساختار کلید-مقدار پویا' },
      { name: 'stock', type: 'INT', modifiers: 'DEFAULT 0 CHECK (stock >= 0)', desc: 'کوانتیته و موجودی زنده انبار غرفه‌دار' },
      { name: 'video_url', type: 'VARCHAR(255)', modifiers: 'NULLABLE', desc: 'فیلم پیش‌نمایش یا تست محصول' },
      { name: 'created_at', type: 'TIMESTAMP', modifiers: 'DEFAULT CURRENT_TIMESTAMP', desc: 'تاریخ تعریف کالا' }
    ]
  },
  {
    name: 'orders',
    desc: 'کارت صورتحساب خرید و جزییات لجستیکی تراکنش مشتریان',
    columns: [
      { name: 'id', type: 'UUID', modifiers: 'PRIMARY KEY DEFAULT gen_random_uuid()', desc: 'کد رهگیری تراکنش بازارچه' },
      { name: 'buyer_id', type: 'UUID', modifiers: 'REFERENCES users(id) ON DELETE RESTRICT', desc: 'خریدار ثبت فاکتور' },
      { name: 'status', type: 'VARCHAR(30)', modifiers: 'DEFAULT \'PENDING\' CHECK(status IN (\'PENDING\', \'PREPARING\', \'SHIPPED\', \'DELIVERED\'))', desc: 'وضعیت پردازش فیزیکی مرسوله' },
      { name: 'total_price', type: 'BIGINT', modifiers: 'NOT NULL', desc: 'مبلغ نهایی پرداختی فاکتور با احتساب آفرها' },
      { name: 'discount_code_id', type: 'VARCHAR(50)', modifiers: 'NULLABLE', desc: 'کپن تخفیف اعمالی روی فاکتور' },
      { name: 'tracking_number', type: 'VARCHAR(40)', modifiers: 'UNIQUE NULLABLE', desc: 'کد مرسوله شرکت پست یا تیپا‌اکسپرس' },
      { name: 'destination_address_id', type: 'UUID', modifiers: 'NULLABLE', desc: 'نشانی ارسالی منتخب در نقشه' },
      { name: 'created_at', type: 'TIMESTAMP', modifiers: 'DEFAULT CURRENT_TIMESTAMP', desc: 'زمان صدور فاکتور نهایی' }
    ]
  },
  {
    name: 'wallets_ledger',
    desc: 'دفتر ثبت تراکنش‌های درگاه شتاب (ZarinPal, SnappPay, DigiPay) و کیف پولها',
    columns: [
      { name: 'id', type: 'UUID', modifiers: 'PRIMARY KEY DEFAULT gen_random_uuid()', desc: 'کد صورتحساب ریالی شتاب' },
      { name: 'user_id', type: 'UUID', modifiers: 'REFERENCES users(id) ON DELETE CASCADE', desc: 'ذی‌نفع حساب ریالی' },
      { name: 'gateway', type: 'VARCHAR(30)', modifiers: 'NOT NULL', desc: 'درگاه شریک (زرین‌پال، اسنپ‌پی، دیجیب، آپ، تارا)' },
      { name: 'amount', type: 'BIGINT', modifiers: 'NOT NULL', desc: 'مبلغ موازنه مالی تراکنش (مثبت یا منفی فیزیکی)' },
      { name: 'type', type: 'VARCHAR(30)', modifiers: 'CHECK(type IN (\'CHARGE\', \'SETTLEMENT\', \'REFUND\', \'BUY_PAYMENT\'))', desc: 'نوع رویداد بانکی ثبت شده' },
      { name: 'ref_id', type: 'VARCHAR(100)', modifiers: 'UNIQUE NOT NULL', desc: 'کد پیگیری معامله بانکی از شاپرک' },
      { name: 'created_at', type: 'TIMESTAMP', modifiers: 'DEFAULT CURRENT_TIMESTAMP', desc: 'زمان رخداد تراکنش بانکی' }
    ]
  },
  {
    name: 'support_tickets',
    desc: 'مدیریت و بایگانی تیکت‌های پشتیبانی کاربران و غرفه‌داران',
    columns: [
      { name: 'id', type: 'UUID', modifiers: 'PRIMARY KEY DEFAULT gen_random_uuid()', desc: 'شناسه تیکت ثبت شده' },
      { name: 'user_id', type: 'UUID', modifiers: 'REFERENCES users(id) ON DELETE CASCADE', desc: 'کاربر ثبت کننده یا شاکی پرونده' },
      { name: 'title', type: 'VARCHAR(150)', modifiers: 'NOT NULL', desc: 'عنوان تیکت' },
      { name: 'category', type: 'VARCHAR(50)', modifiers: 'NOT NULL', desc: 'دسته‌بندی شکایت (مالی، مرجوعی، غرفه، فنی)' },
      { name: 'status', type: 'VARCHAR(30)', modifiers: 'DEFAULT \'OPEN\' CHECK(status IN (\'OPEN\', \'IN_PROGRESS\', \'RESOLVED\', \'CLOSED\'))', desc: 'وضعیت تخصیص عامل پشتیبانی' },
      { name: 'priority', type: 'VARCHAR(20)', modifiers: 'DEFAULT \'MEDIUM\' CHECK(priority IN (\'LOW\', \'MEDIUM\', \'HIGH\'))', desc: 'اولویت رسیدگی ادمین مرکزی' },
      { name: 'created_at', type: 'TIMESTAMP', modifiers: 'DEFAULT CURRENT_TIMESTAMP', desc: 'تاریخ و زمان ایجاد تیکت' }
    ]
  }
];

const rawPgSqlSchema = `-- ========================================================
-- UseOnline (ir.useonline.shop) Deep-Ecosystem Schema
-- Relational Model optimized for Cloud SQL PostgreSQL
-- ========================================================

-- 0. Enable UUID generation extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Create central App Users Table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    phone_number VARCHAR(15) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE,
    role VARCHAR(20) DEFAULT 'BUYER' CHECK(role IN ('BUYER', 'VENDOR', 'ADMIN')),
    status VARCHAR(20) DEFAULT 'ACTIVE' CHECK(status IN ('ACTIVE', 'BANNED')),
    wallet_balance BIGINT DEFAULT 0 CHECK (wallet_balance >= 0),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Create Multi-Vendor Stores Table
CREATE TABLE stores (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(100) UNIQUE NOT NULL,
    category VARCHAR(50) NOT NULL,
    logo_url VARCHAR(255),
    rating DECIMAL(3,2) DEFAULT 0.00 CHECK (rating BETWEEN 0.00 AND 5.00),
    status VARCHAR(30) DEFAULT 'PENDING_APPROVAL' CHECK(status IN ('PENDING_APPROVAL', 'APPROVED', 'REJECTED')),
    shaba_number VARCHAR(34) NOT NULL,
    commission_rate DECIMAL(5,2) DEFAULT 2.50,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Create Products Table with dynamic specifications support (JSONB)
CREATE TABLE products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    store_id UUID REFERENCES stores(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    english_title VARCHAR(200),
    price BIGINT NOT NULL CHECK (price >= 0),
    original_price BIGINT,
    discount_percentage INT DEFAULT 0 CHECK (discount_percentage BETWEEN 0 AND 100),
    image_url VARCHAR(255) NOT NULL,
    description TEXT,
    specifications JSONB DEFAULT '{}'::jsonb,
    stock INT DEFAULT 0 CHECK (stock >= 0),
    video_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index on catalog search and json specifications
CREATE INDEX idx_products_search ON products USING gym_trgm(title);
CREATE INDEX idx_products_specs ON products USING gin(specifications);

-- 4. Create central Orders Table
CREATE TABLE orders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    buyer_id UUID REFERENCES users(id) ON DELETE RESTRICT,
    status VARCHAR(30) DEFAULT 'PENDING' CHECK(status IN ('PENDING', 'PREPARING', 'SHIPPED', 'DELIVERED')),
    total_price BIGINT NOT NULL CHECK (total_price >= 0),
    discount_code_id VARCHAR(50),
    tracking_number VARCHAR(40) UNIQUE,
    destination_lat DECIMAL(9,6),
    destination_lng DECIMAL(9,6),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Create Order Items Junction Table
CREATE TABLE order_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id UUID REFERENCES orders(id) ON DELETE CASCADE,
    product_id UUID REFERENCES products(id) ON DELETE RESTRICT,
    quantity INT NOT NULL CHECK (quantity > 0),
    unit_price BIGINT NOT NULL CHECK (unit_price >= 0)
);

-- 6. Create banking transaction ledger table 
CREATE TABLE wallets_ledger (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    gateway VARCHAR(30) NOT NULL, -- ZarinPal, SnappPay, DigiPay, Bank Melli, Tara, etc.
    amount BIGINT NOT NULL,
    type VARCHAR(30) CHECK(type IN ('CHARGE', 'SETTLEMENT', 'REFUND', 'BUY_PAYMENT')),
    ref_id VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. Support ticketing table
CREATE TABLE support_tickets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(150) NOT NULL,
    category VARCHAR(50) NOT NULL,
    status VARCHAR(30) DEFAULT 'OPEN' CHECK(status IN ('OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED')),
    priority VARCHAR(20) DEFAULT 'MEDIUM' CHECK(priority IN ('LOW', 'MEDIUM', 'HIGH')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);`;


// Props Interface
interface CodeExplorerProps {
  addLog?: (layer: 'UI' | 'VIEWMODEL' | 'USECASE' | 'REPOSITORY' | 'DATASOURCE', message: string, details?: string) => void;
}

export function CodeExplorer({ addLog }: CodeExplorerProps) {
  // Primary Developer views: KOTLIN, POSTGRES, API_GATEWAY, ROADMAP
  const [primaryTab, setPrimaryTab] = useState<'KOTLIN' | 'POSTGRES' | 'API_GATEWAY' | 'ROADMAP'>('KOTLIN');
  
  // KOTLIN VIEWS STATES
  const [activeFile, setActiveFile] = useState<KotlinFile>(kotlinCodebase[0]);
  const [searchQuery, setSearchQuery] = useState('');
  const [copied, setCopied] = useState(false);
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    domain: true,
    data: true,
    presentation: true,
    config: true
  });

  const toggleFolder = (folder: string) => {
    setExpandedFolders(prev => ({ ...prev, [folder]: !prev[folder] }));
  };

  const filteredCodebase = kotlinCodebase.filter(file => 
    file.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    file.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
    file.description.includes(searchQuery)
  );

  const handleCopyCode = () => {
    navigator.clipboard.writeText(activeFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Basic custom code highlighter for Kotlin/Compose to make it look exceptionally native and beautiful!
  const renderHighlightedCode = (code: string) => {
    const lines = code.split('\n');
    return lines.map((line, idx) => {
      const highlightedLine = line
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        // Kotlin keywords
        .replace(/\b(package|import|data class|class|interface|object|fun|val|val|private|vazirmatn_irregular|override|suspend|return|operator|this|constructor|init)\b/g, '<span class="text-pink-400 font-bold">$1</span>')
        // Jetpack Compose annotations
        .replace(/(@Inject|@HiltAndroidApp|@HiltViewModel|@Composable)/g, '<span class="text-amber-400 font-semibold">$1</span>')
        // Types
        .replace(/\b(String|Int|Long|Float|Boolean|Map|Flow|List|Vendor|Product|UseOnlineApiService|ProductRepository|GetProductsUseCase|HomeViewModel|CartViewModel|UseOnlineShopApp|Screen|NavController|LayoutDirection|Typography|TextStyle|Color)\b/g, '<span class="text-blue-400 font-medium">$1</span>')
        // Double slash comments
        .replace(/(\/\/.*)/g, '<span class="text-slate-500 italic">$1</span>');

      return (
        <div key={idx} className="table-row">
          <span className="table-cell pr-4 text-slate-600 text-right select-none w-8 border-r border-[#1e1e1e]">{(idx + 1)}</span>
          <span className="table-cell pl-4 whitespace-pre" dangerouslySetInnerHTML={{ __html: highlightedLine || ' ' }} />
        </div>
      );
    });
  };

  const handleDownloadProject = () => {
    let readmeText = `====================================================\nUseOnline Android Jetpack Compose Project Export\n====================================================\n\n`;
    readmeText += `Package Name: ir.useonline.shop\n`;
    readmeText += `Architecture: Model-View-ViewModel (MVVM) + Clean Architecture\n`;
    readmeText += `Design Token: Material Design 3 (M3)\n\n`;
    
    kotlinCodebase.forEach(file => {
      readmeText += `----------------------------------------------------\nFile: app/src/main/java/ir/useonline/shop/${file.path}\n----------------------------------------------------\n\n${file.content}\n\n`;
    });

    const blob = new Blob([readmeText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'useonline_android_kotlin_project.txt';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  // --- POSTGRESQL VIEWS STATES ---
  const [selectedDbTable, setSelectedDbTable] = useState<DbTableDefinition>(dbTables[0]);
  const [dbSubTab, setDbSubTab] = useState<'visual' | 'sql'>('visual');
  const [sqliteCopied, setSqliteCopied] = useState(false);

  // --- API GATEWAY TESTER STATES ---
  const [activeApi, setActiveApi] = useState<EcosystemApiEndpoint>(ecosystemEndpoints[0]);
  const [apiParamValues, setApiParamValues] = useState<Record<string, string>>({
    phone_number: '09123456789',
    app_signature: 'USEONLINE9482XJ',
    code: '48231',
    shop_name: 'گالری مدرن مهرآیین',
    category: 'کالای دیجیتال',
    shaba_number: 'IR820170000000123456789012',
    national_code: '0019865431',
    store_id: 'store_3bc84102',
    amount_tomans: '1250000',
    tracking_number: '390198754125',
    title: 'تاخیر در ارسال تبلت',
    description: 'پس از ۴ روز تبلت هنوز تحویل پست نشده است.',
    priority: 'HIGH'
  });
  const [apiResponse, setApiResponse] = useState<any>(null);
  const [apiRunnerLoading, setApiRunnerLoading] = useState(false);

  const handleUpdateParam = (paramName: string, value: string) => {
    setApiParamValues(prev => ({ ...prev, [paramName]: value }));
  };

  const executeApiCall = () => {
    setApiRunnerLoading(true);
    setApiResponse(null);
    
    if (addLog) {
      addLog(
        activeApi.layer, 
        `فراخوانی وب‌سرویس REST [${activeApi.method}] ${activeApi.path}`, 
        `با پارامترهای ارسالی: ${JSON.stringify(apiParamValues)}`
      );
    }

    setTimeout(() => {
      setApiRunnerLoading(false);
      
      // Inject customizable values to mock response
      let customResponse = { ...activeApi.defaultResponse };
      if (activeApi.id === 'send_otp' && customResponse.data) {
        customResponse.data.phone_number_sent = apiParamValues.phone_number;
      } else if (activeApi.id === 'vendor_register' && customResponse.data) {
        customResponse.data.registered_name = apiParamValues.shop_name;
        customResponse.data.category = apiParamValues.category;
      } else if (activeApi.id === 'create_ticket' && customResponse.data) {
        customResponse.data.subject = apiParamValues.title;
        customResponse.data.priority = apiParamValues.priority;
      } else if (activeApi.id === 'track_order' && customResponse.data) {
        customResponse.data.tracking_number = apiParamValues.tracking_number;
      } else if (activeApi.id === 'wallet_settle' && customResponse.data) {
        customResponse.data.amount_processed = Number(apiParamValues.amount_tomans || 0);
      }

      setApiResponse(customResponse);

      if (addLog) {
        addLog(
          'DATASOURCE', 
          `دریافت پاسخ سرور UseOnline (STATUS 200 OK)`, 
          `نتیجه: ${JSON.stringify(customResponse)}`
        );
      }
    }, 1200);
  };

  return (
    <div className="flex flex-col h-full bg-[#141414] border border-[#262626] rounded-3xl overflow-hidden font-mono shadow-xl relative" id="ecosystem-developer-workspace">
      
      {/* 1. TOP ECOSYSTEM TAB CHOOSER BAR */}
      <div className="bg-[#1b1b1b] border-b border-[#2a2a2a] px-4 py-2.5 flex items-center justify-between flex-wrap gap-2 text-xs text-white">
        
        {/* Brand Indicators */}
        <div className="flex items-center gap-2 select-none">
          <div className="w-6 h-6 rounded bg-gradient-to-tr from-pink-600 to-indigo-600 flex items-center justify-center text-[10px] font-black text-white">
            U
          </div>
          <span className="font-extrabold text-slate-200">UseOnline SDK</span>
          <span className="bg-[#141414] px-2 py-0.5 rounded text-[8.5px] font-bold text-slate-500 border border-zinc-800">ir.useonline.shop</span>
        </div>

        {/* Tab Buttons bar */}
        <div className="flex items-center gap-1.5 bg-[#101010] p-1 rounded-xl border border-zinc-800/60 select-none">
          <button
            onClick={() => setPrimaryTab('KOTLIN')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1.5 cursor-pointer ${
              primaryTab === 'KOTLIN' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>📱 سورس کاتلین</span>
          </button>

          <button
            onClick={() => setPrimaryTab('POSTGRES')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1.5 cursor-pointer ${
              primaryTab === 'POSTGRES' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-3.5 h-3.5" />
            <span>🗄️ دیتابیس PostgreSQL</span>
          </button>

          <button
            onClick={() => setPrimaryTab('API_GATEWAY')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1.5 cursor-pointer ${
              primaryTab === 'API_GATEWAY' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>🌐 تست وب‌سرویس API</span>
          </button>

          <button
            onClick={() => setPrimaryTab('ROADMAP')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1.5 cursor-pointer ${
              primaryTab === 'ROADMAP' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>🏁 نقشه راه لانچ</span>
          </button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden min-h-0">
        
        {/* ========================================================
            VIEW 1: KOTLIN CLIENT CODE EXPLORER (ORIGINAL)
            ======================================================== */}
        {primaryTab === 'KOTLIN' && (
          <>
            {/* File Directory Tree Side navigation */}
            <div className="w-64 border-r border-[#222] bg-[#101010] p-4 flex flex-col gap-4 overflow-y-auto shrink-0 select-none text-[11px] text-[#b5b5b5]">
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2.5">پراپرتی پکیج‌ ها</span>
                
                {/* Search Input In IDE */}
                <div className="relative mb-4">
                  <Search className="absolute left-2.5 top-2.5 w-3.5 h-3.5 text-zinc-600" />
                  <input
                    type="text"
                    placeholder="جستجو در سورس اندروید..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-[#181818] border border-zinc-800 rounded-lg pl-8 pr-2.5 py-1.5 focus:outline-none focus:border-blue-500 text-[10px] text-zinc-300"
                  />
                </div>

                {/* Folder 1: Domain */}
                <div className="mb-2">
                  <div 
                    onClick={() => toggleFolder('domain')}
                    className="flex items-center gap-1.5 py-1.5 hover:bg-[#1a1a1a] rounded px-1.5 cursor-pointer text-slate-300"
                  >
                    {expandedFolders.domain ? <FolderOpen className="w-4 h-4 text-blue-400" /> : <Folder className="w-4 h-4 text-blue-400" />}
                    <span className="font-bold">domain (دامنه)</span>
                  </div>
                  {expandedFolders.domain && (
                    <div className="pl-4 flex flex-col gap-0.5 border-l border-[#222] ml-3 mt-1">
                      {filteredCodebase.filter(f => f.layer === 'domain').map(file => (
                        <div
                          key={file.path}
                          onClick={() => setActiveFile(file)}
                          className={`flex items-center gap-1.5 py-1.5 hover:bg-[#1c1c1c] rounded px-2 cursor-pointer transition ${
                            activeFile.path === file.path ? 'bg-[#1e1e1e] text-blue-400 font-bold border-r-2 border-r-blue-400' : ''
                          }`}
                        >
                          <FileCode className="w-3.5 h-3.5 user text-blue-300" />
                          <span>{file.name}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Folder 2: Data */}
                <div className="mb-2">
                  <div 
                    onClick={() => toggleFolder('data')}
                    className="flex items-center gap-1.5 py-1.5 hover:bg-[#1a1a1a] rounded px-1.5 cursor-pointer text-slate-300"
                  >
                    {expandedFolders.data ? <FolderOpen className="w-4 h-4 text-emerald-400" /> : <Folder className="w-4 h-4 text-emerald-400" />}
                    <span className="font-bold">data (مخزن داده)</span>
                  </div>
                  {expandedFolders.data && (
                    <div className="pl-4 flex flex-col gap-0.5 border-l border-[#222] ml-3 mt-1">
                      {filteredCodebase.filter(f => f.layer === 'data').map(file => (
                        <div
                          key={file.path}
                          onClick={() => setActiveFile(file)}
                          className={`flex items-center gap-1.5 py-1.5 hover:bg-[#1c1c1c] rounded px-2 cursor-pointer transition ${
                            activeFile.path === file.path ? 'bg-[#1e1e1e] text-emerald-400 font-bold border-r-2 border-r-emerald-400' : ''
                          }`}
                        >
                          <FileCode className="w-3.5 h-3.5 text-emerald-300" />
                          <span>{file.name}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Folder 3: Presentation UI */}
                <div className="mb-2">
                  <div 
                    onClick={() => toggleFolder('presentation')}
                    className="flex items-center gap-1.5 py-1.5 hover:bg-[#1a1a1a] rounded px-1.5 cursor-pointer text-slate-300"
                  >
                    {expandedFolders.presentation ? <FolderOpen className="w-4 h-4 text-purple-400" /> : <Folder className="w-4 h-4 text-purple-400" />}
                    <span className="font-bold">presentation (رابط کاربری)</span>
                  </div>
                  {expandedFolders.presentation && (
                    <div className="pl-4 flex flex-col gap-0.5 border-l border-[#222] ml-3 mt-1">
                      {filteredCodebase.filter(f => f.layer === 'presentation').map(file => (
                        <div
                          key={file.path}
                          onClick={() => setActiveFile(file)}
                          className={`flex items-center gap-1.5 py-1.5 hover:bg-[#1c1c1c] rounded px-2 cursor-pointer transition ${
                            activeFile.path === file.path ? 'bg-[#1e1e1e] text-purple-400 font-bold border-r-2 border-r-purple-400' : ''
                          }`}
                        >
                          <FileCode className="w-3.5 h-3.5 text-purple-300" />
                          <span>{file.name}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Folder 4: Config info */}
                <div>
                  <div 
                    onClick={() => toggleFolder('config')}
                    className="flex items-center gap-1.5 py-1.5 hover:bg-[#1a1a1a] rounded px-1.5 cursor-pointer text-slate-300"
                  >
                    {expandedFolders.config ? <FolderOpen className="w-4 h-4 text-amber-500" /> : <Folder className="w-4 h-4 text-amber-500" />}
                    <span className="font-bold">config (تنظیمات هیلت)</span>
                  </div>
                  {expandedFolders.config && (
                    <div className="pl-4 flex flex-col gap-0.5 border-l border-[#222] ml-3 mt-1">
                      {filteredCodebase.filter(f => f.layer === 'config').map(file => (
                        <div
                          key={file.path}
                          onClick={() => setActiveFile(file)}
                          className={`flex items-center gap-1.5 py-1.5 hover:bg-[#1c1c1c] rounded px-2 cursor-pointer transition ${
                            activeFile.path === file.path ? 'bg-[#1e1e1e] text-amber-500 font-bold border-r-2 border-r-amber-500' : ''
                          }`}
                        >
                          <FileCode className="w-3.5 h-3.5 text-amber-400" />
                          <span>{file.name}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

              </div>
            </div>

            {/* Code Editor panel area */}
            <div className="flex-1 flex flex-col bg-[#161616] overflow-hidden">
              
              {/* Active doc banner info */}
              <div className="bg-[#1b1b1b] px-4 py-2 flex items-center justify-between text-[11px] text-zinc-400 border-b border-[#222]">
                <div className="flex items-center gap-2">
                  <FileCode className="w-4 h-4 text-blue-400" />
                  <span>app / src / main / java / ir / useonline / shop / {activeFile.path}</span>
                </div>
                
                <div className="flex gap-2">
                  <button
                    onClick={handleDownloadProject}
                    className="flex items-center gap-1 text-[10px] text-blue-400 hover:text-blue-300 bg-blue-500/5 px-2.5 py-1 rounded border border-blue-500/10 active:scale-95 transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                    دانلود کل سورس کاتلین
                  </button>
                  <button
                    onClick={handleCopyCode}
                    className="flex items-center gap-1 text-[10px] text-zinc-300 hover:text-white bg-white/5 px-2.5 py-1 rounded hover:bg-white/10 active:scale-95 transition animate-fade-in"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-green-400" />
                        کپی شد!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        کپی کد
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Persian functional notes */}
              <div className="bg-[#1f1d18] border-b border-yellow-950/20 px-4 py-2.5 text-[10px] text-amber-300/80 leading-normal flex items-start gap-1.5 select-none text-right font-vazir" dir="rtl">
                <span className="text-sm">💡</span>
                <span>{activeFile.description}</span>
              </div>

              {/* IDE coding visual workspace */}
              <div className="flex-1 overflow-auto p-4 text-[12px] leading-relaxed text-[#c5c5c5] font-mono table h-full">
                {renderHighlightedCode(activeFile.content)}
              </div>
            </div>
          </>
        )}

        {/* ========================================================
            VIEW 2: POSTGRESQL DATABASE SCHEMA & MIGRATIONS
            ======================================================== */}
        {primaryTab === 'POSTGRES' && (
          <div className="flex-1 flex flex-col h-full bg-[#121212]">
            
            {/* Top Toolbar: visual vs script */}
            <div className="bg-[#181818] px-4 py-2 flex items-center justify-between border-b border-zinc-800">
              <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1.5 font-vazir" dir="rtl">
                <Database className="w-3.5 h-3.5 text-blue-400" />
                مدل داده‌ای پایگاه داده PostgreSQL (UseOnline cloud architecture)
              </span>

              <div className="bg-[#101010] p-0.5 rounded-lg border border-zinc-800 flex gap-1">
                <button
                  onClick={() => setDbSubTab('visual')}
                  className={`px-3 py-1 text-[10px] font-bold rounded cursor-pointer ${
                    dbSubTab === 'visual' ? 'bg-zinc-800 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  طرح گرافیکی رابطه مدلها
                </button>
                <button
                  onClick={() => setDbSubTab('sql')}
                  className={`px-3 py-1 text-[10px] font-bold rounded cursor-pointer ${
                    dbSubTab === 'sql' ? 'bg-zinc-800 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  اسکریپت SQL ساخت و مهاجرت
                </button>
              </div>
            </div>

            {dbSubTab === 'visual' ? (
              <div className="flex-1 flex overflow-hidden">
                
                {/* Visual Left pane - Table Lists */}
                <div className="w-60 bg-[#101010] border-l border-zinc-800/80 p-3.5 overflow-y-auto shrink-0 flex flex-col gap-1.5 font-vazir text-right" dir="rtl">
                  <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest block mb-2 px-1">تیبل های پایگاه‌داده (۷)</span>
                  
                  {dbTables.map((tab) => (
                    <button
                      key={tab.name}
                      onClick={() => setSelectedDbTable(tab)}
                      className={`w-full text-right p-2.5 rounded-xl text-[10.5px] transition flex items-center justify-between group active:scale-[0.98] ${
                        selectedDbTable.name === tab.name 
                          ? 'bg-indigo-600/10 text-indigo-400 font-black border border-indigo-500/20' 
                          : 'text-slate-400 hover:bg-zinc-900 border border-transparent'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-mono font-bold">{tab.name}</span>
                      </div>
                      <ChevronRight className={`w-3.5 h-3.5 transition ${selectedDbTable.name === tab.name ? 'text-indigo-400 translate-x-0.5' : 'text-slate-600 opacity-0 group-hover:opacity-100'}`} />
                    </button>
                  ))}
                </div>

                {/* Visual Right pane - Column viewer */}
                <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 font-vazir" dir="rtl">
                  
                  {/* Table title card */}
                  <div className="bg-[#18181c] border border-zinc-800 p-4 rounded-2.5xl flex flex-col gap-1">
                    <span className="text-[9px] font-bold text-indigo-400 uppercase font-mono select-none">TABLE STRUCTURE</span>
                    <h3 className="text-sm font-black text-white font-mono flex items-center gap-1.5">
                      {selectedDbTable.name}
                      <span className="bg-blue-500/10 text-blue-400 text-[8.5px] px-2 py-0.5 rounded-md border border-blue-500/20 font-bold font-sans">
                        SQL Schema
                      </span>
                    </h3>
                    <p className="text-[10.5px] text-slate-400 leading-normal mt-1">{selectedDbTable.desc}</p>
                  </div>

                  {/* Columns listing */}
                  <div className="bg-[#101010] border border-zinc-800/60 rounded-3xl overflow-hidden shadow-md">
                    <div className="bg-[#161616] px-4 py-2 border-b border-zinc-800 grid grid-cols-12 text-[10.5px] text-slate-500 font-bold">
                      <div className="col-span-3 text-right">عنوان ستون (Column)</div>
                      <div className="col-span-2 text-right">نوع داده (Type)</div>
                      <div className="col-span-3 text-right">قیود و کلیدها (Modifiers)</div>
                      <div className="col-span-4 text-right">توضیحات عملکرد فیلد</div>
                    </div>

                    <div className="divide-y divide-zinc-800/40">
                      {selectedDbTable.columns.map((col, index) => (
                        <div key={index} className="px-4 py-3.5 grid grid-cols-12 text-[10.5px] items-center hover:bg-zinc-900/40 transition">
                          {/* Name */}
                          <div className="col-span-3 text-right font-mono font-bold text-indigo-300">{col.name}</div>
                          
                          {/* Type */}
                          <div className="col-span-2 text-right font-mono text-blue-400 text-[10px]">{col.type}</div>
                          
                          {/* Modifiers */}
                          <div className="col-span-3 text-right font-mono text-slate-400 text-[9.5px] leading-relaxed pr-1">
                            {col.modifiers.includes('PRIMARY KEY') ? (
                              <span className="bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 px-1.5 py-0.5 rounded-md text-[8.5px] font-bold mr-1">
                                🔑 PK
                              </span>
                            ) : null}
                            {col.modifiers.includes('REFERENCES') ? (
                              <span className="bg-purple-500/10 text-purple-400 border border-purple-500/20 px-1.5 py-0.5 rounded-md text-[8.5px] font-bold mr-1">
                                🔗 FK
                              </span>
                            ) : null}
                            <span className="block mt-1 text-[9px] text-slate-500 select-all">{col.modifiers}</span>
                          </div>
                          
                          {/* Description */}
                          <div className="col-span-4 text-right text-slate-300 leading-normal font-sans text-[10px]">{col.desc}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Schema reference tips */}
                  <div className="bg-yellow-950/5 border border-yellow-500/10 p-3.5 rounded-2xl flex items-start gap-2.5 text-right mt-1">
                    <span className="text-sm">🧬</span>
                    <div>
                      <span className="text-[10px] font-black text-amber-500">نکته کلیدی پیوند چندفروشگاهی مغرور:</span>
                      <p className="text-[9.5px] text-slate-400 leading-normal mt-0.5">
                        فلوهای استعلام به انبار <span className="font-mono text-[9px] text-slate-200">products</span> به طور مستقیم به <span className="font-mono text-[9px] text-slate-200">stores</span> ارجاع دارند. کمیسیون تخصیص یافته به ازای هر غرفه به تفکیک تراکنش در درگاه شتاب ثبت شده و در جدول تخصصی <span className="font-mono text-[9px] text-slate-200">wallets_ledger</span> مهار می‌گردد.
                      </p>
                    </div>
                  </div>

                </div>
              </div>
            ) : (
              // Raw SQL Script Code block
              <div className="flex-1 flex flex-col overflow-hidden">
                <div className="bg-[#1b1b1b] px-4 py-2 border-b border-zinc-800 flex items-center justify-between">
                  <span className="text-[10px] text-zinc-500 font-mono">schema.sql (PostgreSQL, Drizzle-compatible)</span>
                  
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(rawPgSqlSchema);
                      setSqliteCopied(true);
                      setTimeout(() => setSqliteCopied(false), 2000);
                    }}
                    className="flex items-center gap-1 text-[10.5px] text-zinc-300 hover:text-white bg-white/5 px-2.5 py-1 rounded"
                  >
                    {sqliteCopied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{sqliteCopied ? 'کپی شد!' : 'کپی کل اسکریپت'}</span>
                  </button>
                </div>

                <div className="flex-1 overflow-auto p-4 bg-[#141414] font-mono text-[11px] text-slate-300 leading-relaxed text-left" dir="ltr">
                  <pre>{rawPgSqlSchema}</pre>
                </div>
              </div>
            )}

          </div>
        )}

        {/* ========================================================
            VIEW 3: WEB REST API GATEWAY & ENDPOINT TESTER
            ======================================================== */}
        {primaryTab === 'API_GATEWAY' && (
          <div className="flex-1 flex overflow-hidden">
            
            {/* Sidebar with API Gateway Routes */}
            <div className="w-64 border-l border-zinc-800 bg-[#101010] p-3 overflow-y-auto shrink-0 flex flex-col gap-3 font-vazir text-right" dir="rtl">
              <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest block px-1">سرویس‌های لجستیک و تراکنش شتاب</span>
              
              <div className="flex flex-col gap-1.5">
                {ecosystemEndpoints.map((end) => (
                  <button
                    key={end.id}
                    onClick={() => {
                      setActiveApi(end);
                      setApiResponse(null);
                    }}
                    className={`w-full text-right p-2.5 rounded-xl text-[10px] transition flex flex-col gap-1 border ${
                      activeApi.id === end.id 
                        ? 'bg-[#18181f] border-indigo-500/40 text-white' 
                        : 'border-transparent hover:bg-zinc-900 text-slate-400'
                    }`}
                  >
                    <div className="flex items-center gap-1.5">
                      <span className={`text-[8px] font-black px-1.5 py-0.5 rounded-md text-white font-mono ${
                        end.method === 'POST' ? 'bg-emerald-600' : 'bg-blue-600'
                      }`}>
                        {end.method}
                      </span>
                      <span className="font-mono font-bold text-slate-200 text-[10px]">{end.path}</span>
                    </div>
                    <span className="text-[9px] text-slate-500 font-bold block mt-0.5">{end.title}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Main Interactive testing playground */}
            <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-4 font-vazir text-right" dir="rtl">
              
              {/* Endpoint summary heading card */}
              <div className="bg-[#18181c] border border-zinc-800 p-4 rounded-2.5xl flex flex-col gap-1.5">
                <div className="flex items-center gap-2">
                  <span className={`text-[9px] font-black px-2 py-0.5 rounded-md text-white font-mono ${
                    activeApi.method === 'POST' ? 'bg-emerald-600' : 'bg-blue-600'
                  }`}>
                    {activeApi.method}
                  </span>
                  <span className="font-mono font-black text-white text-xs block">{activeApi.path}</span>
                </div>
                <h3 className="text-xs font-black text-slate-100 mt-1">{activeApi.title}</h3>
                <p className="text-[10px] text-slate-400 leading-normal">{activeApi.desc}</p>
              </div>

              {/* API Sandbox Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                
                {/* Inputs Pane */}
                <div className="bg-[#101010] border border-zinc-800/80 rounded-2.5xl p-4 flex flex-col justify-between gap-4">
                  <div className="space-y-3">
                    <span className="text-[10px] font-black text-zinc-400 block uppercase border-b border-zinc-800 pb-2">پارامترهای بدنه درخواست (PAYLOAD)</span>
                    
                    {activeApi.params.map(p => (
                      <div key={p.name} className="flex flex-col gap-1">
                        <label className="text-[10px] block font-bold text-slate-300 font-mono">
                          {p.name}
                          {p.isRequired ? <span className="text-red-500 mr-1">*</span> : <span className="text-slate-500 mr-1">(اختیاری)</span>}
                        </label>
                        <input
                          type={p.type === 'number' ? 'number' : 'text'}
                          value={apiParamValues[p.name] !== undefined ? apiParamValues[p.name] : p.defaultValue}
                          onChange={(e) => handleUpdateParam(p.name, e.target.value)}
                          placeholder={p.placeholder}
                          className="w-full bg-[#18181c] border border-zinc-800/80 rounded-xl px-3 py-2 text-[10.5px] font-mono text-slate-200 focus:outline-none focus:border-indigo-500 text-left"
                          dir="ltr"
                        />
                      </div>
                    ))}
                  </div>

                  <button
                    onClick={executeApiCall}
                    disabled={apiRunnerLoading}
                    className="w-full bg-indigo-600 hover:bg-indigo-700 disabled:bg-zinc-800 disabled:text-slate-500 text-white font-black py-2.5 px-4 rounded-xl cursor-pointer active:scale-95 transition flex items-center justify-center gap-1.5 shadow-md shadow-indigo-600/10 text-xs"
                  >
                    {apiRunnerLoading ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>درخواست در حال ترانزیت...</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 fill-white" />
                        <span>شبیه‌سازی و تست فراخوانی زنده</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Outputs Panel (JSON client response) */}
                <div className="bg-[#0e0e0e] border border-zinc-800/80 rounded-2.5xl p-4 flex flex-col gap-2 relative min-h-60 h-full overflow-hidden">
                  <div className="flex items-center justify-between border-b border-zinc-800 pb-2 select-none">
                    <span className="text-[10px] font-black text-zinc-500 uppercase font-mono">JSON RESPONSE STREAM</span>
                    <span className="text-[8px] bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-bold px-2 py-0.5 rounded-full font-mono">
                      HTTP 200 OK
                    </span>
                  </div>

                  <div className="flex-1 overflow-auto font-mono text-[10px] text-zinc-300 leading-normal text-left pt-1" dir="ltr">
                    {apiResponse ? (
                      <pre className="text-emerald-400 whitespace-pre-wrap">{JSON.stringify(apiResponse, null, 2)}</pre>
                    ) : apiRunnerLoading ? (
                      <div className="h-full flex flex-col items-center justify-center gap-1.5 text-slate-500">
                        <RefreshCw className="w-4 h-4 animate-spin text-indigo-500" />
                        <span className="text-[9.5px]">Waiting for server response...</span>
                      </div>
                    ) : (
                      <div className="h-full flex flex-col items-center justify-center text-slate-500 text-center p-8 select-none font-vazir">
                        <Terminal className="w-6 h-6 text-zinc-700 mb-1" />
                        <span className="text-[10px]">روی دکمه تست کلیک کنید تا تراکنش وب‌سرویس آغاز شود.</span>
                        <span className="text-[9px] text-slate-600 mt-1">تراکنش‌ها به صورت مستقیم به لایه‌ ردیاب وب دسکشن فرستاده می‌شوند.</span>
                      </div>
                    )}
                  </div>
                </div>

              </div>
              
              {/* Trace details warning info */}
              <div className="bg-indigo-950/5 border border-indigo-500/10 p-3 rounded-xl text-[9px] leading-relaxed text-slate-400 mt-1">
                📌 مکانیزم وب‌سرویس‌های فوق کلاینت اندروید <span className="font-mono text-[10px] text-[#818cf8]">ir.useonline.shop</span> را به سرورهای یکپارچه متصل می‌نماید. کلیه استعلام‌ها با امضای هدر احراز هویت خریداران همراه بوده و تراکنش‌های مالی به کاتالوگ امن دیتابیس لوکال Room ارجاع داده می‌شوند.
              </div>

            </div>
          </div>
        )}

        {/* ========================================================
            VIEW 4: ROADMAP & LAUNCH TIMELINE GANTT
            ======================================================== */}
        {primaryTab === 'ROADMAP' && (
          <div className="flex-1 flex flex-col h-full bg-[#121212] overflow-y-auto p-4 sm:p-5 font-vazir text-right" dir="rtl">
            <div className="bg-[#18181c] border border-zinc-800 p-4 rounded-2.5xl mb-5 flex flex-col gap-1.5">
              <span className="text-[9px] font-bold text-indigo-400 uppercase font-mono tracking-wider select-none">ARCHITECTURE IMPLEMENTATION ROADMAP</span>
              <h3 className="text-sm font-black text-white">برنامه زمان‌بندی و گام‌های راه‌اندازی اکوسیستم UseOnline</h3>
              <p className="text-[10px] text-slate-400 leading-normal">
                برقراری فازهای اجرای فنی از استقرار دیتابیس و هسته کلاینت تا دریافت استانداردهای کافه بازار و راه‌اندازی پنل‌های وب ادمین و فروشنده.
              </p>
            </div>

            {/* Roadmap Timelines list */}
            <div className="space-y-4 max-w-3xl mx-auto w-full pb-8 select-none">
              
              {/* Step 1 */}
              <div className="relative pl-4 border-r-2 border-indigo-600/30 pr-6 pb-2">
                <span className="absolute -right-2 top-0.5 w-3.5 h-3.5 rounded-full bg-indigo-600 border-4 border-[#121212] flex items-center justify-center" />
                <div className="bg-[#16161c] border border-indigo-500/10 p-4 rounded-2xl flex flex-col gap-1">
                  <span className="text-[8.5px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2 py-0.5 rounded-full font-bold w-fit mb-1 font-sans">
                    هفته اول (روز ۱ تا ۷)
                  </span>
                  <h4 className="text-xs font-black text-white">فاز ۱: استقرار دیتابیس ابری و هاب احراز پیامکی OTP</h4>
                  <p className="text-[10px] text-slate-400 leading-relaxed mt-1">
                    راه‌اندازی سرویس‌های پایه دیتابیس PostgreSQL در Cloud SQL، پیاده‌سازی گیت‌وی پیامکی کاوه نگار جهت احراز هویت SMS OTP مشتریان و غرفه‌داران، و ساخت پایه‌ی امنیتی توکن‌های منقضی‌شونده JWT.
                  </p>
                  <div className="flex flex-wrap gap-1.5 mt-2 text-[8px] text-slate-400">
                    <span className="bg-[#111] px-2 py-1 rounded">PostgreSQL setup</span>
                    <span className="bg-[#111] px-2 py-1 rounded">SMS Gateway API</span>
                    <span className="bg-[#111] px-2 py-1 rounded">JWT Token Generator</span>
                  </div>
                </div>
              </div>

              {/* Step 2 */}
              <div className="relative pl-4 border-r-2 border-indigo-600/30 pr-6 pb-2">
                <span className="absolute -right-2 top-0.5 w-3.5 h-3.5 rounded-full bg-indigo-600 border-4 border-[#121212] flex items-center justify-center" />
                <div className="bg-[#16161c] border border-[#212936] p-4 rounded-2xl flex flex-col gap-1">
                  <span className="text-[8.5px] bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2 py-0.5 rounded-full font-bold w-fit mb-1 font-sans">
                    هفته دوم و سوم (روز ۸ تا ۲۰)
                  </span>
                  <h4 className="text-xs font-black text-white">فاز ۲: معماری تمیز کلاینت اندروید (Jetpack Compose SDK)</h4>
                  <p className="text-[10px] text-slate-400 leading-relaxed mt-1">
                    فرم‌ولاسیون معماری Clean با رویکرد MVVM در اندروید استودیو به کمک گریدل کاتلین-دی‌اس‌ال. تزریق وابستگی پایدار هیلت (Hilt)، ساختار دیتابیس بومی آفلاین ROOM و واکشی اطلاعات لوکال از Retrofit API.
                  </p>
                  <div className="flex flex-wrap gap-1.5 mt-2 text-[8px] text-slate-400">
                    <span className="bg-[#111] px-2 py-1 rounded">Hilt DI</span>
                    <span className="bg-[#111] px-2 py-1 rounded">Room Database</span>
                    <span className="bg-[#111] px-2 py-1 rounded">Retrofit HTTP</span>
                  </div>
                </div>
              </div>

              {/* Step 3 */}
              <div className="relative pl-4 border-r-2 border-indigo-600/30 pr-6 pb-2">
                <span className="absolute -right-2 top-0.5 w-3.5 h-3.5 rounded-full bg-indigo-600 border-4 border-[#121212] flex items-center justify-center" />
                <div className="bg-[#16161c] border border-[#212936] p-4 rounded-2xl flex flex-col gap-1">
                  <span className="text-[8.5px] bg-purple-500/10 text-purple-400 border border-purple-500/20 px-2 py-0.5 rounded-full font-bold w-fit mb-1 font-sans">
                    هفته چهارم و پنجم (روز ۲۱ تا ۳۵)
                  </span>
                  <h4 className="text-xs font-black text-white">فاز ۳: پنل وب دسکشن غرفه‌داران چندفروشگاهی (UseOnline Merchant)</h4>
                  <p className="text-[10px] text-slate-400 leading-relaxed mt-1">
                    راه‌اندازی داشبورد وب واکنش‌گرا مختص غرفه‌داران جهت ثبت مشخصات تجاری، تایید شبای بانکی، مدیریت زنده موجودی انبار، آمارگیری فروش متمرکز، درخواست تسویه‌حساب دوره‌ای و تیکت‌گذاری مشتریان.
                  </p>
                  <div className="flex flex-wrap gap-1.5 mt-2 text-[8px] text-slate-400">
                    <span className="bg-[#111] px-2 py-1 rounded">Store Logistics</span>
                    <span className="bg-[#111] px-2 py-1 rounded">Live Stock Manager</span>
                    <span className="bg-[#111] px-2 py-1 rounded">Payment Ledger</span>
                  </div>
                </div>
              </div>

              {/* Step 4 */}
              <div className="relative pl-4 border-r-2 border-indigo-600/30 pr-6 pb-2">
                <span className="absolute -right-2 top-0.5 w-3.5 h-3.5 rounded-full bg-indigo-600 border-4 border-[#121212] flex items-center justify-center" />
                <div className="bg-[#16161c] border border-[#212936] p-4 rounded-2xl flex flex-col gap-1">
                  <span className="text-[8.5px] bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full font-bold w-fit mb-1 font-sans">
                    هفته ششم (روز ۳۶ تا ۴۵)
                  </span>
                  <h4 className="text-xs font-black text-white">فاز ۴: پنل ادمین مرکزی وب یوزآنلاین شاپ</h4>
                  <p className="text-[10px] text-slate-400 leading-relaxed mt-1">
                    طراحی کنسول نظارتی ادمین جهت تایید صنف و غرفه‌داران جدید، مهار مالی میزان پورسانت‌های بازارچه (Commission System)، پایش گزارش‌های تخلف خریداران، و پوش نوتیفیکیشن همگانی.
                  </p>
                  <div className="flex flex-wrap gap-1.5 mt-2 text-[8px] text-slate-400">
                    <span className="bg-[#111] px-2 py-1 rounded">Commission Manager</span>
                    <span className="bg-[#111] px-2 py-1 rounded">Abuse Reports Portal</span>
                    <span className="bg-[#111] px-2 py-1 rounded">Push Campaign Hub</span>
                  </div>
                </div>
              </div>

              {/* Step 5 */}
              <div className="relative pl-4 border-r-2 border-indigo-600/30 pr-6 pb-2">
                <span className="absolute -right-2 top-0.5 w-3.5 h-3.5 rounded-full bg-indigo-600 border-4 border-[#121212] flex items-center justify-center" />
                <div className="bg-[#16161c] border border-[#212936] p-4 rounded-2xl flex flex-col gap-1">
                  <span className="text-[8.5px] bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-full font-bold w-fit mb-1 font-sans">
                    هفته هفتم (روز ۴۶ تا ۵۲)
                  </span>
                  <h4 className="text-xs font-black text-white">فاز ۵: تلفیق درگاه‌های پرداخت هوشمند شتاب</h4>
                  <p className="text-[10px] text-slate-400 leading-relaxed mt-1">
                    اتصال SDK بازارچه‌های ریالی برای پرداخت‌های همه‌جانبه زرین‌پال، اسنپ‌پی (پرداخت قسطی دیجی‌شهر)، دیجی‌پی، آساند، آپ و تارا همراه با مهار تراکنشهای چند غرفه‌ای جهت توزیع ریالی وجوه.
                  </p>
                  <div className="flex flex-wrap gap-1.5 mt-2 text-[8px] text-slate-400">
                    <span className="bg-[#111] px-2 py-1 rounded">SnappPay gateway</span>
                    <span className="bg-[#111] px-2 py-1 rounded">ZarinPal SDK</span>
                    <span className="bg-[#111] px-2 py-1 rounded">Direct settlement</span>
                  </div>
                </div>
              </div>

              {/* Step 6 */}
              <div className="relative pl-4 pr-6">
                <span className="absolute -right-2 top-0.5 w-3.5 h-3.5 rounded-full bg-zinc-800 border-4 border-[#121212] flex items-center justify-center" />
                <div className="bg-[#1c1c24] border border-indigo-500/20 p-4 rounded-2xl flex flex-col gap-1">
                  <span className="text-[8.5px] bg-amber-500/10 text-amber-500 border border-amber-500/20 px-2 py-0.5 rounded-full font-bold w-fit mb-1 font-sans">
                    هفته هشتم (روز ۵۳ تا ۶۰)
                  </span>
                  <h4 className="text-xs font-black text-slate-100 flex items-center gap-1.5">
                    فاز ۶: تست نفوذ کانتینر، بهینه‌سازی کاتلین و آماده‌سازی انتشار
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  </h4>
                  <p className="text-[10px] text-slate-400 leading-relaxed mt-1">
                    فعال‌سازی سیستم پروگارد (Proguard) و کدگذاری متد کلاس‌ها، تاییدیه SSL Certificate Pinning، تست گوشی‌های دستکاری‌شده (Rootbeer Security)، و بارگذاری نهایی فایل APK در سرورهای کافه‌بازار و گوگل‌پلی.
                  </p>
                  <div className="flex flex-wrap gap-1.5 mt-2 text-[8px] text-slate-400">
                    <span className="bg-[#111] px-2 py-1 rounded">Proguard Protection</span>
                    <span className="bg-[#111] px-2 py-1 rounded">SSL Pinning</span>
                    <span className="bg-[#111] px-2 py-1 rounded">CafelBazaar Publish</span>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
}
