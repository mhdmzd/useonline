import React, { useState, useRef, useEffect } from 'react';
import { ZoomIn, ZoomOut, Move, Maximize2, RefreshCw } from 'lucide-react';

interface ZoomableImageProps {
  src: string;
  alt: string;
  addLog?: (layer: 'UI' | 'VIEWMODEL' | 'REPOSITORY' | 'DATASOURCE', message: string, details: string) => void;
}

export function ZoomableImage({ src, alt, addLog }: ZoomableImageProps) {
  const [scale, setScale] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState(false);
  const [isPinching, setIsPinching] = useState(false);
  const [showTooltip, setShowTooltip] = useState(true);

  const containerRef = useRef<HTMLDivElement>(null);
  const startPanRef = useRef({ x: 0, y: 0 });
  const initialDistanceRef = useRef(0);
  const initialScaleRef = useRef(1);

  // Auto-hide helper tooltip after 4 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowTooltip(false);
    }, 4000);
    return () => clearTimeout(timer);
  }, []);

  const toPersianDigits = (num: number | string) => {
    const id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/[0-9]/g, (w) => id[parseInt(w)]);
  };

  // Helper distance calculator for pinch-to-zoom
  const getTouchesDistance = (touch1: Touch, touch2: Touch) => {
    return Math.sqrt(
      Math.pow(touch1.clientX - touch2.clientX, 2) +
      Math.pow(touch1.clientY - touch2.clientY, 2)
    );
  };

  // Touch handlers
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      e.stopPropagation();
      const dist = getTouchesDistance(e.touches[0], e.touches[1]);
      initialDistanceRef.current = dist;
      initialScaleRef.current = scale;
      setIsPinching(true);
      if (addLog) {
        addLog('UI', 'آغاز ژست حرکتی زوم چندانگشتی (Pinch Initialized)', `فاصله اولیه: ${Math.round(dist)}px`);
      }
    } else if (e.touches.length === 1 && scale > 1) {
      setIsPanning(true);
      startPanRef.current = {
        x: e.touches[0].clientX - pan.x,
        y: e.touches[0].clientY - pan.y
      };
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && isPinching) {
      e.preventDefault();
      e.stopPropagation();
      const dist = getTouchesDistance(e.touches[0], e.touches[1]);
      if (initialDistanceRef.current === 0) return;
      
      const factor = dist / initialDistanceRef.current;
      let newScale = initialScaleRef.current * factor;
      
      // Boundaries
      newScale = Math.max(1, Math.min(3.5, newScale));
      setScale(newScale);

      if (newScale === 1) {
        setPan({ x: 0, y: 0 });
      }
    } else if (e.touches.length === 1 && isPanning && scale > 1) {
      e.preventDefault();
      const newX = e.touches[0].clientX - startPanRef.current.x;
      const newY = e.touches[0].clientY - startPanRef.current.y;
      
      // Calculate bounds limits relative to container size and scale
      const limitX = (scale - 1) * 120;
      const limitY = (scale - 1) * 80;
      
      setPan({
        x: Math.max(-limitX, Math.min(limitX, newX)),
        y: Math.max(-limitY, Math.min(limitY, newY))
      });
    }
  };

  const handleTouchEnd = () => {
    setIsPinching(false);
    setIsPanning(false);
    
    // Smooth rebound and recovery if scaled down too much
    if (scale < 1.05) {
      handleReset();
    }
  };

  // Mouse handlers (Desktop)
  const handleMouseDown = (e: React.MouseEvent) => {
    if (scale <= 1) return;
    e.preventDefault();
    setIsPanning(true);
    startPanRef.current = {
      x: e.clientX - pan.x,
      y: e.clientY - pan.y
    };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isPanning || scale <= 1) return;
    e.preventDefault();
    const newX = e.clientX - startPanRef.current.x;
    const newY = e.clientY - startPanRef.current.y;
    
    const limitX = (scale - 1) * 150;
    const limitY = (scale - 1) * 100;
    
    setPan({
      x: Math.max(-limitX, Math.min(limitX, newX)),
      y: Math.max(-limitY, Math.min(limitY, newY))
    });
  };

  const handleMouseUpOrLeave = () => {
    setIsPanning(false);
  };

  // Mouse wheel zoom support
  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomIntensity = 0.15;
    let newScale = scale + (e.deltaY < 0 ? zoomIntensity : -zoomIntensity);
    newScale = Math.max(1, Math.min(3.5, newScale));
    
    setScale(newScale);
    if (newScale === 1) {
      setPan({ x: 0, y: 0 });
    }
    
    if (addLog && Math.abs(newScale - scale) > 0.01) {
      addLog('UI', `تغییر مقدار بزرگنمایی با اسکرول ماوس به ${newScale.toFixed(1)}x`, 'رویداد Wheel');
    }
  };

  // Double tap to quick zoom toggle
  const handleDoubleTap = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (scale > 1.2) {
      handleReset();
      if (addLog) {
        addLog('UI', 'ریست بزرگنمایی کالا از راه دابل‌کلیک', 'Zoom Reset to 1.0x');
      }
    } else {
      setScale(2.2);
      setPan({ x: 0, y: 0 });
      if (addLog) {
        addLog('UI', 'بزرگنمایی سریع تصویر کالا به ۲.۲ برابر با دابل‌کلیک', 'Quick Scale to 2.2x');
      }
    }
  };

  // Zoom controllers buttons
  const handleStepZoom = (zoomIn: boolean) => {
    let newScale = scale + (zoomIn ? 0.4 : -0.4);
    newScale = Math.max(1, Math.min(3.5, newScale));
    setScale(newScale);
    if (newScale === 1) {
      setPan({ x: 0, y: 0 });
    }
    if (addLog) {
      addLog('UI', `کلیک دکمه زوم: تنظیم روی ${newScale.toFixed(1)}x`, 'manual buttons');
    }
  };

  const handleReset = () => {
    setScale(1);
    setPan({ x: 0, y: 0 });
  };

  return (
    <div 
      ref={containerRef}
      className="relative w-full h-44 rounded-3xl overflow-hidden bg-slate-100 touch-none select-none border border-slate-100 shadow-inner group"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onTouchCancel={handleTouchEnd}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUpOrLeave}
      onMouseLeave={handleMouseUpOrLeave}
      onWheel={handleWheel}
      onDoubleClick={handleDoubleTap}
    >
      {/* Zoomable Image Element */}
      <img
        src={src}
        alt={alt}
        draggable={false}
        className="w-full h-full object-cover rounded-3xl transition-transform duration-100 ease-out origin-center"
        style={{
          transform: `translate(${pan.x}px, ${pan.y}px) scale(${scale})`,
          cursor: scale > 1 ? 'grab' : 'zoom-in',
        }}
      />

      {/* Grid Pattern Guideline overlay visible when zoomed in */}
      {scale > 1 && (
        <div className="absolute inset-0 pointer-events-none border-2 border-dashed border-blue-500/20 rounded-3xl animate-pulse">
          <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-blue-500/10"></div>
          <div className="absolute left-1/2 top-0 bottom-0 w-[1px] bg-blue-500/10"></div>
        </div>
      )}

      {/* Gesture Controls floating panel */}
      <div className="absolute top-2.5 left-2.5 z-10 flex items-center gap-1.5 transition-all duration-300">
        {scale > 1 && (
          <button
            onClick={(e) => { e.stopPropagation(); handleReset(); }}
            className="w-7 h-7 rounded-lg bg-white/90 backdrop-blur-md border border-slate-200/60 shadow flex items-center justify-center text-red-600 active:scale-95 transition"
            title="بازنشانی زوم"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        )}
        <button
          onClick={(e) => { e.stopPropagation(); handleStepZoom(true); }}
          className="w-7 h-7 rounded-lg bg-white/90 backdrop-blur-md border border-slate-200/60 shadow flex items-center justify-center text-slate-700 hover:text-blue-600 active:scale-95 transition"
          title="بزرگنمایی"
        >
          <ZoomIn className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); handleStepZoom(false); }}
          className="w-7 h-7 rounded-lg bg-white/90 backdrop-blur-md border border-slate-200/60 shadow flex items-center justify-center text-slate-700 hover:text-blue-600 active:scale-95 transition"
          title="کوچک‌نمایی"
        >
          <ZoomOut className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Persistent Scale Value read-out overlay */}
      {scale > 1 && (
        <div className="absolute bottom-2.5 left-2.5 bg-black/60 backdrop-blur-sm px-2 py-1 rounded-lg text-white font-black text-[8px] flex items-center gap-1 select-none font-vazir z-10">
          <Maximize2 className="w-3 h-3 text-blue-400" />
          <span>بزرگنمایی: %{toPersianDigits(Math.round(scale * 100))}</span>
        </div>
      )}

      {/* Helper User Prompt Tooltip */}
      {showTooltip && scale === 1 && (
        <div className="absolute inset-x-0 bottom-2.5 flex justify-center px-4 animate-bounce pointer-events-none">
          <div className="bg-black/75 backdrop-blur-sm text-[8px] text-white font-bold py-1 px-3 border border-white/10 rounded-full flex items-center gap-1 font-vazir">
            <Move className="w-3 h-3 text-blue-400 animate-pulse" />
            <span>برای بزرگنمایی فاصله انگشتان را بیشتر کنید یا دابل‌کلیک نمایید</span>
          </div>
        </div>
      )}

      {/* Dragging instruction label when zoomed in */}
      {scale > 1.05 && (
        <div className="absolute top-2.5 right-24 bg-blue-600/90 text-white font-semibold text-[7px] py-1 px-2.5 rounded-full flex items-center gap-1 z-10 select-none animate-fade-in font-vazir">
          <Move className="w-2.5 h-2.5 animate-bounce" />
          <span>می‌توانید تصویر را بکشید تا جزئیات را مشاهده کنید</span>
        </div>
      )}
    </div>
  );
}
