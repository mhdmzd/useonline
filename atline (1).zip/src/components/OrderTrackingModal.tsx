import React, { useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, MapPin, Truck, Package, Clock, CheckCircle2, ChevronRight, 
  HelpCircle, Sparkles, Navigation, ShieldCheck, RefreshCw, Layers 
} from 'lucide-react';
import { Order, ArchLog, UserAddress } from '../types';

interface OrderTrackingModalProps {
  order: Order | null;
  onClose: () => void;
  addresses: UserAddress[];
  activeAddressId: string;
  addLog: (layer: ArchLog['layer'], message: string, details: string) => void;
  onUpdateOrderStatus?: (orderId: string, nextStatus: Order['status']) => void;
}

export function OrderTrackingModal({
  order,
  onClose,
  addresses,
  activeAddressId,
  addLog,
  onUpdateOrderStatus,
}: OrderTrackingModalProps) {
  if (!order) return null;

  // Find active address or default to first
  const destinationAddress = useMemo(() => {
    const active = addresses.find(a => a.id === activeAddressId);
    if (active) return active;
    if (addresses.length > 0) return addresses[0];
    return {
      title: 'آدرس منتخب',
      receiverName: 'کاربر یوزآنلاین',
      phoneNumber: '۰۹۱۲۳۴۵۶۷۸۹',
      province: 'تهران',
      city: 'تهران',
      details: 'اتوبان صدر، خیابان قیطریه، کوچه احمدی، پلاک ۱۲، زنگ سوم'
    };
  }, [addresses, activeAddressId]);

  // Generate deterministic mock products based on order ID & total price
  const mockItems = useMemo(() => {
    const items = [];
    const count = order.itemsCount;
    const basePrice = Math.floor(order.totalPrice / count);

    const names = [
      'گوشی موبایل شیائومی Redmi Note 13',
      'ساعت هوشمند امیزفیت اسپرت v4',
      'هدفون بی‌سیم انکر مدل Soundcore Q30',
      'پاوربانک ۲۰۰۰۰ میلی‌آمپر شیائومی',
      'کابل تبدیل دو سر تایپ‌سی یوزشارژ',
      'کیف چرمی محافظ پاسپورت غرفه‌داران'
    ];

    for (let i = 0; i < count; i++) {
      const idx = (parseInt(order.id.replace(/\D/g, '')) + i) % names.length || i;
      items.push({
        id: `item_${order.id}_${i}`,
        name: names[idx],
        quantity: 1,
        price: basePrice,
        image: `https://picsum.photos/seed/${order.id}_${i}/120/120`
      });
    }
    return items;
  }, [order]);

  // Setup the map dimensions and path node coordinates
  // Nodes: 1 (Warehouse), 2 (Sorting Hub), 3 (Local Courier Hub), 4 (Destination Client Address)
  const nodes = useMemo(() => {
    return [
      { id: 1, name: 'انبار مرکزی یوزآنلاین', x: 80, y: 25, desc: 'Tehran Prime Depot', statusLabel: 'مبدا بارگیری' },
      { id: 2, name: 'هاب منطقه‌ای توزیع شتاب', x: 55, y: 55, desc: 'Central Sorting Center', statusLabel: 'مرکز تفکیک' },
      { id: 3, name: 'دفتر پستی توزیع محلی', x: 25, y: 35, desc: 'Local Mail Office', statusLabel: 'آماده تخصیص پیک' },
      { id: 4, name: destinationAddress.title || 'مکانیزم آدرس شما', x: 12, y: 75, desc: destinationAddress.details, statusLabel: 'مقصد نهایی' },
    ];
  }, [destinationAddress]);

  // Determine current position based on Order status
  const currentStatusWeight = useMemo(() => {
    switch (order.status) {
      case 'PENDING': return 1;
      case 'PREPARING': return 2;
      case 'SHIPPED': return 3;
      case 'DELIVERED': return 4;
      default: return 1;
    }
  }, [order.status]);

  // Smooth intermediate coordinate calculations for the moving delivery vehicle
  const courierCoords = useMemo(() => {
    const w = currentStatusWeight;
    if (w === 1) {
      // Exactly at Warehouse (Node 1)
      return { x: nodes[0].x, y: nodes[0].y, rotation: -135 };
    } else if (w === 2) {
      // Between Warehouse (Node 1) and Sorting Hub (Node 2)
      const ratio = 0.5; // Simulate halfway point
      const x = nodes[0].x + (nodes[1].x - nodes[0].x) * ratio;
      const y = nodes[0].y + (nodes[1].y - nodes[0].y) * ratio;
      return { x, y, rotation: -135 };
    } else if (w === 3) {
      // Between Sorting Center (Node 2) and Local Hub (Node 3) or Delivery Courier
      const ratio = 0.65;
      const x = nodes[1].x + (nodes[2].x - nodes[1].x) * ratio;
      const y = nodes[1].y + (nodes[2].y - nodes[1].y) * ratio;
      return { x, y, rotation: 165 };
    } else {
      // Exactly at Destination Client Address (Node 4)
      return { x: nodes[3].x, y: nodes[3].y, rotation: 45 };
    }
  }, [currentStatusWeight, nodes]);

  // Live progress percentage for UI metrics
  const progressPercentage = useMemo(() => {
    switch (order.status) {
      case 'PENDING': return 15;
      case 'PREPARING': return 45;
      case 'SHIPPED': return 75;
      case 'DELIVERED': return 100;
      default: return 0;
    }
  }, [order.status]);

  const toPersianDigits = (num: number | string) => {
    const id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/[0-9]/g, (w) => id[+w]);
  };

  const formatPrice = (price: number) => {
    const formatted = price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return toPersianDigits(formatted);
  };

  const handleNextSimulationStatus = () => {
    if (!onUpdateOrderStatus) return;
    
    let next: Order['status'] = 'PENDING';
    if (order.status === 'PENDING') next = 'PREPARING';
    else if (order.status === 'PREPARING') next = 'SHIPPED';
    else if (order.status === 'SHIPPED') next = 'DELIVERED';
    else if (order.status === 'DELIVERED') next = 'PENDING';

    addLog('UI', `تغییر وضعیت پیگیری سفارش ${order.id} به ${next} در نقشه زنده`, `تغییر لوکیشن متحرک غرفه`);
    addLog('VIEWMODEL', 'بارگذاری مجدد نقاط جغرافیایی در MapViewModel', `انتقال بردار به طول فیزیکی جدید`);
    onUpdateOrderStatus(order.id, next);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4 select-none">
      {/* Background Click Close */}
      <div className="absolute inset-0 z-0" onClick={onClose} />

      {/* Modal Container */}
      <motion.div 
        initial={{ y: '100%', opacity: 0.8 }}
        animate={{ y: 0, opacity: 1 }}
        exit={{ y: '100%', opacity: 0.8 }}
        transition={{ type: 'spring', damping: 28, stiffness: 300 }}
        className="relative z-10 w-full max-w-lg bg-white rounded-t-[2.5rem] sm:rounded-[2rem] shadow-2xl overflow-hidden flex flex-col max-h-[92vh] sm:max-h-[88vh]"
        dir="rtl"
      >
        {/* Decorative Top Pill Slide Indicator */}
        <div className="mx-auto w-12 h-1.5 bg-slate-200 rounded-full my-3 block shrink-0" />

        {/* Modal Header */}
        <div className="px-5 pb-3 border-b border-slate-100 flex items-center justify-between shrink-0">
          <div className="flex flex-col">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-black text-slate-900">رهگیری لایو سفارش {toPersianDigits(order.id)}</h3>
              <span className="text-[9px] bg-slate-900 text-slate-100 px-2 py-0.5 rounded-lg font-mono">
                #{toPersianDigits(order.trackingNumber)}
              </span>
            </div>
            <p className="text-[10px] text-slate-400 mt-1">تضمین توزیع اختصاصی و هوشمند یوزپی بستر شتاب</p>
          </div>
          <button 
            onClick={onClose}
            className="p-2 bg-slate-100 hover:bg-slate-200 rounded-full transition active:scale-90"
          >
            <X className="w-4 h-4 text-slate-600" />
          </button>
        </div>

        {/* Scrollable Content Outer */}
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4 font-vazir text-right pb-10">
          
          {/* 1. MAP CANVAS CARD CONTAINER */}
          <div className="bg-slate-50 border border-slate-100 rounded-[2rem] p-3.5 relative overflow-hidden shadow-emerald-500/5 shadow-sm">
            
            {/* Live Progress Header */}
            <div className="flex items-center justify-between mb-3.5 px-1 z-10 relative">
              <span className="text-[10px] font-black text-slate-900 flex items-center gap-1">
                <Navigation className="w-3.5 h-3.5 text-blue-600 animate-pulse" />
                نقشه چندرشته‌ای موقعیت‌سنجی یوزآنلاین
              </span>
              <span className="bg-blue-50 text-blue-700 text-[9px] px-2 py-0.5 rounded-lg font-black shrink-0">
                گویای {toPersianDigits(progressPercentage)}٪ توزیع
              </span>
            </div>

            {/* Stylized Interactive Map Stage */}
            <div className="w-full h-44 bg-[#eef4f8] rounded-2xl border border-slate-200/60 relative overflow-hidden flex items-center justify-center select-none shadow-inner">
              
              {/* Map grid lines layout */}
              <div className="absolute inset-0 opacity-15" style={{ 
                backgroundImage: 'radial-gradient(#1e3a8a 0.75px, transparent 0.75px)', 
                backgroundSize: '16px 16px' 
              }} />

              {/* Decorative Map Features */}
              {/* River Line */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
                <path d="M-10,80 Q40,110 120,70 T280,105 T450,40" fill="none" stroke="#bae6fd" strokeWidth="8" strokeLinecap="round" opacity="0.6" />
                <path d="M-10,80 Q40,110 120,70 T280,105 T450,40" fill="none" stroke="#e0f2fe" strokeWidth="4" strokeLinecap="round" opacity="0.8" />
              </svg>

              {/* Decorative Parks */}
              <div className="absolute top-[18%] left-[45%] w-10 h-10 bg-emerald-500/10 border border-emerald-500/20 rounded-full blur-xs" />
              <div className="absolute bottom-[22%] left-[18%] w-12 h-8 bg-emerald-500/10 border border-emerald-500/20 rounded-xl blur-xs rotate-12" />

              {/* Draw Vector Connected Track Lines on Map */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
                {/* Dash Base Route */}
                <path 
                  d={`M ${nodes[0].x}% ${nodes[0].y}% L ${nodes[1].x}% ${nodes[1].y}% L ${nodes[2].x}% ${nodes[2].y}% L ${nodes[3].x}% ${nodes[3].y}%`} 
                  fill="none" 
                  stroke="#cbd5e1" 
                  strokeWidth="3.5" 
                  strokeDasharray="6 4" 
                  strokeLinecap="round"
                />
                
                {/* Active Colored Route Tracker Layer */}
                <motion.path 
                  d={`M ${nodes[0].x}% ${nodes[0].y}% L ${nodes[1].x}% ${nodes[1].y}% L ${nodes[2].x}% ${nodes[2].y}% L ${nodes[3].x}% ${nodes[3].y}%`} 
                  fill="none" 
                  stroke="#2563eb" 
                  strokeWidth="3.5" 
                  strokeLinecap="round"
                  initial={{ strokeDasharray: '0 1000' }}
                  animate={{ strokeDasharray: `${progressPercentage} 1000` }}
                  transition={{ duration: 0.8, ease: 'easeOut' }}
                />
              </svg>

              {/* Render Node Pins */}
              {nodes.map((node, nodeIdx) => {
                const isPassed = currentStatusWeight >= node.id;
                const isActive = currentStatusWeight === node.id;

                return (
                  <div 
                    key={node.id}
                    className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center select-none"
                    style={{ left: `${node.x}%`, top: `${node.y}%` }}
                  >
                    {/* Ring Pulse outer */}
                    {isPassed && (
                      <span className={`absolute inline-flex h-6 w-6 rounded-full opacity-60 animate-ping -z-10 ${
                        isActive ? 'bg-blue-400' : 'bg-emerald-300'
                      }`} />
                    )}

                    {/* Small map indicator Pin bubble */}
                    <div className={`w-5 h-5 rounded-full border flex items-center justify-center transition-all duration-300 ${
                      isActive 
                        ? 'bg-blue-600 text-white border-blue-700 shadow-md ring-2 ring-blue-200' 
                        : isPassed
                          ? 'bg-emerald-500 text-white border-emerald-600 shadow-xs'
                          : 'bg-white text-slate-400 border-slate-300 shadow-xs'
                    }`}>
                      {node.id === 1 ? (
                        <Package className="w-2.5 h-2.5" />
                      ) : node.id === 4 ? (
                        <MapPin className="w-2.5 h-2.5" />
                      ) : (
                        <div className="w-1.5 h-1.5 rounded-full bg-current" />
                      )}
                    </div>

                    {/* Highly polished small labels popup on hover/active */}
                    <div className={`mt-1 bg-slate-900/90 text-white text-[6.5px] px-1.5 py-0.5 rounded shadow-sm whitespace-nowrap leading-none transition-all duration-300 ${
                      isActive ? 'opacity-100 scale-100' : 'opacity-65 scale-90'
                    }`}>
                      {node.statusLabel}
                    </div>
                  </div>
                );
              })}

              {/* Dynamic Animated Courier truck icon floating along the route path */}
              <motion.div 
                className="absolute z-30 flex items-center justify-center p-1.5 bg-blue-600 text-white rounded-full shadow-lg border border-blue-700 -translate-x-1/2 -translate-y-1/2 shrink-0 select-none cursor-pointer"
                style={{ left: `${courierCoords.x}%`, top: `${courierCoords.y}%` }}
                animate={{ scale: [1, 1.08, 1] }}
                transition={{ repeat: Infinity, duration: 2.2, ease: 'easeInOut' }}
              >
                <div className="relative">
                  <Truck className="w-3.5 h-3.5" />
                  <span className="absolute -top-1 -right-1 w-2 h-2 bg-amber-400 border border-white rounded-full animate-ping" />
                </div>
              </motion.div>
            </div>

            {/* Simulated Logistics Meta description widget */}
            <div className="mt-3 bg-white p-3 rounded-2xl border border-slate-100/80 flex items-center justify-between text-[9px] gap-2 shadow-xs">
              <div className="flex-1">
                <span className="text-slate-400 font-bold block">موقعیت فعلی مرسوله شما</span>
                <span className="text-slate-800 font-extrabold mt-0.5 block">
                  {nodes[Math.min(currentStatusWeight - 1, 3)].name}
                </span>
                <p className="text-[8px] text-slate-400 leading-normal mt-0.5 max-w-[280px] break-words">
                  {currentStatusWeight === 1 && 'کالا هم‌اکنون در سیستم غرفه‌دار پذیرش شده و آماده صدور فاکتور است.'}
                  {currentStatusWeight === 2 && 'کالا با موفقیت به انبار بزرگ یوزآنلاین انتقال یافته و در صف پردازش بسته‌ها است.'}
                  {currentStatusWeight === 3 && 'مرسوله پستی بارگیری شده و با اتوبار سریع یوزپی در ردیف ارسال توزیع قرار دارد.'}
                  {currentStatusWeight === 4 && 'کالا با موفقیت و ممهور به امضای اصطلاحات تضمینی درب آدرس خریدار تحویل گردید.'}
                </p>
              </div>

              {/* Interactive Status Simulation trigger inside modal */}
              <button
                onClick={handleNextSimulationStatus}
                className="bg-slate-100 hover:bg-blue-50 border border-slate-200/80 hover:border-blue-200 text-blue-600 font-black text-[8px] px-2.5 py-2 rounded-xl active:scale-95 transition flex flex-col items-center justify-center gap-1.5 max-w-[80px] shrink-0 text-center"
                title="شبیه‌ساز گام نقشه"
              >
                <RefreshCw className="w-3.5 h-3.5 text-blue-600 animate-spin-hover" />
                <span>شبیه‌ساز مرسوله</span>
              </button>
            </div>
          </div>

          {/* 2. CHRONOLOGY STEPS (Horizontal check dots) */}
          <div className="bg-white border border-slate-100 rounded-3xl p-4 shadow-xs">
            <h4 className="text-[10px] font-black text-slate-800 mb-3.5 pb-2 border-b border-slate-50 flex items-center justify-between">
              <span>گام‌های تاریخی فاکتور خرید شتاب</span>
              <span className="text-[8px] text-slate-400 font-mono">ESTIMATED LOGS</span>
            </h4>

            {/* Standard Checklist progress log */}
            <div className="relative flex flex-col gap-4.5 pr-4 border-r-2 border-slate-100 text-right">
              {nodes.map((node, idx) => {
                const pointWeight = idx + 1;
                const isPassed = currentStatusWeight >= pointWeight;
                const isActive = currentStatusWeight === pointWeight;

                let logTime = '---';
                if (pointWeight === 1) logTime = order.date;
                else if (pointWeight === 2 && currentStatusWeight >= 2) logTime = '۱۴۰۵/۰۳/۱۷ (۱۴:۲۰)';
                else if (pointWeight === 3 && currentStatusWeight >= 3) logTime = '۱۴۰۵/۰۳/۱۸ (۰۹:۳۰)';
                else if (pointWeight === 4 && currentStatusWeight >= 4) logTime = '۱۴۰۵/۰۳/۱۸ (۱۷:۴۵)';

                return (
                  <div key={node.id} className="relative flex justify-between items-start">
                    {/* Ring dot absolute connector */}
                    <div className={`absolute -right-[23px] top-[4px] w-3 h-3 rounded-full border-2 transition-all duration-300 ${
                      isActive 
                        ? 'bg-blue-600 border-blue-200 scale-125' 
                        : isPassed 
                          ? 'bg-emerald-500 border-emerald-100' 
                          : 'bg-white border-slate-200'
                    }`} />

                    <div className="flex-1 pr-1">
                      <span className={`text-[10px] font-black block transition-all duration-300 ${
                        isActive ? 'text-blue-600 scale-[1.01]' : isPassed ? 'text-slate-800' : 'text-slate-400'
                      }`}>
                        {node.name}
                      </span>
                      <span className="text-[8px] text-slate-400/90 leading-relaxed block mt-0.5">
                        {node.desc}
                      </span>
                    </div>

                    <div className="text-[8.5px] font-mono text-slate-400 shrink-0 text-left pl-1">
                      {toPersianDigits(logTime)}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 3. ORDERED PRODUCTS INVOICE CARD */}
          <div className="bg-white border border-slate-100 rounded-3xl p-4 shadow-xs">
            <h4 className="text-[10px] font-black text-slate-800 mb-3 pb-2 border-b border-slate-50 flex items-center justify-between">
              <span>اقلام خریداری شده فاکتور</span>
              <span className="text-[8px] bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-lg font-black font-sans">
                {toPersianDigits(mockItems.length)} ITEM
              </span>
            </h4>

            <div className="divide-y divide-slate-50">
              {mockItems.map((item) => (
                <div key={item.id} className="py-2.5 flex items-center justify-between gap-3 first:pt-0 last:pb-0">
                  <img 
                    src={item.image} 
                    alt={item.name} 
                    referrerPolicy="no-referrer"
                    className="w-10 h-10 object-cover rounded-xl bg-slate-100 border border-slate-100"
                  />
                  <div className="flex-1 min-w-0 pr-1 text-right">
                    <span className="text-[9.5px] font-bold text-slate-800 block truncate">{item.name}</span>
                    <span className="text-[8px] text-slate-400 block mt-0.5">ثبت شده غرفه‌داران شتاب</span>
                  </div>
                  <div className="text-left shrink-0">
                    <span className="text-[9px] font-extrabold text-slate-900 block">{formatPrice(item.price)} تومان</span>
                    <span className="text-[8px] text-slate-400 block mt-0.5">{toPersianDigits(item.quantity)} عدد</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 4. RECEIVER & DISPATCH INFORMATION DETAILS */}
          <div className="bg-slate-50 border border-slate-150 rounded-3xl p-4 text-[9px] text-slate-600 space-y-2.5">
            <h4 className="text-[10px] font-black text-slate-800 border-b border-slate-200/80 pb-2 mb-2 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              اطلاعات تحویل و آدرس گیرنده سفارش
            </h4>
            
            <div className="flex justify-between items-center text-slate-500">
              <span>تحویل‌گیرنده:</span>
              <span className="font-extrabold text-slate-800">{destinationAddress.receiverName}</span>
            </div>

            <div className="flex justify-between items-center text-slate-500">
              <span>شماره تماس:</span>
              <span className="font-mono font-extrabold text-slate-800" dir="ltr">
                {toPersianDigits(destinationAddress.phoneNumber)}
              </span>
            </div>

            <div className="flex justify-between items-start text-slate-500 gap-3">
              <span className="shrink-0">نشانی دقیق تحویل:</span>
              <span className="font-bold text-slate-850 text-left">
                {destinationAddress.province}، {destinationAddress.city}، {destinationAddress.details}
              </span>
            </div>

            <div className="flex justify-between items-center text-slate-500 border-t border-slate-200/80 pt-2.5">
              <span className="font-black text-slate-900">کل مبلغ پرداختی (تضمین پرداخت شتاب):</span>
              <span className="font-black text-blue-600 text-xs">
                {formatPrice(order.totalPrice)} تومان
              </span>
            </div>
          </div>

        </div>

        {/* Modal Action Footer */}
        <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[8.5px] text-slate-400 font-bold">اتصال لایو با باربر هوایی</span>
          </div>

          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-slate-950 hover:bg-slate-900 text-white font-heavy text-xs rounded-xl cursor-pointer shadow-md shadow-slate-200 hover:shadow-lg transition active:scale-95"
          >
            بستن رهگیری هوشمند
          </button>
        </div>
      </motion.div>
    </div>
  );
}
