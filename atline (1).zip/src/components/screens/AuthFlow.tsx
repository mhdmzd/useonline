import React, { useState, useEffect } from 'react';
import { User, Phone, Mail, Lock, Key, ArrowRight, Eye, EyeOff, RefreshCw, Check } from 'lucide-react';
import { ArchLog } from '../../types';

interface AuthFlowProps {
  onAuthSuccess: (userName: string) => void;
  addLog: (layer: ArchLog['layer'], message: string, details: string) => void;
}

export function AuthFlow({ onAuthSuccess, addLog }: AuthFlowProps) {
  const [screen, setScreen] = useState<'login' | 'register' | 'forgot'>('login');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [otp, setOtp] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // States for flows
  const [isLoading, setIsLoading] = useState(false);
  const [step, setStep] = useState(1); // 1 = Input, 2 = Verify OTP (for register/forgot)
  const [timer, setTimer] = useState(60);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (step === 2 && timer > 0) {
      interval = setInterval(() => setTimer((t) => t - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [step, timer]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || !password) return;

    setIsLoading(true);
    addLog('UI', 'دکمه ورود فشرده شد', `Phone: ${phone}`);
    addLog('VIEWMODEL', 'فراخوانی متد login در AuthViewModel', 'ارزیابی مقادیر ورودی و ارسال به UseCase');

    setTimeout(() => {
      addLog('USECASE', 'فراخوانی AuthenticateUserUseCase', 'تأیید اعتبار کاربر در جریان کار وب');
      addLog('REPOSITORY', 'ارتباط UserRepository.login()', 'بررسی توکن‌های شبکه در پایگاه‌داده...');
      addLog('DATASOURCE', 'درخواست POST به /api/auth/login', `با اطلاعات: ${phone}`);

      setIsLoading(false);
      addLog('REPOSITORY', 'دریافت پاسخ معتبر از API', 'ذخیره توکن با موفقیت در EncryptedSharedPreferences');
      addLog('VIEWMODEL', 'تغییر وضعیت به AuthUiState.Authenticated', 'اعلام موفقیت‌آمیز ورود به لایه رابط کاربری');
      
      onAuthSuccess(phone === '09123456789' ? 'کاوه مهرآیین' : 'کاربر یوزآنلاین');
    }, 1200);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      if (!name || !phone || !password) return;
      setIsLoading(true);
      addLog('UI', 'دکمه ثبت‌نام کلیک شد - درخواست ارسال کد OTP', `نام: ${name}، تلفن: ${phone}`);
      
      setTimeout(() => {
        addLog('VIEWMODEL', 'ارسال پیام ارسال پیامک به SendOtpUseCase', 'آماده‌سازی لایه زیرین');
        addLog('DATASOURCE', 'درخواست پیامک OTP به درگاه یوزآنلاین', 'کد فعال‌سازی با موفقیت پیامک شد.');
        setIsLoading(false);
        setStep(2);
        setTimer(60);
      }, 1000);
    } else {
      if (otp.length < 4) return;
      setIsLoading(true);
      addLog('UI', 'کد فعال‌سازی وارد شد - ثبت نهایی کاربر', `کد: ${otp}`);

      setTimeout(() => {
        addLog('USECASE', 'فراخوانی RegisterUserUseCase', 'بررسی کد احراز هویت پیامکی');
        addLog('REPOSITORY', 'تکمیل فرآیند ثبت‌نام کاربر در سرور', 'پاسخ موفقیت‌آمیز');
        setIsLoading(false);
        onAuthSuccess(name);
      }, 1200);
    }
  };

  const handleForgot = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      if (!phone) return;
      setIsLoading(true);
      addLog('UI', 'درخواست فراموشی رمز عبور', `شماره تلفن: ${phone}`);
      
      setTimeout(() => {
        addLog('VIEWMODEL', 'درخواست ارسال لینک ایمن یا پیامک بازیابی', 'فراخوانی RequestPasswordResetUseCase');
        setIsLoading(false);
        setStep(2);
        setTimer(60);
      }, 1000);
    } else {
      if (!password) return;
      setIsLoading(true);
      addLog('UI', 'تنظیم رمز عبور جدید', 'ثبت پسورد جدید در لایه دیتا');
      
      setTimeout(() => {
        addLog('USECASE', 'فراخوانی ResetPasswordUseCase', 'تغییر رمز عبور در پایگاه داده مرکزی');
        addLog('REPOSITORY', 'به‌روزرسانی امنیت کاربر با موفقیت', 'Success');
        setIsLoading(false);
        setScreen('login');
        setStep(1);
      }, 1200);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 p-6 font-vazir" dir="rtl" id="auth-flow-container">
      {/* Header */}
      <div className="flex items-center justify-between mb-8 mt-2">
        <div className="flex flex-col">
          <h1 className="text-2xl font-black text-gray-900 tracking-tight">بازارچه یوزآنلاین</h1>
          <span className="text-xs text-gray-400 font-medium">پلتفرم چندفروشگاهی برتر کشور</span>
        </div>
        <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-black text-lg shadow-md shadow-blue-200">
          ی
        </div>
      </div>

      {screen === 'login' && (
        <form onSubmit={handleLogin} className="flex flex-col gap-4 flex-1 justify-center max-w-sm mx-auto w-full">
          <div className="mb-4">
            <h2 className="text-xl font-bold text-gray-950">ورود به حساب کاربری</h2>
            <p className="text-xs text-gray-400 mt-1">رمز عبور و شماره همراه خود را وارد کنید.</p>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs font-semibold text-gray-700">شماره تلفن همراه</label>
            <div className="relative flex items-center">
              <Phone className="absolute right-3 w-4 h-4 text-gray-400" />
              <input
                type="tel"
                placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full pr-10 pl-3 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-600 transition"
              />
            </div>
            <span className="text-[10px] text-gray-400 text-left" dir="ltr">تست: 09123456789</span>
          </div>

          <div className="flex flex-col gap-1">
            <label className="text-xs font-semibold text-gray-700">رمز عبور</label>
            <div className="relative flex items-center">
              <Lock className="absolute right-3 w-4 h-4 text-gray-400" />
              <input
                type={showPassword ? 'text' : 'password'}
                placeholder="******"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pr-10 pl-10 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-600 transition text-right"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute left-3 p-1.5 rounded-lg text-gray-400 hover:text-gray-600"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <span className="text-[10px] text-gray-400 text-left" dir="ltr">تست: 123456</span>
          </div>

          <button
            type="button"
            onClick={() => {
              setScreen('forgot');
              setStep(1);
            }}
            className="text-xs text-blue-600 hover:underline text-right font-medium self-start"
          >
            رمز عبور خود را فراموش کرده‌اید؟
          </button>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-3 bg-blue-600 text-white font-bold rounded-xl text-sm hover:bg-blue-700 active:scale-95 transition flex items-center justify-center gap-2 shadow-lg shadow-blue-100"
          >
            {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : 'ورود به یوزآنلاین'}
          </button>

          <div className="text-center mt-4">
            <span className="text-xs text-gray-500">حساب کاربری جدید دارید؟ </span>
            <button
              type="button"
              onClick={() => {
                setScreen('register');
                setStep(1);
              }}
              className="text-xs text-blue-600 font-bold hover:underline"
            >
              ایجاد حساب کاربر جدید
            </button>
          </div>
        </form>
      )}

      {screen === 'register' && (
        <form onSubmit={handleRegister} className="flex flex-col gap-4 flex-1 justify-center max-w-sm mx-auto w-full">
          <div className="mb-4">
            <h2 className="text-xl font-bold text-gray-950">
              {step === 1 ? 'ساخت حساب کاربری یوزآنلاین' : 'تأیید شماره تلفن'}
            </h2>
            <p className="text-xs text-gray-400 mt-1">
              {step === 1 
                ? 'به پلتفرم چندفروشگاهی یوزآنلاین خوش آمدید.' 
                : 'کد ارسال پیامکی را که به تلفن شما رفت وارد کنید.'}
            </p>
          </div>

          {step === 1 ? (
            <>
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-gray-700">نام و نام خانوادگی</label>
                <div className="relative flex items-center">
                  <User className="absolute right-3 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    required
                    placeholder="امیررضا علوی"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pr-10 pl-3 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-600 transition"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-gray-700">شماره تلفن همراه</label>
                <div className="relative flex items-center">
                  <Phone className="absolute right-3 w-4 h-4 text-gray-400" />
                  <input
                    type="tel"
                    required
                    placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pr-10 pl-3 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-600 transition"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-gray-700">ایمیل (اختیاری)</label>
                <div className="relative flex items-center">
                  <Mail className="absolute right-3 w-4 h-4 text-gray-400" />
                  <input
                    type="email"
                    placeholder="info@useonline.ir"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pr-10 pl-3 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-600 transition"
                  />
                </div>
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-gray-700">رمز عبور</label>
                <div className="relative flex items-center">
                  <Lock className="absolute right-3 w-4 h-4 text-gray-400" />
                  <input
                    type="password"
                    required
                    placeholder="******"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pr-10 pl-3 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-600 transition"
                  />
                </div>
              </div>

              <div className="flex items-start gap-2 mt-2">
                <input type="checkbox" id="terms" defaultChecked className="mt-1 accent-blue-600" />
                <label htmlFor="terms" className="text-[10px] text-gray-500 leading-normal">
                  من تمامی <span className="text-blue-600 underline cursor-pointer">قوانین و مقررات کاربری یوزآنلاین</span> را خوانده و می‌پذیرم.
                </label>
              </div>
            </>
          ) : (
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-gray-700 text-center">کد فعال‌سازی ۴ رقمی</label>
                <input
                  type="text"
                  maxLength={4}
                  placeholder="۱۲۳۴"
                  value={otp}
                  onChange={(e) => setOtp(e.target.value)}
                  className="w-32 mx-auto tracking-[1em] text-center font-bold text-xl py-3 border border-gray-200 rounded-xl focus:outline-none focus:border-blue-600"
                />
              </div>

              <div className="text-center text-xs text-gray-400 mt-2">
                {timer > 0 ? (
                  <span>ارسال مجدد کد تا {timer} ثانیه دیگر</span>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setTimer(60);
                      addLog('UI', 'درخواست مجدد کد فعال‌سازی', 'ارسال رویداد به SendOtpUseCase');
                    }}
                    className="text-blue-600 hover:underline font-bold"
                  >
                    ارسال مجدد پیامک تایید کد
                  </button>
                )}
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-4 py-3 bg-blue-600 text-white font-bold rounded-xl text-sm hover:bg-blue-700 active:scale-95 transition flex items-center justify-center gap-2 shadow-lg shadow-blue-100"
          >
            {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : step === 1 ? 'مرحله بعد و تأیید شماره' : 'تکمیل نهایی ثبت‌نام'}
          </button>

          <button
            type="button"
            onClick={() => {
              if (step === 2) {
                setStep(1);
              } else {
                setScreen('login');
              }
            }}
            className="text-xs text-blue-600 font-bold hover:underline text-center mt-2"
          >
            بازگشت به عقب
          </button>
        </form>
      )}

      {screen === 'forgot' && (
        <form onSubmit={handleForgot} className="flex flex-col gap-4 flex-1 justify-center max-w-sm mx-auto w-full">
          <div className="mb-4">
            <h2 className="text-xl font-bold text-gray-950">
              {step === 1 ? 'فراموشی کلمه‌ عبور' : 'رمز عبور جدید'}
            </h2>
            <p className="text-xs text-gray-400 mt-1">
              {step === 1 
                ? 'شماره تلفن خود را وارد کنید تا کد بازنشانی پیامک شود.'
                : 'رمز همراه ایمن و قوی جدید خود را تنظیم کنید.'}
            </p>
          </div>

          {step === 1 ? (
            <div className="flex flex-col gap-1">
              <label className="text-xs font-semibold text-gray-700">تلفن همراه</label>
              <div className="relative flex items-center">
                <Phone className="absolute right-3 w-4 h-4 text-gray-400" />
                <input
                  type="tel"
                  required
                  placeholder="۰۹۱۲۳۴۵۶۷۸۹"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full pr-10 pl-3 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-600 transition"
                />
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-3">
              <div className="flex flex-col gap-1">
                <label className="text-xs font-semibold text-gray-700">رمز عبور نوین</label>
                <div className="relative flex items-center">
                  <Lock className="absolute right-3 w-4 h-4 text-gray-400" />
                  <input
                    type="password"
                    required
                    placeholder="******"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pr-10 pl-3 py-2.5 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:border-blue-600 transition"
                  />
                </div>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full mt-4 py-3 bg-blue-600 text-white font-bold rounded-xl text-sm hover:bg-blue-700 active:scale-95 transition flex items-center justify-center gap-2 shadow-lg shadow-blue-100"
          >
            {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : step === 1 ? 'دریافت کد تغییر پسورد' : 'تغییر و ذخیره پسورد نو'}
          </button>

          <button
            type="button"
            onClick={() => {
              setScreen('login');
              setStep(1);
            }}
            className="text-xs text-blue-600 font-bold hover:underline text-center mt-2"
          >
            انصراف و ورود مجدد
          </button>
        </form>
      )}
    </div>
  );
}
