import React, { useState, useMemo } from 'react';
import { 
  ClipboardCheck, 
  Settings, 
  ShieldCheck, 
  FileText, 
  Sparkles, 
  Zap, 
  Upload, 
  Lock, 
  CheckCircle2, 
  AlertTriangle, 
  Copy, 
  Check, 
  Eye, 
  LayoutGrid, 
  Compass, 
  RefreshCw, 
  FileCode, 
  Flame, 
  Download,
  HelpCircle,
  HelpCircle as QuestionIcon
} from 'lucide-react';

interface ReleaseConsoleProps {
  products: any[];
  addLog: (layer: 'DATASOURCE' | 'REPOSITORY' | 'USECASE' | 'VIEWMODEL' | 'UI', message: string, details?: string) => void;
  onAddNotification: (notif: any) => void;
}

export function ReleaseConsole({ products, addLog, onAddNotification }: ReleaseConsoleProps) {
  const [activeSubTab, setActiveSubTab] = useState<'checklist' | 'optSec' | 'iconAssets' | 'legal'>('checklist');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // --- 1. CHECKLIST STATE ---
  const [checklist, setChecklist] = useState([
    { id: 'chk_1', text: 'انتخاب و تست پکیج نیم منحصر به فرد (ir.useonline.shop)', category: 'تنظیمات پایه', checked: true },
    { id: 'chk_2', text: 'تنظیم نسخه ساخت (VersionCode: 100 و VersionName: 1.0.0)', category: 'تنظیمات پایه', checked: true },
    { id: 'chk_3', text: 'پیاده‌سازی مکانیزم پرداخت درون‌برنامه‌ای بازار (In-App Billing SDK)', category: 'سرویس‌های مارکت', checked: false },
    { id: 'chk_4', text: 'بهینه‌سازی کلیه تصاویر و کاهش سایز به فرمت WebP', category: 'کارایی', checked: false },
    { id: 'chk_5', text: 'فعال‌سازی قواعد حفاظتی و بهینه‌سازی R8/Proguard', category: 'امنیتی', checked: false },
    { id: 'chk_6', text: 'پیاده‌سازی سیستم مدیریت خطای سراسری (Crashlytics/Sentry)', category: 'پایداری', checked: false },
    { id: 'chk_7', text: 'تنظیم آیکون‌های تطبیقی (Adaptive Icons) و طوق متغیر', category: 'طراحی', checked: true },
    { id: 'chk_8', text: 'تهیه و تنظیم سند حریم خصوصی (Privacy Policy) معتبر', category: 'حقوقی', checked: false },
    { id: 'chk_9', text: 'آماده‌سازی پیش‌نویس تصاویر و اسکرین‌شات‌های ابعاد گوشی', category: 'دارایی‌های مارکت', checked: false },
    { id: 'chk_10', text: 'امضای با فایل کلید رسمی و پایدار (Signing JKS file)', category: 'انتشار', checked: false },
  ]);

  const toggleChecklist = (id: string) => {
    setChecklist(prev => prev.map(item => {
      if (item.id === id) {
        const nextState = !item.checked;
        addLog('UI', `تغییر وضعیت چک‌لیست نهایی: ${item.text}`, nextState ? 'تایید شده ✓' : 'غیرفعال');
        return { ...item, checked: nextState };
      }
      return item;
    }));
  };

  const checklistProgress = useMemo(() => {
    const checkedCount = checklist.filter(c => c.checked).length;
    return Math.round((checkedCount / checklist.length) * 100);
  }, [checklist]);

  // --- 2. OPTIMIZATION STATE ---
  const [isCompilersActive, setIsCompilersActive] = useState(false);
  const [compressorStatus, setCompressorStatus] = useState<'idle' | 'compressing' | 'completed'>('idle');
  const [securitySSL, setSecuritySSL] = useState(false);
  const [securityRoot, setSecurityRoot] = useState(false);
  const [securityPref, setSecurityPref] = useState(false);
  const [securityProguard, setSecurityProguard] = useState(false);
  const [crashState, setCrashState] = useState<'stable' | 'simulated'>('stable');

  // Interactive mock images list
  const [appImages, setAppImages] = useState([
    { name: 'logo_highres.png', sizeOriginal: '2.4 MB', sizeWebP: '185 KB', savedPercent: '92%', image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=100&h=100&fit=crop&q=80', active: true },
    { name: 'banner_store.png', sizeOriginal: '4.8 MB', sizeWebP: '310 KB', savedPercent: '93%', image: 'https://images.unsplash.com/photo-1557821552-17105176677c?w=120&h=80&fit=crop&q=80', active: true },
    { name: 'product01_hero.jpg', sizeOriginal: '1.2 MB', sizeWebP: '95 KB', savedPercent: '91%', image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=100&h=100&fit=crop&q=80', active: true },
  ]);

  const triggerImageCompression = () => {
    setCompressorStatus('compressing');
    addLog('REPOSITORY', 'آغاز فرایند تبدیل گروهی تصاویر به فرمت فوق فشرده WebP');
    setTimeout(() => {
      setCompressorStatus('completed');
      // Automatically check off the optimization item in the checklist
      setChecklist(prev => prev.map(c => c.id === 'chk_4' ? { ...c, checked: true } : c));
      addLog('DATASOURCE', 'فشرده‌سازی موفق تصاویر بازارچه | حجم کل کاهش یافت به کمتر از ۷۰۰ کیلوبایت', 'کاهش کل: ۹۲.۳٪');
      onAddNotification({
        id: Math.random().toString(),
        title: 'فرآیند بهینه‌سازی تصاویر با موفقیت پایان یافت! 🎨',
        body: 'حجم دارایی‌های گرافیکی بازارچه از ۸.۴ مگابایت به ۵۹۰ کیلوبایت کاهش یافت که باعث افزایش جادویی لودینگ اپ در کافه بازار شد.',
        time: 'هم‌اکنون',
        type: 'SYSTEM',
        isRead: false
      });
    }, 2000);
  };

  const handleTriggerSimulatedCrash = () => {
    setCrashState('simulated');
    addLog('UI', '💥 شبیه‌سازی رخ‌داد خطای بحرانی در اکتیویتی اصلی (java.lang.NullPointerException)');
    
    setTimeout(() => {
      addLog('VIEWMODEL', '⚠️ سامانه تله‌متری UncaughtExceptionHandler وارد لایه شد');
      addLog('REPOSITORY', '📤 ارسال متادیتا و پشته خطاهای رخ داده به آدرس Sentry/Crashlytics API', 'Device: Android 14 SDK 34');
      addLog('UI', '🛡️ اجرای موفق سیستم بازیافت وضعیت پایدار (Crash Recovery UI Active)');
      
      onAddNotification({
        id: Math.random().toString(),
        title: 'گزارش ارسالی به کرش‌لتیکس 🚫',
        body: 'یک خطای فرضی با موفقیت و بدون قطع کامل برنامه مهار شد و جزئیات پشته خطا به کنسول مدیریتی ارسال گردید.',
        time: 'هم‌اکنون',
        type: 'SYSTEM',
        isRead: false
      });

      // Automatically check off crash handling in checklist
      setChecklist(prev => prev.map(c => c.id === 'chk_6' ? { ...c, checked: true } : c));
      setCrashState('stable');
    }, 1500);
  };

  // Run full production optimization metrics
  const handleFullOptimization = () => {
    setIsCompilersActive(true);
    addLog('USECASE', '🔍 آنالیز کامل کیفیت کدهای کاتلین و تنظیمات گریدل پروژه آغاز شد...');
    
    setTimeout(() => {
      addLog('REPOSITORY', '✅ کدهای بدون استفاده از پکیج‌های نهایی با موفقیت حذف شدند');
      addLog('DATASOURCE', '✅ کوئری‌های تعبیه شده دیتابیس Room ایندکس‌گذاری و ردیابی شدند');
      addLog('VIEWMODEL', '✅ فلوهای همروند با Coroutines Dispatchers.IO مهار شدند');
      addLog('UI', '⚡ تغییر کامپایلر به مد ترشح حافظه‌ای R8 | برنامه با تمام بهینه‌سازی‌ها آماده خروجی شد');
      
      setIsCompilersActive(false);
      
      onAddNotification({
        id: Math.random().toString(),
        title: 'پروانه‌ کارایی برنامه در کافه بازار صادر شد ⚡',
        body: 'کلیه تست‌های بهینه‌سازی کدهای برنامه با ابزار Lint و موتور R8 با موفقیت تایید شد. سرعت پاسخ با بهبود ۲۴٪ روبرو شد.',
        time: 'هم‌اکنون',
        type: 'SYSTEM',
        isRead: false
      });
    }, 2500);
  };

  // --- 3. STORE ASSETS & APP ICON STATE ---
  const [iconMask, setIconMask] = useState<'squircle' | 'round' | 'legacy'>('squircle');
  
  // Custom store text listings in Persian
  const storeListingEnglish = {
    packageName: 'ir.useonline.shop',
    title: 'UseOnline Marketplace | Seamless B2B2C Online Shopping',
    shortDesc: 'Experience local and global storefronts with instant delivery and secure payments.',
    longDesc: 'UseOnline Marketplace connects vendors, merchants, and buyers directly. Built on modern native Jetpack Compose architecture.'
  };

  const storeListingPersian = {
    title: 'بازارچه چندفروشگاهی یوزآنلاین (مدیریت غرفه و خرید آنلاین)',
    shortDesc: 'تجربه بی‌واسطه خرید از سراسر کشور، ثبت غرفه فروشگاهی، مدیریت موجودی انبار و تحویل هوشمند.',
    longDesc: `بازارچه آنلاین یوزآنلاین، پلتفرمی دو طرفه و پایدار ویژه عموم خریداران و صاحبان غرفه و کسب‌وکارهای خانگی و شرکتی است. 
این بازارچه منطبق بر معماری نوین اندروید، برترین استانداردهای لودینگ و متریال دیزاین ۳ توسعه یافته است تا کمترین میزان مصرف اینترنت و بالاترین کارایی را ارائه دهد.

ویژگی‌های برجسته‌ی یوزآنلاین برای خریداران:
• دسترسی به کاتالوگ محصولات فروشندگان معتبر به کمک سیستم جستجوی پیشرفته
• امکان ثبت سفارش آسان، استفاده از کدهای تخفیف متنوع و پیگیری دقیق فاکتورها
• سیستم نشان‌کردن کالاها (علاقه‌مندی‌ها) جهت خریدهای آینده
• بارگذاری جادویی و چیدمان شیک راست‌چین منطبق با استانداردهای نوین رابط کاربری

ویژگی‌های برجسته‌ی یوزآنلاین برای غرفه‌داران محترم:
• امکان ثبت و ویرایش رایگان غرفه در کمتر از یک دقیقه
• ابزارهای پیشرفته مدیریت زنده موجودی انبار و تعیین قیمت کالا
• تسویه حساب‌های منظم زیر نظر پنل ادمین متمرکز بازارچه یوزآنلاین
• نمودارهای آماری از میزان فروش، تراکم سفارشات و پایش کارایی غرفه`
  };

  // --- 4. LEGAL GENERATOR STATE ---
  const [legalForm, setLegalForm] = useState({
    appName: 'بازارچه یوزآنلاین (UseOnline Shop)',
    devName: 'تیم توسعه فنی یوزآنلاین شاپ',
    supportEmail: 'support@useonline.shop',
    supportPhone: '021-91001234',
    website: 'https://useonline.shop'
  });

  const privacyPolicyContent = useMemo(() => {
    return {
      persian: `سند سیاست حریم خصوصی اپلیکیشن "${legalForm.appName}"

۱. مقدمه
اپلیکیشن "${legalForm.appName}" توسط "${legalForm.devName}" توسعه یافته و به منظور ارائه خدمات خرید آنلاین و مدیریت غرفه طراحی شده است. ما برای حفظ حریم خصوصی کاربران ارزش بالایی قائل هستیم. این سند نحوه جمع‌آوری، استفاده و ذخیره‌سازی داده‌های شما را توصیف می‌کند.

۲. داده‌های جمع‌آوری شده
الف) اطلاعات کاربری: شامل نام، شماره تلفن همراه، نشانی‌های ثبت‌شده برای تحویل سفارش و آدرس ایمیل.
ب) داده‌های تراکنش: سفارشات ثبت‌شده، مبالغ خرید و گزارش‌های تراکنش مالی.
ج) اطلاعات دستگاه: نسخه اندروید، مدل گوشی، و گزارش‌های تصادفات برنامه (Crash Reports) به منظور بهینه‌سازی کارایی برنامه.

۳. اهداف جمع‌آوری اطلاعات
• ارائه خدمات لجستیکی و ارسال سفارشات توسط غرفه‌داران به نشانی‌های صحیح کاربران خریدار.
• احراز هویت پیامکی به عنوان استاندار امنیتی الزامی در بازارهای ایرانی نظیر کافه بازار و مایکت.
• پایش فنی و ردیابی خطاهای سیستمی از طریق سامانه‌های Sentry و Firebase Crashlytics.

۴. دسترسی‌های مورد نیاز در اندروید
• دسترسی به شبکه اینترنت (INTERNET): جهت برقراری ارتباط با سرورهای پایگاه داده یوزآنلاین.
• دسترسی خواندن وضعیت حافظه برای ویرایش تصاویر پروفایل و عکس محصولات غرفه.

۵. ارتباط کاربری و پشتیبانی
هرگونه درخواست تغییر یا حذف کامل حساب کاربری از پایگاه داده مستقیماً از طریق ایمیل پشتیبانی به آدرس "${legalForm.supportEmail}" یا تلفن "${legalForm.supportPhone}" قابل پیگیری خواهد بود.`,
      
      english: `Privacy Policy for "${legalForm.appName}"

1. Introduction
"${legalForm.appName}" is built and operated by "${legalForm.devName}". We are deeply committed to protecting the privacy of our buyers and vendors. This Privacy Policy outlines what personal, business, and system transactional data we collect and how we utilize it.

2. Data We Collect
• Profile Information: Name, Mobile Number, Shipping/Billing Addresses, and Email.
• Store Operations Data (for Vendors): Product info, stock quantities, and wallet ledger logs.
• Technical Logs: Crash feedback reports collected securely on Android devices via Sentry.

3. Third-party SDK Integrations
To conform to Cafe Bazaar and Myket release policies, our application links to:
• Cafe Bazaar In-App Billing SDK (for digital payments).
• Sentry Crash Analytics Engine (for real-time stability monitoring).

4. Access Permissions Requested
• ACCESS_NETWORK_STATE & INTERNET: To connect to our secure cloud API endpoints.
• READ_EXTERNAL_STORAGE: For profile image updates and digital catalog assets.

5. Contact Us
If you have any questions about this policy or request complete data deletion, reach out to us at ${legalForm.supportEmail} or via ${legalForm.supportPhone}.`
    };
  }, [legalForm]);

  const termsOfServiceContent = useMemo(() => {
    return {
      persian: `سند شرایط و قوانین استفاده (Terms of Service) اپلیکیشن "${legalForm.appName}"

به اپلیکیشن "${legalForm.appName}" خوش آمدید. ورود به بازارچه و استفاده از خدمات خرید آنلاین، به منزله پذیرش کامل شرایط و مفاد زیر است:

۱. قوانین عمومی و حقوق مالکیت
رعایت کلیه قوانین جاری جمهوری اسلامی ایران از جمله قانون تجارت الکترونیکی مصوب ۱۳۸۲ و قانون حمایت از مصرف‌کننده االزامی است. استفاده از نام تجاری یوزآنلاین برای اهداف تبلیغاتی نامرتبط اکیداً ممنوع بوده و پیگیری قانونی دارد.

۲. شرایط عضویت و مسئولیت کاربران
کاربران متعهد هستند که در زمان ثبت‌نام، شماره موبایل معتبر و متعلق به خود را درج نمایند. هرگونه عواقب ناشی از ثبت نشانی‌های اشتباه برعهده مشتری است. همچنین غرفه‌داران متعهد به ارسال کالاهای اصل و تضمین تطابق موجودی زنده انبار با واقعیت هستند.

۳. کارمزدهای معاملات و تراکنش‌ها
کارمزد پیش‌فرض تسهیلات بازارچه برای فروش کلیه اقلام غیرسخت‌افزاری معادل ۲.۵٪ بوده و مانده حساب و کیف پول غرفه‌داران به صورت پایا و روزانه تسویه خواهد شد.

۴. مرجوعی کالاها و تضمین بازگشت وجه
خریدار عادی تا ۷ روز تقویمی پس از دریافت فیزیکی کالا، حق رجوع و فسخ معامله را در صورت باز نشدن پلمب کالا دارد. هزینه‌های مرجوعی کالای معیوب کاملاً بر عهده غرفه‌دار خواهد بود.

۵. تغییر قوانین و مرجع حل اختلاف
کلیه شرایط منطبق با سیاست‌های امنیتی انتشار در کافه بازار و مایکت بازبینی شده و در صورت بروز هرگونه مغایرت، درگاه داوری مرکزی یوزآنلاین شاپ ملاک قضاوت خواهد بود.`,
      
      english: `Terms of Service and Store Agreement for "${legalForm.appName}"

By installing "${legalForm.appName}", you agree to adhere to the following store guidelines and standard policies:

1. Marketplace Conduct
Users are strictly prohibited from submitting fraudulent reviews, listing illegal or counterfeit products, or creating fake orders. Vendors must guarantee the authenticity and accurate description of all inventory listed.

2. User Registration and SMS Authentication
All users of this application must register with a valid mobile phone number linked to their Iranian national identification code as mandated by e-commerce laws. 

3. Revenue, Wallet, and Settlements
A transaction fee of up to 2.5% is applied to all completed sales inside the App. Payout settlement is dispatched directly via Paya to the merchant bank account registered under vendor profile details on working days.

4. Customer Returns
According to Iranian E-Commerce law, customers benefit from a 7-day return cooling-off window for unopened packages without penalties.

5. Inquiries
Please contact technical support at "${legalForm.website}" or phone "${legalForm.supportPhone}" for settlement disputes or account terminations.`
    };
  }, [legalForm]);

  const triggerCopyAction = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    addLog('UI', `کپی موفق داده به کلیپ‌بورد`, label);
    setTimeout(() => setCopiedText(null), 2500);
  };

  return (
    <div className="flex flex-col h-full bg-[#14181f] border border-[#212936] rounded-3xl overflow-hidden font-sans text-right select-none shadow-2xl relative" dir="rtl" id="release-center-container">
      {/* Upper Tab Header Bar */}
      <div className="bg-[#1b212c] border-b border-[#2d3744]/70 px-4 py-3 flex items-center justify-between text-xs text-white">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 animate-pulse" />
          <span className="font-black text-slate-100 text-[11px] sm:text-xs">🚀 مرکز انتشار و آمادگی رلیز یوزآنلاین (Release Console)</span>
          <span className="bg-emerald-500/10 text-emerald-400 text-[8.5px] px-2 py-0.5 rounded-md border border-emerald-500/20 font-mono">
            ir.useonline.shop
          </span>
        </div>
        
        <div className="flex items-center gap-1.5 bg-[#12161f] p-1 rounded-xl border border-white/5">
          <button
            onClick={() => setActiveSubTab('checklist')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all duration-150 flex items-center gap-1 cursor-pointer ${
              activeSubTab === 'checklist' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ClipboardCheck className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">چک‌لیست بازار</span>
          </button>
          
          <button
            onClick={() => setActiveSubTab('optSec')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all duration-150 flex items-center gap-1 cursor-pointer ${
              activeSubTab === 'optSec' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">بهینه‌سازی و امنیت</span>
          </button>

          <button
            onClick={() => setActiveSubTab('iconAssets')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all duration-150 flex items-center gap-1 cursor-pointer ${
              activeSubTab === 'iconAssets' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">آیکون و دارایی‌ها</span>
          </button>

          <button
            onClick={() => setActiveSubTab('legal')}
            className={`px-3 py-1.5 rounded-lg text-[10px] font-bold transition-all duration-150 flex items-center gap-1 cursor-pointer ${
              activeSubTab === 'legal' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">اسناد قانونی</span>
          </button>
        </div>
      </div>

      {/* Main Container Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5">
        
        {/* ======================= TAB 1: CHECKLIST ======================= */}
        {activeSubTab === 'checklist' && (
          <div className="space-y-4 animate-fade-in text-right">
            {/* Upper percentage status card */}
            <div className="bg-gradient-to-l from-indigo-900/30 via-indigo-950/20 to-transparent p-4 rounded-2xl border border-indigo-500/20 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-[10px] font-bold text-indigo-400 block uppercase tracking-wider">سنسور آمادگی انتشار (Bazaar & Myket Compliance)</span>
                <h3 className="text-sm font-black text-white">درصد تطابق با قوانین مارکت ملی</h3>
                <p className="text-[10px] text-slate-400 leading-relaxed max-w-lg">
                  این بخش میزان آمادگی کدهای اندروید یوزآنلاین جهت انتشار در فروشگاه‌های بازار و مایکت را ردیابی می‌نماید. با بررسی و تایید آیتم‌ها، این شاخص را به ۱۰۰٪ رسانده و از عدم ریجکت برنامه اطمینان حاصل کنید.
                </p>
              </div>

              <div className="flex items-center gap-4 shrink-0">
                <div className="relative w-20 h-20 flex items-center justify-center bg-[#11141a]/60 rounded-full border border-indigo-500/10">
                  {/* Gauge indicator */}
                  <svg className="w-16 h-16 transform -rotate-90">
                    <circle cx="32" cy="32" r="28" className="stroke-slate-800" strokeWidth="4" fill="transparent" />
                    <circle 
                      cx="32" 
                      cy="32" 
                      r="28" 
                      className="stroke-indigo-500 transition-all duration-500" 
                      strokeWidth="5" 
                      fill="transparent" 
                      strokeDasharray={2 * Math.PI * 28}
                      strokeDashoffset={2 * Math.PI * 28 * (1 - checklistProgress / 100)}
                    />
                  </svg>
                  <span className="absolute text-base font-black text-white font-mono leading-none">
                    {checklistProgress}%
                  </span>
                </div>
                <div>
                  <span className="text-[9px] text-slate-400 block font-bold">وضعیت انتشار:</span>
                  <span className={`text-[11px] font-black block mt-0.5 ${checklistProgress >= 80 ? 'text-emerald-400 animate-pulse' : 'text-amber-400'}`}>
                    {checklistProgress === 100 ? '✅ صددرصد آماده بارگذاری' : checklistProgress >= 70 ? '🟢 وضعیت مناسب - آستانه نهایی' : '🟡 نیازمند اقدامات آماده‌سازی'}
                  </span>
                </div>
              </div>
            </div>

            {/* Checklist items dynamic mapping */}
            <div className="bg-[#12161d] rounded-2.5xl p-4 border border-[#212936] space-y-2">
              <span className="text-[9.5px] font-bold text-slate-400 block mb-3">اقدامات نهایی انتشار در فروشگاه:</span>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
                {checklist.map((item) => (
                  <div 
                    key={item.id} 
                    onClick={() => toggleChecklist(item.id)}
                    className={`p-3.5 rounded-xl border flex items-center justify-between gap-3 cursor-pointer transition-all duration-150 group select-none ${
                      item.checked 
                        ? 'border-indigo-500/30 bg-indigo-950/10 hover:bg-indigo-950/20' 
                        : 'border-[#2d3744]/60 bg-[#161a20]/60 hover:border-slate-600 hover:bg-[#1a2029]'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-4 h-4 rounded-md border flex items-center justify-center transition-all duration-150 ${
                        item.checked 
                          ? 'bg-indigo-600 border-indigo-500 text-white' 
                          : 'border-slate-600 group-hover:border-slate-500'
                      }`}>
                        {item.checked && <Check className="w-3 h-3" strokeWidth={3} />}
                      </div>
                      <div className="text-right">
                        <span className={`text-[10px] block font-semibold transition-all ${item.checked ? 'text-slate-100' : 'text-slate-400 line-through'}`}>
                          {item.text}
                        </span>
                        <span className="text-[8px] text-slate-500 font-bold block mt-0.5">{item.category}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Market spec advice footer */}
            <div className="bg-[#181216] border border-amber-500/10 p-3 rounded-xl flex items-start gap-2.5 text-right">
              <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <span className="text-[9.5px] font-bold text-amber-400 block">توجه فنی در اجرای پرداخت بازار:</span>
                <p className="text-[9px] text-slate-400 leading-normal">
                  جهت اجرای مکانیزم پرداخت درون‌برنامه‌ای (In-App Purchase) کافه بازار، مطمئن شوید کلید عمومی RSA دریافتی از پنل مدیریتی بازار را در کلاس ساختار بیانی <span className="font-mono text-[8.5px] text-blue-300">MarketBillingHelper.kt</span> تعریف کرده‌اید تا تراکنش‌های تاییدیه خریداران به درستی امضا و رمزگشایی شوند.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* ======================= TAB 2: PERFORMANCE & SECURITY ======================= */}
        {activeSubTab === 'optSec' && (
          <div className="space-y-5 animate-fade-in text-right">
            
            {/* Group 1: Performance Benchmarking & Image Compressor */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
              
              {/* Left Column: Image Conversion Engine */}
              <div className="lg:col-span-7 bg-[#12161c] border border-[#212936] p-4 rounded-2.5xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 mb-2">
                    <Sparkles className="w-4 h-4 text-indigo-400" />
                    <h4 className="text-xs font-black text-white">کمپرسور تصاویر و تبدیل فرمت به WebP (بازارچه)</h4>
                  </div>
                  <p className="text-[9.5px] text-slate-400 leading-normal mb-3">
                    کافه بازار و مایکت نسبت به فایل‌های سنگین حساسیت بالایی دارند. با استفاده از موتور مبدل WebP لندینگ پیج، منابع تصویری زیر تا ۹۰٪ بدون افت محسوس کیفیت فشرده خواهند شد تا حجم فایل APK کاهش یابد.
                  </p>

                  <div className="space-y-2 max-h-40 overflow-y-auto mb-4 border border-white/5 p-2 rounded-xl bg-[#0e1115]">
                    {appImages.map((img, i) => (
                      <div key={i} className="flex items-center justify-between p-2 bg-[#161a22] rounded-lg text-right">
                        <div className="flex items-center gap-2">
                          <img src={img.image} className="w-8 h-8 rounded object-cover" alt="" referrerPolicy="no-referrer" />
                          <div>
                            <span className="text-[9.5px] text-slate-200 block font-bold font-mono">{img.name}</span>
                            <span className="text-[8px] text-slate-500 block">سایز پیشین: {img.sizeOriginal}</span>
                          </div>
                        </div>

                        <div className="text-left font-mono">
                          {compressorStatus === 'completed' ? (
                            <div className="text-right">
                              <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[8px] font-extrabold px-1.5 py-0.5 rounded-full">
                                {img.sizeWebP} (WebP)
                              </span>
                              <span className="text-[8px] text-emerald-400 block mt-0.5 font-bold">صرفه‌جویی: {img.savedPercent}</span>
                            </div>
                          ) : (
                            <span className="text-slate-500 text-[9px] font-bold">در انتظار فشرده‌سازی</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-white/5 pt-3">
                  <div className="text-[9px] text-slate-400">
                    {compressorStatus === 'completed' ? (
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        صرفه‌جویی کل: ۷.۸ مگابایت!
                      </span>
                    ) : (
                      <span>تعداد فایل هدف: ۳ المان گرافیکی</span>
                    )}
                  </div>

                  <button
                    onClick={triggerImageCompression}
                    disabled={compressorStatus === 'compressing'}
                    className={`text-[9.5px] font-black px-4 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer active:scale-95 ${
                      compressorStatus === 'compressing'
                        ? 'bg-[#1b212c] text-slate-400 border border-white/5'
                        : compressorStatus === 'completed'
                          ? 'bg-emerald-600/10 text-emerald-400 border border-emerald-500/30'
                          : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-md shadow-indigo-600/15'
                    }`}
                  >
                    {compressorStatus === 'compressing' ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>در حال تبدیل و فشرده‌سازی...</span>
                      </>
                    ) : compressorStatus === 'completed' ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        <span>عملیات با موفقیت انجام شد</span>
                      </>
                    ) : (
                      <>
                        <Upload className="w-3.5 h-3.5" />
                        <span>شروع تبدیل فرمت و فشرده‌سازی به WebP</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Right Column: Code Compilers Optimization (R8 & Lint Tester) */}
              <div className="lg:col-span-5 bg-[#12161c] border border-[#212936] p-4 rounded-2.5xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-1.5 mb-2">
                    <Zap className="w-4 h-4 text-indigo-400" />
                    <h4 className="text-xs font-black text-white">بهینه‌سازی کدهای بیلد سیستم (R8 Compiler)</h4>
                  </div>
                  <p className="text-[9.5px] text-slate-400 leading-normal mb-4">
                    موتور R8 با حذف متدهای بلااستفاده و کوچک‌سازی آبجکت‌ها سایز کدهای نهایی کاتلین را کاهش می‌دهد. این شبیه‌ساز با عارضه‌یابی و مانیتورینگ متغیرها، پایداری کدهای Compose را در لایه مموری تایید می‌کند.
                  </p>

                  <div className="bg-[#0e1115] border border-white/5 p-3 rounded-xl font-mono text-[9px] text-zinc-400 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">M3 Unused Assets Remover:</span>
                      <span className={isCompilersActive ? 'text-amber-400 animate-pulse' : 'text-emerald-400 font-bold'}>
                        {isCompilersActive ? 'Running...' : 'Enabled (Safely cleaned)'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Kotlin Dead Code Strip:</span>
                      <span className={isCompilersActive ? 'text-amber-400 animate-pulse' : 'text-emerald-400 font-bold'}>
                        {isCompilersActive ? 'Optimizing...' : '12,084 methods cleaned'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">Dex Guard Compiler State:</span>
                      <span className="text-[#9ea0a5]/80 font-semibold">Single-Dex Configured</span>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-white/5 flex items-center justify-end">
                  <button
                    onClick={handleFullOptimization}
                    disabled={isCompilersActive}
                    className="bg-zinc-800 hover:bg-zinc-700 active:scale-95 transition text-slate-200 text-[9.5px] font-black px-4 py-2 rounded-xl flex items-center gap-1.5 border border-zinc-700/60 cursor-pointer"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isCompilersActive ? 'animate-spin' : ''}`} />
                    <span>بهینه‌سازی کامل کدهای یوزآنلاین و اجرای تست R8</span>
                  </button>
                </div>
              </div>

            </div>

            {/* Group 2: Security Hardening & SharedPreferences Obfuscation Code Generator */}
            <div className="bg-[#12161c] border border-[#212936] p-4 rounded-2.5xl space-y-4">
              <div className="flex items-center gap-1.5 justify-between">
                <div className="flex items-center gap-1.5">
                  <Lock className="w-4 h-4 text-indigo-400" />
                  <h4 className="text-xs font-black text-white">کیت امنیت عمیق اندروید (Security Hardening toolkit)</h4>
                </div>
                <span className="text-[8px] bg-red-500/10 border border-red-500/20 text-red-400 font-bold px-2 py-0.5 rounded-full">الزامی برای جلوگیری از دیکامپایل</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-[#0d1015] p-3 rounded-2xl border border-white/5">
                {/* Switch 1: SSL Pinning */}
                <div 
                  onClick={() => {
                    const next = !securitySSL;
                    setSecuritySSL(next);
                    if(next) addLog('REPOSITORY', 'پیکربندی تاییدیه گواهینامه SSL Pinning فعال شد');
                  }} 
                  className={`p-3 rounded-xl border cursor-pointer select-none transition ${
                    securitySSL ? 'bg-indigo-950/15 border-indigo-500/40' : 'bg-transparent border-[#2d3744]/40 hover:border-slate-700'
                  }`}
                >
                  <span className="text-[10px] font-black text-white block">پیکربندی SSL Pinning</span>
                  <span className="text-[8px] text-slate-500 block mt-0.5">ضد شنود کائوتیک داده‌ها (MitM)</span>
                  <span className={`text-[8.5px] font-bold block mt-2 ${securitySSL ? 'text-indigo-400' : 'text-slate-500'}`}>
                    {securitySSL ? '✓ فعال و کاتالوگ شد' : 'غیرفعال'}
                  </span>
                </div>

                {/* Switch 2: Root Detection */}
                <div 
                  onClick={() => {
                    const next = !securityRoot;
                    setSecurityRoot(next);
                    if(next) {
                      addLog('REPOSITORY', 'تلفیق کتابخانه RootBeer جهت پایش گوشی‌های روت شده');
                      setChecklist(prev => prev.map(c => c.id === 'chk_5' ? { ...c, checked: true } : c));
                    }
                  }} 
                  className={`p-3 rounded-xl border cursor-pointer select-none transition ${
                    securityRoot ? 'bg-indigo-950/15 border-indigo-500/40' : 'bg-transparent border-[#2d3744]/40 hover:border-slate-700'
                  }`}
                >
                  <span className="text-[10px] font-black text-white block">تشخیص روت (Root Detection)</span>
                  <span className="text-[8px] text-slate-500 block mt-0.5">بررسی وضعیت دسترسی SU گوشی</span>
                  <span className={`text-[8.5px] font-bold block mt-2 ${securityRoot ? 'text-indigo-400' : 'text-slate-500'}`}>
                    {securityRoot ? '✓ ادغام اندروید شد' : 'غیرفعال'}
                  </span>
                </div>

                {/* Switch 3: Encrypted SharedPreferences */}
                <div 
                  onClick={() => {
                    const next = !securityPref;
                    setSecurityPref(next);
                    if(next) addLog('DATASOURCE', 'تغییر بستر ذخیره‌سازی ترجیحات به EncryptedSharedPreferences');
                  }} 
                  className={`p-3 rounded-xl border cursor-pointer select-none transition ${
                    securityPref ? 'bg-indigo-950/15 border-indigo-500/40' : 'bg-transparent border-[#2d3744]/40 hover:border-slate-700'
                  }`}
                >
                  <span className="text-[10px] font-black text-white block">رمزگذاری حافظه داخلی</span>
                  <span className="text-[8px] text-slate-500 block mt-0.5">کدگذاری توکن به کمک KeyStore</span>
                  <span className={`text-[8.5px] font-bold block mt-2 ${securityPref ? 'text-indigo-400' : 'text-slate-500'}`}>
                    {securityPref ? '✓ فعال و ایمن گشت' : 'غیرفعال'}
                  </span>
                </div>

                {/* Switch 4: Proguard Config rule generation */}
                <div 
                  onClick={() => {
                    const next = !securityProguard;
                    setSecurityProguard(next);
                    if(next) addLog('REPOSITORY', 'بازیابی اتوماتیک قوائد همگام‌سازی پروقارد لایه دیتا');
                  }} 
                  className={`p-3 rounded-xl border cursor-pointer select-none transition ${
                    securityProguard ? 'bg-indigo-950/15 border-indigo-500/40' : 'bg-transparent border-[#2d3744]/40 hover:border-slate-700'
                  }`}
                >
                  <span className="text-[10px] font-black text-white block">کدگذاری کاتلین (Obfuscation)</span>
                  <span className="text-[8px] text-slate-500 block mt-0.5">قوائد Proguard پیشگیری از هک</span>
                  <span className={`text-[8.5px] font-bold block mt-2 ${securityProguard ? 'text-indigo-400' : 'text-slate-500'}`}>
                    {securityProguard ? '✓ آماده خروجی' : 'غیرفعال'}
                  </span>
                </div>
              </div>

              {/* Code Generator Output based on selected toggles */}
              {(securitySSL || securityRoot || securityPref || securityProguard) && (
                <div className="bg-[#0e1115] border border-white/5 rounded-2xl p-4 space-y-3 font-mono text-[9.5px] select-text">
                  <div className="flex items-center justify-between border-b border-white/5 pb-2">
                    <span className="text-slate-400 font-bold flex items-center gap-1.5">
                      <FileCode className="w-3.5 h-3.5 text-blue-400" />
                      کد منبع کاتلین و تنظیمات گریدل بازیابی شده
                    </span>
                    <button
                      onClick={() => {
                        let textToCopy = '';
                        if (securityProguard) textToCopy += `# Proguard parameters\n-keep class ir.useonline.shop.domain.model.** { *; }\n-keepattributes Signature,*Annotation*,EnclosingMethod\n`;
                        if (securityRoot) textToCopy += `// Rootbeer integrations\nval rootBeer = RootBeer(context)\nif(rootBeer.isRooted) { finish() /* Block execution */ }\n`;
                        if (securityPref) textToCopy += `val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)\nval secureSharePref = EncryptedSharedPreferences.create(...)\n`;
                        triggerCopyAction(textToCopy || 'Code segment', 'کد محافظت شده کاتلین');
                      }}
                      className="bg-[#1c222c] hover:bg-slate-800 text-slate-300 px-2.5 py-1 rounded border border-white/5 flex items-center gap-1 cursor-pointer"
                    >
                      {copiedText === 'کد محافظت شده کاتلین' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedText === 'کد محافظت شده کاتلین' ? 'کپی شد!' : 'کپی تکه کد'}</span>
                    </button>
                  </div>

                  <div className="space-y-3 overflow-x-auto text-[8.5px] md:text-[9.5px]">
                    {securityProguard && (
                      <div>
                        <span className="text-amber-400 block font-bold">// proguard-rules.pro — ایمن‌سازی دیتابیس Room و کاتالوگ غرفه‌داران</span>
                        <pre className="text-slate-400 font-mono mt-1 p-2 bg-[#12161c] rounded border border-white/5 leading-relaxed text-left" dir="ltr">
{`-keep class ir.useonline.shop.domain.model.** { *; }
-keep class ir.useonline.shop.data.local.** { *; }
-keepclassmembers class * extends androidx.room.RoomDatabase {
    <init>(...);
}
-dontwarn com.google.errorprone.annotations.**`}
                        </pre>
                      </div>
                    )}

                    {securityRoot && (
                      <div>
                        <span className="text-amber-400 block font-bold">// MainActivity.kt — بررسی وضعیت امنیتی سیستم‌عامل کاربر قبل از اجرای پرداخت</span>
                        <pre className="text-slate-400 font-mono mt-1 p-2 bg-[#12161c] rounded border border-white/5 leading-relaxed text-left" dir="ltr">
{`import com.scottyab.rootbeer.RootBeer

fun checkDeviceSecurity(context: Context): Boolean {
    val rootBeer = RootBeer(context)
    if (rootBeer.isRooted) {
        Log.e("Security", "خروج اضطراری؛ دستگاه کاربر روت شده است.")
        return false // Block payment flows
    }
    return true
}`}
                        </pre>
                      </div>
                    )}

                    {securityPref && (
                      <div>
                        <span className="text-amber-400 block font-bold">// Hilt SecurityModule — ارجاع متد EncryptedSharedPreferences برای توکن‌ها</span>
                        <pre className="text-slate-400 font-mono mt-1 p-2 bg-[#12161c] rounded border border-white/5 leading-relaxed text-left" dir="ltr">
{`@Provides
@Singleton
fun provideEncryptedSharedPreferences(@ApplicationContext context: Context): SharedPreferences {
    val masterKeyAlias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
    return EncryptedSharedPreferences.create(
        "useonline_secure_prefs",
        masterKeyAlias,
        context,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
}`}
                        </pre>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Simulated Crash Handling Console (Stability center) */}
            <div className="bg-[#1a1215] border border-rose-500/10 p-5 rounded-2.5xl flex flex-col md:flex-row md:items-center justify-between gap-5">
              <div className="space-y-1">
                <div className="flex items-center gap-1.5">
                  <Flame className="w-4 h-4 text-rose-500 animate-pulse" />
                  <span className="text-[10px] font-bold text-rose-400 block uppercase">ردیابی پایداری و ثبات اپ (Sentry / Crashlytics Logs)</span>
                </div>
                <h3 className="text-xs font-black text-white">شبیه‌ساز هوشمند کرش و مدیریت خطای غرفه‌داری و خرید</h3>
                <p className="text-[9.5px] text-slate-400 leading-normal max-w-xl">
                  بازار و مایکت برنامه‌هایی که مکرراً کرش می‌کنند را به سرعت حذف یا رده پایین قرار می‌دهند. مکانیزم یکپارچه استثنای سراسری (UncaughtExceptionHandler) در یوزآنلاین شاپ از قطع ناگهانی ارتباط کاتلان جلوگیری می‌نماید.
                </p>
              </div>

              <button
                onClick={handleTriggerSimulatedCrash}
                disabled={compressorStatus === 'compressing'}
                className="bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 text-[9.5px] font-black px-4.5 py-2.5 rounded-xl active:scale-95 transition shrink-0 flex items-center gap-1.5 cursor-pointer"
              >
                <Flame className="w-3.5 h-3.5" />
                <span>شبیه‌سازی خطا و پایش تله‌متری</span>
              </button>
            </div>
          </div>
        )}

        {/* ======================= TAB 3: APP ICON & GRAPHIC ASSETS ======================= */}
        {activeSubTab === 'iconAssets' && (
          <div className="space-y-5 animate-fade-in text-right">
            
            {/* Visual adaptive app icon simulator side-by-side with market details */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              
              {/* Box 1: Adaptive icon preview selector and specs */}
              <div className="lg:col-span-4 bg-[#12161c] border border-[#212936] p-4 rounded-2.5xl flex flex-col items-center justify-center text-center">
                <span className="text-[10px] font-bold text-slate-400 mb-3 block">شبیه‌ساز آیکون تطبیقی (Adaptive Vector)</span>
                
                {/* Simulated icon mask frame */}
                <div className="relative w-28 h-28 flex items-center justify-center bg-gradient-to-tr from-slate-900 to-slate-950 p-6 rounded-2.5xl border border-white/10 mb-4 shadow-lg group">
                  <div className={`w-20 h-20 bg-gradient-to-tr from-blue-600 to-indigo-700 text-white flex items-center justify-center font-black text-4xl shadow-md transition-all duration-300 relative overflow-hidden ${
                    iconMask === 'squircle' ? 'rounded-[22px]' : iconMask === 'round' ? 'rounded-full' : 'rounded-none'
                  }`}>
                    آ
                    {/* Foreground visual details overlay */}
                    <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-white/10 to-transparent pointer-events-none" />
                  </div>
                </div>

                {/* Mask switcher options */}
                <div className="flex gap-1.5 bg-[#0e1115] p-1.5 rounded-xl border border-white/5 mb-4 text-[9px] font-bold">
                  <button 
                    onClick={() => setIconMask('squircle')} 
                    className={`px-2.5 py-1 rounded-md transition ${iconMask === 'squircle' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
                  >Squircle (سامسونگ)</button>
                  <button 
                    onClick={() => setIconMask('round')} 
                    className={`px-2.5 py-1 rounded-md transition ${iconMask === 'round' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
                  >Round (پیکسل)</button>
                  <button 
                    onClick={() => setIconMask('legacy')} 
                    className={`px-2.5 py-1 rounded-md transition ${iconMask === 'legacy' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
                  >Legacy (کلاسیک)</button>
                </div>

                <div className="space-y-1 text-slate-400 text-[9px] text-right w-full border-t border-white/5 pt-3">
                  <span className="font-bold text-slate-300 block mb-1">الزامات فنی آیکون اندروید:</span>
                  <p>• ابعاد آیکون اصلی مارکت: ۵۱۲ در ۵۱۲ پیکسل (فرمت PNG ۳۲ بیت)</p>
                  <p dir="ltr" className="text-left">• res/mipmap-anydpi-v26/useonline_icon.xml</p>
                  <p>• شامل پس‌زمینه (Background) غنی و لایه پیشین (Foreground) وکتور.</p>
                </div>
              </div>

              {/* Box 2: Store listing copywriter (Interactive template copy helper) */}
              <div className="lg:col-span-8 bg-[#12161c] border border-[#212936] p-4 rounded-2.5xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3 border-b border-white/5 pb-2">
                    <div className="flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-indigo-400" />
                      <h4 className="text-xs font-black text-white">کپی‌رایتر پیش‌نویس کافه بازار و مایکت (Store Listing)</h4>
                    </div>
                    
                    <button
                      onClick={() => triggerCopyAction(
                        `عنوان: ${storeListingPersian.title}\nشرح کوتاه: ${storeListingPersian.shortDesc}\nتوضیحات معرفی:\n${storeListingPersian.longDesc}`,
                        'کپشن مارکت ایرانی یوزآنلاین'
                      )}
                      className="bg-[#1c222c] hover:bg-slate-850 text-slate-300 px-2.5 py-1 rounded border border-white/5 text-[9px] flex items-center gap-1.5 cursor-pointer font-bold"
                    >
                      {copiedText === 'کپشن مارکت ایرانی یوزآنلاین' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedText === 'کپشن مارکت ایرانی یوزآنلاین' ? 'کپی شد!' : 'کپی متن معرفی فارسی'}</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <span className="text-[9px] font-bold text-slate-400 block mb-0.5">عنوان فارسی ثبت در مارکت:</span>
                      <p className="bg-[#0e1115] p-2.5 rounded-xl border border-white/5 text-slate-200 text-[10px] font-bold leading-normal text-right">
                        {storeListingPersian.title}
                      </p>
                    </div>

                    <div>
                      <span className="text-[9px] font-bold text-slate-400 block mb-0.5">توضیح کوتاه (شورت دسکریپشن):</span>
                      <p className="bg-[#0e1115] p-2.5 rounded-xl border border-white/5 text-slate-200 text-[10px] leading-relaxed text-right">
                        {storeListingPersian.shortDesc}
                      </p>
                    </div>

                    <div>
                      <span className="text-[9px] font-bold text-slate-400 block mb-0.5">بخشی از متن معرفی عمیق محصول:</span>
                      <div className="bg-[#0e1115] p-3 rounded-xl border border-white/5 text-slate-400 text-[9px] leading-relaxed text-right max-h-40 overflow-y-auto whitespace-pre-line">
                        {storeListingPersian.longDesc}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-[9px] text-slate-500 pt-3 border-t border-white/5 leading-normal">
                  💡 <span className="font-bold text-slate-400">نکته بازاریابی:</span> به همراه داشتن کلمات کلیدی همچانی نظیر "خرید کالا"، "مدیریت غرفه"، "کیف پول" و "تخفیف" شانس نمایش اپلیکیشن یوزآنلاین را در سرچ بومی کافه بازار تا ۳۷٪ توسعه می‌دهد.
                </div>
              </div>

            </div>

            {/* Asset Dimensions Specification Info Table */}
            <div className="bg-[#12161c] border border-[#212936] p-4 rounded-2.5xl">
              <span className="text-[10px] font-black text-white block mb-2.5">جدول راهنمای ابعاد و فرمت دارایی‌های گرافیکی انتشار نهایی</span>
              <div className="overflow-x-auto">
                <table className="w-full text-right text-[9.5px] border-collapse bg-[#0e1115] rounded-xl border border-white/5">
                  <thead>
                    <tr className="border-b border-white/10 text-slate-400 font-bold bg-[#14181f]">
                      <th className="p-2.5">نام دارایی</th>
                      <th className="p-2.5">هدف استفاده</th>
                      <th className="p-2.5">رزولوشن / ابعاد الزامی</th>
                      <th className="p-2.5 text-center">فرمت فایل</th>
                      <th className="p-2.5 text-left">محدودیت حجم</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5 text-slate-300">
                    <tr>
                      <td className="p-2.5 font-bold">نماد اصلی (High-Res Icon)</td>
                      <td className="p-2.5">نمایش در نتایج جستجو و لندینگ مارکت‌ها</td>
                      <td className="p-2.5 font-mono text-indigo-400">512 x 512 px</td>
                      <td className="p-2.5 text-center">32-bit PNG (with alpha)</td>
                      <td className="p-2.5 text-left font-mono">1 MB max</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold">تصاویر محیط برنامه (Screenshots)</td>
                      <td className="p-2.5">اسکرین شات از نمای خرید، سبد خرید، غرفه‌داری</td>
                      <td className="p-2.5 font-mono text-indigo-400">1080 x 1920 px (یا برعکس)</td>
                      <td className="p-2.5 text-center">WebP / High Quality JPG</td>
                      <td className="p-2.5 text-left font-mono">2 MB per image</td>
                    </tr>
                    <tr>
                      <td className="p-2.5 font-bold">بنر تبلیغاتی ویژه (Promo Banner)</td>
                      <td className="p-2.5">لندینگ فیچرهای ویژه بازار در صدر صفحه اول</td>
                      <td className="p-2.5 font-mono text-indigo-400">1024 x 500 px</td>
                      <td className="p-2.5 text-center">PNG / JPG (no alpha)</td>
                      <td className="p-2.5 text-left font-mono">3 MB max</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ======================= TAB 4: LEGAL TEMPLATES GENERATOR ======================= */}
        {activeSubTab === 'legal' && (
          <div className="space-y-4 animate-fade-in text-right">
            
            {/* Dynamic Metadata Inputs form to customized templates on the fly! */}
            <div className="bg-[#12161c] border border-[#212936] p-4 rounded-2.5xl">
              <span className="text-[10px] font-black text-white block mb-3">شخصی‌سازی آنی اطلاعات در اسناد قانونی (Privacy & Terms Generator)</span>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-slate-400 block">نام اپ قطعی:</label>
                  <input 
                    type="text" 
                    value={legalForm.appName}
                    onChange={(e) => setLegalForm({...legalForm, appName: e.target.value})}
                    className="w-full bg-[#1c222d] border border-white/5 rounded-xl px-2.5 py-1.5 text-[10px] text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-semibold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-slate-400 block">نام تیم توسعه صادرکننده:</label>
                  <input 
                    type="text" 
                    value={legalForm.devName}
                    onChange={(e) => setLegalForm({...legalForm, devName: e.target.value})}
                    className="w-full bg-[#1c222d] border border-white/5 rounded-xl px-2.5 py-1.5 text-[10px] text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-semibold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-slate-400 block">ایمیل پشتیبانی رسمی:</label>
                  <input 
                    type="email" 
                    value={legalForm.supportEmail}
                    onChange={(e) => setLegalForm({...legalForm, supportEmail: e.target.value})}
                    className="w-full bg-[#1c222d] border border-white/5 rounded-xl px-2.5 py-1.5 text-[10px] text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-left"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-slate-400 block">تلفن روابط عمومی:</label>
                  <input 
                    type="text" 
                    value={legalForm.supportPhone}
                    onChange={(e) => setLegalForm({...legalForm, supportPhone: e.target.value})}
                    className="w-full bg-[#1c222d] border border-white/5 rounded-xl px-2.5 py-1.5 text-[10px] text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-left"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[9px] font-bold text-slate-400 block">وبسایت و وب‌آدرس رسمی:</label>
                  <input 
                    type="text" 
                    value={legalForm.website}
                    onChange={(e) => setLegalForm({...legalForm, website: e.target.value})}
                    className="w-full bg-[#1c222d] border border-white/5 rounded-xl px-2.5 py-1.5 text-[10px] text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-left"
                  />
                </div>
              </div>
            </div>

            {/* Split Grid for privacy policy versus terms of service */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              
              {/* Left Column: Privacy Policy Generator View */}
              <div className="bg-[#12161c] border border-[#212936] p-4 rounded-2.5xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between pointer-events-none mb-3">
                    <span className="text-xs font-black text-indigo-400">سند حریم خصوصی خریداران و غرفه‌ها</span>
                    <span className="text-[8px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2 py-0.5 rounded-full font-bold">Privacy Policy</span>
                  </div>

                  {/* Farsi description file text viewer */}
                  <div className="space-y-2 mb-4 text-right">
                    <span className="text-[9px] font-bold text-slate-400 block">پیش‌نویس سند قانونی حریم خصوصی (به زبان فارسی):</span>
                    <div className="bg-[#0e1115] p-3 rounded-xl border border-white/5 text-[9px] text-slate-300 leading-normal max-h-56 overflow-y-auto whitespace-pre-line text-right">
                      {privacyPolicyContent.persian}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-white/5 pt-3">
                  <button 
                    onClick={() => {
                      triggerCopyAction(privacyPolicyContent.english, 'سیاست حریم خصوصی به زبان انگلیسی');
                      setChecklist(prev => prev.map(c => c.id === 'chk_8' ? { ...c, checked: true } : c));
                    }}
                    className="text-slate-400 hover:text-white transition text-[9px] font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="w-3 h-3" />
                    <span>دریافت نسخه انگلیسی policy</span>
                  </button>

                  <button
                    onClick={() => {
                      triggerCopyAction(privacyPolicyContent.persian, 'سیاست حریم خصوصی فارسی');
                      setChecklist(prev => prev.map(c => c.id === 'chk_8' ? { ...c, checked: true } : c));
                    }}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-[9.5px] px-3.5 py-1.5 rounded-lg active:scale-95 transition flex items-center gap-1 cursor-pointer"
                  >
                    {copiedText === 'سیاست حریم خصوصی فارسی' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>کپی پیست نسخه فارسی</span>
                  </button>
                </div>
              </div>

              {/* Right Column: Terms of Service Generator View */}
              <div className="bg-[#12161c] border border-[#212936] p-4 rounded-2.5xl flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between pointer-events-none mb-3">
                    <span className="text-xs font-black text-indigo-400">قرارداد و شرایط استفاده غرفه‌دار و خریدار</span>
                    <span className="text-[8px] bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2 py-0.5 rounded-full font-bold">Terms of Service</span>
                  </div>

                  {/* Farsi conditions file text viewer */}
                  <div className="space-y-2 mb-4 text-right">
                    <span className="text-[9px] font-bold text-slate-400 block">توافق‌نامه انضباطی و مالی فی‌مابین (شامل شرایط عودت کالا):</span>
                    <div className="bg-[#0e1115] p-3 rounded-xl border border-white/5 text-[9px] text-slate-300 leading-normal max-h-56 overflow-y-auto whitespace-pre-line text-right">
                      {termsOfServiceContent.persian}
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between border-t border-white/5 pt-3">
                  <button 
                    onClick={() => triggerCopyAction(termsOfServiceContent.english, 'سند شرایط استفاده انگلیسی')}
                    className="text-slate-400 hover:text-white transition text-[9px] font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="w-3 h-3" />
                    <span>دریافت نسخه انگلیسی terms</span>
                  </button>

                  <button
                    onClick={() => triggerCopyAction(termsOfServiceContent.persian, 'سند شرایط استفاده فارسی')}
                    className="bg-[#1c222c] hover:bg-slate-800 text-slate-200 border border-white/5 font-bold text-[9.5px] px-3.5 py-1.5 rounded-lg active:scale-95 transition flex items-center gap-1 cursor-pointer"
                  >
                    {copiedText === 'سند شرایط استفاده فارسی' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>کپی پیست شرایط فارسی</span>
                  </button>
                </div>
              </div>

            </div>

          </div>
        )}

      </div>

      {/* Embedded footer disclaimer */}
      <div className="bg-[#1b212c] border-t border-[#2d3744]/70 px-4 py-2.5 flex items-center justify-between text-[9px] text-slate-500 font-semibold" dir="rtl">
        <span>* کلیه اسناد بر اساس قوانین ناظر تجارت الکترونیک کافه بازار بومی‌سازی شده است.</span>
        <span className="font-mono">Last updated: June 2026</span>
      </div>
    </div>
  );
}
