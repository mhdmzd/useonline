import React, { useState, useMemo } from 'react';
import { 
  Users, 
  Store, 
  ShoppingBag, 
  FolderTree, 
  FileText, 
  AlertTriangle, 
  TrendingUp, 
  DollarSign, 
  Activity, 
  Search, 
  Trash2, 
  Edit, 
  Plus, 
  Check, 
  X, 
  ChevronDown, 
  UserCheck, 
  UserX, 
  CheckCircle, 
  Wallet, 
  Filter, 
  RefreshCw,
  FolderOpen,
  Eye,
  Award,
  BellRing,
  ShieldCheck,
  Download
} from 'lucide-react';
import { Product, Category, Order, ArchLog, NotificationItem, VendorShop } from '../../types';

// State Interfaces
export interface AdminUser {
  id: string;
  name: string;
  role: 'BUYER' | 'VENDOR' | 'ADMIN';
  status: 'ACTIVE' | 'BANNED';
  balance: number;
  email: string;
  phone: string;
  joinedDate: string;
}

export interface AdminVendor {
  id: string;
  name: string;
  ownerName: string;
  category: string;
  rating: number;
  balance: number;
  status: 'APPROVED' | 'PENDING_APPROVAL' | 'REJECTED';
  joinedDate: string;
  productsCount: number;
  ordersCount: number;
  logo: string;
}

export interface AdminReport {
  id: string;
  title: string;
  reporterName: string;
  targetType: 'PRODUCT' | 'VENDOR' | 'USER';
  targetName: string;
  description: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  date: string;
  status: 'PENDING' | 'RESOLVED' | 'DISMISSED';
}

interface AdminConsoleProps {
  products: Product[];
  onAddProduct: (p: Product) => void;
  onEditProduct: (p: Product) => void;
  onDeleteProduct: (id: string) => void;
  
  categories: Category[];
  onAddCategory: (c: Category) => void;
  onEditCategory: (c: Category) => void;
  onDeleteCategory: (id: string) => void;

  orders: Order[];
  onUpdateOrderStatus: (orderId: string, nextStatus: Order['status']) => void;

  addLog: (layer: ArchLog['layer'], message: string, details?: string) => void;
  onAddNotification: (notif: NotificationItem) => void;

  reports?: AdminReport[];
  onResolveReport?: (reportId: string, action: 'RESOLVED' | 'DISMISSED') => void;

  // New multi-vendor hooks
  shop?: VendorShop | null;
  onApproveShop?: (decision: 'APPROVED' | 'REJECTED') => void;
}

export function AdminConsole({
  products,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  categories,
  onAddCategory,
  onEditCategory,
  onDeleteCategory,
  orders,
  onUpdateOrderStatus,
  addLog,
  onAddNotification,
  reports,
  onResolveReport,
  shop,
  onApproveShop,
}: AdminConsoleProps) {
  
  // 1. Core State Hooks
  const [activeTab, setActiveTab] = useState<number>(0); // 0: Dashboard, 1: Users, 2: Vendors, 3: Products, 4: Categories, 5: Orders, 6: Reports
  
  // 1.1 Seeding mock users database and list
  const [userList, setUserList] = useState<AdminUser[]>([
    { id: 'usr_1', name: 'کاوه مهرآیین', role: 'BUYER', status: 'ACTIVE', balance: 450000, email: 'mehrayin.kaveh@gmail.com', phone: '09123456789', joinedDate: '۱۴۰۴/۱۰/۱۲' },
    { id: 'usr_2', name: 'امیر احسان‌پور', role: 'VENDOR', status: 'ACTIVE', balance: 14500000, email: 'ehsanpour@useonline.shop', phone: '09129876543', joinedDate: '۱۴۰۴/۱۱/۰۵' },
    { id: 'usr_3', name: 'زهرا محمدی', role: 'BUYER', status: 'ACTIVE', balance: 120000, email: 'zahra.m@gmail.com', phone: '09351112233', joinedDate: '۱۴۰۴/۱۲/۰۱' },
    { id: 'usr_4', name: 'سجاد اسدی', role: 'BUYER', status: 'BANNED', balance: 0, email: 'asadi@yahoo.com', phone: '09307778899', joinedDate: '۱۴۰۵/۰۱/۱۵' },
    { id: 'usr_5', name: 'سارا رضایی', role: 'ADMIN', status: 'ACTIVE', balance: 2500000, email: 'sara.admin@useonline.shop', phone: '09121112233', joinedDate: '۱۴۰۴/۰۱/۰۱' }
  ]);

  // 1.2 Seeding mock vendors database
  const [vendorList, setVendorList] = useState<AdminVendor[]>([
    { id: 'vnd_1', name: 'یوزآنلاین دیجیتال', ownerName: 'امیر احسان‌پور', category: 'کالای دیجیتال', rating: 4.9, balance: 28400000, status: 'APPROVED', joinedDate: '۱۴۰۴/۱۱/۰۵', productsCount: 4, ordersCount: 42, logo: 'UD' },
    { id: 'vnd_2', name: 'پردیس کالا', ownerName: 'مهدی پردیسی', category: 'کالای دیجیتال', rating: 4.7, balance: 12200000, status: 'APPROVED', joinedDate: '۱۴۰۴/۱۱/۲۰', productsCount: 3, ordersCount: 29, logo: 'PK' },
    { id: 'vnd_3', name: 'گالری شیک‌‌پوش', ownerName: 'الناز شاکری', category: 'مد و پوشاک', rating: 4.5, balance: 4800000, status: 'APPROVED', joinedDate: '۱۴۰۴/۱۲/۱۰', productsCount: 2, ordersCount: 15, logo: 'SP' },
    { id: 'vnd_4', name: 'زرین مارکت', ownerName: 'رضا کریمی', category: 'کالاهای سوپرمارکتی', rating: 0.0, balance: 0, status: 'PENDING_APPROVAL', joinedDate: '۱۴۰۵/۰۳/۱۴', productsCount: 0, ordersCount: 0, logo: 'ZM' },
    { id: 'vnd_5', name: 'دکوراسیون مدرن', ownerName: 'مسعود مرادی', category: 'خانه و آشپزخانه', rating: 4.2, balance: -350000, status: 'REJECTED', joinedDate: '۱۴۰۵/۰۲/۰۱', productsCount: 0, ordersCount: 2, logo: 'DM' }
  ]);

  // 1.3 Seeding mock reports (Tickets) database
  const [localReportList, setLocalReportList] = useState<AdminReport[]>([
    { id: 'rep_1', title: 'تاخیر در ارسال تبلت شیائومی', reporterName: 'کاوه مهرآیین', targetType: 'VENDOR', targetName: 'گالری شیک‌‌پوش', description: 'سفارش ثبت شده من پس از ۴ روز هنوز ارسال نشده و غرفه‌دار پاسخگو نیست.', severity: 'HIGH', date: '۱۴۰۵/۰۳/۱۵', status: 'PENDING' },
    { id: 'rep_2', title: 'اشتباه بودن فرکانس تراشه پردازنده', reporterName: 'زهرا محمدی', targetType: 'PRODUCT', targetName: 'iPhone 15 Pro Max', description: 'توضیحات فیلد پردازنده ثبت شده فرکانس ۳.۲ گیگاهرتز دارد در صورتیکه نسخه اصلی ۳.۴۶ گیگاهرتز است.', severity: 'LOW', date: '۱۴۰۵/۰۳/۱۰', status: 'RESOLVED' },
    { id: 'rep_3', title: 'شکایت از عدم تطابق تصویر عطر با کالا', reporterName: 'وحید ناصری', targetType: 'PRODUCT', targetName: 'ادو پرفیوم مردانه بلو د شنل', description: 'تصویر شیشه ۱۰۰ میل است اما عطر ارسالی ۵۰ میل است. تقاضای خسارت دارم.', severity: 'MEDIUM', date: '۱۴۰۵/۰۳/۰۴', status: 'PENDING' },
    { id: 'rep_4', title: 'نامناسب بودن لحن پشتیبان در بخش پیام', reporterName: 'گلناز راد', targetType: 'USER', targetName: 'پشتیبانی فنی', description: 'پشتیبان شماره دو رفتاری عصبانی و لحنی غیرحرفه‌ای داشت.', severity: 'LOW', status: 'DISMISSED', date: 'یک هفته پیش' }
  ]);

  const reportList = reports || localReportList;

  // Search filter and states
  const [userSearch, setUserSearch] = useState('');
  const [vendorSearch, setVendorSearch] = useState('');
  const [productSearch, setProductSearch] = useState('');
  const [orderSearch, setOrderSearch] = useState('');
  const [categorySearch, setCategorySearch] = useState('');
  const [reportSearch, setReportSearch] = useState('');

  // 1.4 Category Creation / Modification States
  const [addCatName, setAddCatName] = useState('');
  const [addCatIcon, setAddCatIcon] = useState('FolderOpen');
  const [catImagePreview, setCatImagePreview] = useState('https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=300&auto=format&fit=crop&q=80');
  const [isAddingCat, setIsAddingCat] = useState(false);
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editCatName, setEditCatName] = useState('');

  // User wallet edit tool states
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editUserBalance, setEditUserBalance] = useState('');
  
  // Product Edit Form State inline overlay
  const [quickStockId, setQuickStockId] = useState<string | null>(null);
  const [quickStockVal, setQuickStockVal] = useState<number>(0);

  // 1.5 Selection states for bulk actions
  const [selectedUserIds, setSelectedUserIds] = useState<string[]>([]);
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);

  // Sales statistics calculations based on live orders
  const staticStats = useMemo(() => {
    // calculate actual totals
    const totalSalesFromStored = orders.reduce((acc, curr) => acc + curr.totalPrice, 0);
    // Add seed transactions for mock volume
    const baseRevenue = 248900000;
    const currentRevenue = baseRevenue + totalSalesFromStored;
    const userGrowth = 8.4;
    const vendorRateCount = vendorList.filter(v => v.status === 'APPROVED').length;
    
    return {
      revenue: currentRevenue,
      ordersCount: 142 + orders.length,
      usersCount: 1250,
      vendorsCount: vendorRateCount,
      growth: userGrowth
    };
  }, [orders, vendorList]);

  // 2. Persian Digit conversion templates
  const toPersianDigits = (num: number | string) => {
    const id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/[0-9]/g, (w) => id[+w]);
  };

  const formatPrice = (price: number) => {
    const formatted = price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return toPersianDigits(formatted);
  };

  // 3. Admin Usecases Handler Handlers
  const handleToggleUserBan = (userId: string) => {
    setUserList(prev => prev.map(usr => {
      if (usr.id === userId) {
        const nextStatus = usr.status === 'ACTIVE' ? 'BANNED' : 'ACTIVE';
        addLog('USECASE', `فراخوانی ToggleUserStatusUseCase (${usr.name})`, `وضعیت جدید: ${nextStatus}`);
        addLog('DATASOURCE', `به‌روزرسانی رکورد کاربر ${userId} در پایگاه‌داده`, `Status: ${nextStatus}`);
        
        onAddNotification({
          id: Math.random().toString(),
          title: `سیستم ایمنی بازارچه 🛡️`,
          body: `وضعیت کاربر "${usr.name}" به علت مسائل انضباطی به ${nextStatus === 'BANNED' ? 'مسدود شده' : 'فعال'} تغییر یافت.`,
          time: 'هم‌اکنون',
          type: 'SYSTEM',
          isRead: false
        });

        return { ...usr, status: nextStatus };
      }
      return usr;
    }));
  };

  const handleUpdateUserRole = (userId: string, targetRole: AdminUser['role']) => {
    setUserList(prev => prev.map(usr => {
      if (usr.id === userId) {
        addLog('USECASE', `ارتقای نقش کاربری: ${usr.name}`, `نقش قبلی: ${usr.role} -> نقش جدید: ${targetRole}`);
        
        onAddNotification({
          id: Math.random().toString(),
          title: `دسترسی سیستمی جدید 🔑`,
          body: `نقش حساب کاربری "${usr.name}" در هسته امنیتی به "${targetRole}" ارتقا یافت.`,
          time: 'هم‌اکنون',
          type: 'SYSTEM',
          isRead: false
        });

        return { ...usr, role: targetRole };
      }
      return usr;
    }));
  };

  const handleUpdateUserBalance = (userId: string) => {
    const parsed = parseInt(editUserBalance.replace(/[^\d]/g, ''), 10);
    if (isNaN(parsed) || parsed < 0) return;

    setUserList(prev => prev.map(usr => {
      if (usr.id === userId) {
        addLog('REPOSITORY', `ویرایش مستقیم ولت مالی کاربر: ${usr.name}`, `اعتبار فیزیکی قبلی: ${usr.balance} -> جدید: ${parsed}`);
        setEditingUserId(null);
        setEditUserBalance('');
        return { ...usr, balance: parsed };
      }
      return usr;
    }));
  };

  const handleOnboardVendor = (vendorId: string, decision: 'APPROVED' | 'REJECTED') => {
    if (vendorId === 'my_registered_shop') {
      if (onApproveShop) {
        onApproveShop(decision);
      }
    }
    setVendorList(prev => {
      const exists = prev.some(v => v.id === vendorId);
      if (!exists && vendorId === 'my_registered_shop' && shop) {
        return [
          {
            id: 'my_registered_shop',
            name: shop.name,
            ownerName: 'شما (کاربر فعلی)',
            category: 'کالای دیجیتال',
            rating: 5.0,
            balance: shop.balance,
            status: decision,
            joinedDate: 'هم‌اکنون',
            productsCount: products.filter(p => p.vendor?.name === shop.name).length,
            ordersCount: shop.ordersCount,
            logo: shop.logo
          },
          ...prev
        ];
      }
      return prev.map(v => {
        if (v.id === vendorId) {
          addLog('USECASE', `تصمیم‌گیری پذیرش غرفه‌دار: ${v.name}`, `رای مدیریت: ${decision}`);
          
          onAddNotification({
            id: Math.random().toString(),
            title: `بررسی وضعیت غرفه بازارچه 🏪`,
            body: `درخواست احراز صلاحیت غرفه "${v.name}" توسط مدیریت سیستم ${decision === 'APPROVED' ? 'تایید و بلافاصله افتتاح شد' : 'رد گردید'}.`,
            time: 'هم‌اکنون',
            type: 'SYSTEM',
            isRead: false
          });

          return { ...v, status: decision };
        }
        return v;
      });
    });
  };

  const handleAdjustVendorBalance = (vendorId: string, amount: number) => {
    setVendorList(prev => prev.map(v => {
      if (v.id === vendorId) {
        const nextBal = v.balance + amount;
        addLog('DATASOURCE', `به‌روزرسانی همزمان تراز مالی فروشگاه ${v.name}`, `مبلغ: ${amount.toLocaleString()} تومان`);
        return { ...v, balance: nextBal };
      }
      return v;
    }));
  };

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addCatName.trim()) return;

    const newId = 'cat_' + Math.random().toString(36).substring(2, 6);
    const newCat: Category = {
      id: newId,
      name: addCatName.trim(),
      icon: addCatIcon,
      subcategories: [
        { id: `${newId}_sub1`, name: `عمومی ${addCatName}`, image: catImagePreview }
      ]
    };

    onAddCategory(newCat);
    addLog('USECASE', `ایجکت دسته‌بندی جدید به کاتالوگ فروش شاپ`, newCat.name);
    addLog('REPOSITORY', `درج دسته‌بندی در رم SQLite با نام شناسه ${newId}`, `تعداد زیرشاخه‌ها: ۱`);

    setAddCatName('');
    setIsAddingCat(false);
  };

  const handleSaveEditCat = (catId: string) => {
    if (!editCatName.trim()) return;
    const original = categories.find(c => c.id === catId);
    if (original) {
      const updated: Category = { ...original, name: editCatName.trim() };
      onEditCategory(updated);
      setEditingCatId(null);
      setEditCatName('');
      addLog('USECASE', 'اصلاح اطلاعات دسته‌بندی با موفقیت بروز شد', updated.name);
    }
  };

  const handleResolveReport = (reportId: string, action: 'RESOLVED' | 'DISMISSED') => {
    if (onResolveReport) {
      onResolveReport(reportId, action);
      return;
    }
    setLocalReportList(prev => prev.map(rep => {
      if (rep.id === reportId) {
        addLog('USECASE', 'بروزرسانی تیکت شکایتی رول پشتیبانی ادمین', `شناسه شکایت: ${reportId}, وضعیت جدید: ${action}`);
        
        onAddNotification({
          id: Math.random().toString(),
          title: `پاسخگویی به گزارشات ادمین 📨`,
          body: `گزارش ثبت شده شما با عنوان "${rep.title}" پس از بررسی ادمین به وضعیت "${action === 'RESOLVED' ? 'رفع شد' : 'بایگانی‌شده'}" درآمد.`,
          time: 'هم‌اکنون',
          type: 'ORDER',
          isRead: false
        });

        return { ...rep, status: action };
      }
      return rep;
    }));
  };

  // Dynamically blend the user registered shop into the admin list
  const mergedVendorList = useMemo(() => {
    if (shop) {
      const exists = vendorList.some(v => v.id === 'my_registered_shop');
      if (!exists) {
        const userVendor = {
          id: 'my_registered_shop',
          name: shop.name,
          ownerName: 'شما (کاربر فعلی)',
          category: shop.category === 'digital' ? 'کالای دیجیتال' : shop.category === 'apparel' ? 'مد و پوشاک' : shop.category === 'home' ? 'خانه و آشپزخانه' : shop.category === 'cosmetics' ? 'آرایشی و بهداشتی' : 'سایر',
          rating: shop.rating,
          balance: shop.balance,
          status: shop.status || 'PENDING_APPROVAL',
          joinedDate: shop.joinedDate || 'هم‌اکنون',
          productsCount: products.filter(p => p.vendor?.name === shop.name).length,
          ordersCount: shop.ordersCount,
          logo: shop.logo
        };
        return [userVendor, ...vendorList];
      } else {
        return vendorList.map(v => {
          if (v.id === 'my_registered_shop') {
            return {
              ...v,
              name: shop.name,
              status: shop.status || 'PENDING_APPROVAL',
              balance: shop.balance,
              productsCount: products.filter(p => p.vendor?.name === shop.name).length,
              logo: shop.logo
            };
          }
          return v;
        });
      }
    }
    return vendorList;
  }, [vendorList, shop, products]);

  // 4. Filtering arrays dynamically
  const filteredUsers = userList.filter(u => 
    u.name.toLowerCase().includes(userSearch.toLowerCase()) || 
    u.phone.includes(userSearch) || 
    u.email.toLowerCase().includes(userSearch.toLowerCase())
  );

  const filteredVendors = mergedVendorList.filter(v =>
    v.name.toLowerCase().includes(vendorSearch.toLowerCase()) ||
    v.ownerName.toLowerCase().includes(vendorSearch.toLowerCase())
  );

  const filteredProducts = products.filter(p =>
    p.title.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.englishTitle.toLowerCase().includes(productSearch.toLowerCase()) ||
    p.category.toLowerCase().includes(productSearch.toLowerCase()) ||
    (p.vendor && p.vendor.name.toLowerCase().includes(productSearch.toLowerCase()))
  );

  const filteredOrders = orders.filter(o =>
    o.id.toLowerCase().includes(orderSearch.toLowerCase()) ||
    o.trackingNumber.includes(orderSearch)
  );

  const filteredCategories = categories.filter(c =>
    c.name.toLowerCase().includes(categorySearch.toLowerCase())
  );

  const filteredReports = reportList.filter(r =>
    r.title.toLowerCase().includes(reportSearch.toLowerCase()) ||
    r.reporterName.toLowerCase().includes(reportSearch.toLowerCase()) ||
    r.targetName.toLowerCase().includes(reportSearch.toLowerCase())
  );

  // Helper to trigger a CSV file download
  const exportToCSV = (data: any[], fileName: string, headers: string[]) => {
    // UTF-8 with BOM to ensure correct Farsi/Arabic encoding in Microsoft Excel
    const BOM = '\uFEFF';
    const csvContent = BOM + [
      headers.join(','),
      ...data.map(row => 
        row.map((val: any) => {
          const str = val === undefined || val === null ? '' : String(val);
          // escape double quotes and wrap in quotes to prevent issue with commas
          return `"${str.replace(/"/g, '""')}"`;
        }).join(',')
      )
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${fileName}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleExportUsers = () => {
    const headers = [
      'شناسه کاربر',
      'نام و نام خانوادگی',
      'نقش',
      'وضعیت',
      'اعتبار کیف پول (ریال)',
      'ایمیل',
      'شماره تلفن',
      'تاریخ عضویت'
    ];
    
    const rows = filteredUsers.map(user => [
      user.id,
      user.name,
      user.role === 'ADMIN' ? 'مدیر سیستم' : user.role === 'VENDOR' ? 'غرفه‌دار' : 'خریدار',
      user.status === 'ACTIVE' ? 'فعال' : 'مسدودشده',
      user.balance.toString(),
      user.email,
      user.phone,
      user.joinedDate
    ]);

    exportToCSV(rows, 'useonline_users_report', headers);
    addLog('REPOSITORY', 'خروجی گزارش CSV کاربران ادمین', `تعداد کاربران: ${rows.length}`);
    onAddNotification({
      id: Math.random().toString(),
      title: '📊 گزارش کاربران صادر شد',
      body: `فایل CSV شامل اطلاعات ${toPersianDigits(rows.length)} کاربر با موفقیت تولید و دانلود شد.`,
      time: 'هم‌اکنون',
      type: 'SYSTEM',
      isRead: false
    });
  };

  const handleExportProducts = () => {
    const headers = [
      'شناسه کالا',
      'عنوان فارسی',
      'عنوان انگلیسی',
      'قیمت (تومان)',
      'قیمت اصلی (تومان)',
      'امتیاز',
      'تعداد نظرات',
      'موجودی انبار',
      'دسته بندی',
      'نام غرفه'
    ];
    
    const rows = filteredProducts.map(p => [
      p.id,
      p.title,
      p.englishTitle || '',
      p.price.toString(),
      p.originalPrice ? p.originalPrice.toString() : p.price.toString(),
      p.rating ? p.rating.toString() : '0',
      p.reviewsCount ? p.reviewsCount.toString() : '0',
      p.stock !== undefined ? p.stock.toString() : '0',
      p.category,
      p.vendor ? p.vendor.name : 'یوزآنلاین سیستم'
    ]);

    exportToCSV(rows, 'useonline_products_catalogue', headers);
    addLog('REPOSITORY', 'خروجی گزارش CSV محصولات کاتالوگ', `تعداد کالاها: ${rows.length}`);
    onAddNotification({
      id: Math.random().toString(),
      title: '📊 گزارش کاتالوگ محصولات صادر شد',
      body: `فایل CSV شامل اطلاعات ${toPersianDigits(rows.length)} کالا با موفقیت تولید و دانلود شد.`,
      time: 'هم‌اکنون',
      type: 'SYSTEM',
      isRead: false
    });
  };

  return (
    <div className="bg-[#111418] border border-[#191e24] rounded-3xl h-full flex flex-col font-vazir text-right overflow-hidden shadow-2xl relative" dir="rtl" id="admin-workspace-console">
      
      {/* Console Top Header */}
      <div className="bg-[#161a20] px-5 py-4 border-b border-[#222931] flex flex-col md:flex-row justify-between items-start md:items-center gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white border border-indigo-500/30">
            <ShieldCheck className="w-5 h-5 text-indigo-100" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white flex items-center gap-2">
              کنسول ارشد مدیریت بازارچه (UseOnline Suite)
              <span className="bg-red-500/10 text-red-400 border border-red-500/25 text-[8.5px] font-black px-2.5 py-0.5 rounded-full animate-pulse">
                حالت امنیتی روت برقرار است
              </span>
            </h2>
            <p className="text-[10px] text-slate-400 mt-1">مدیریت کامل بر کاربران، پذیرش غرفه‌داران گالری، محصولات کاتالوگ، تسویه سود و فیلترینگ شکایات</p>
          </div>
        </div>

        {/* Action Panel Refresh */}
        <div className="flex items-center gap-2" dir="ltr">
          <span className="text-[9px] text-slate-500 font-mono font-bold">Session ID: useonline_sys_{toPersianDigits('2026')}</span>
          <button 
            onClick={() => {
              addLog('DATASOURCE', 'همگام‌سازی اجباری و پاکسازی سطل کش ادمین انجام شد');
              onAddNotification({
                id: Math.random().toString(),
                title: 'تطابق کامل دیتابیس 🔄',
                body: 'کنترل‌گر سیستم با موفقیت تمام جداول SQLite و نمودارهای بازارچه را با دستگاه شبیه‌ساز اندروید همگام‌سازی نمود.',
                time: 'هم‌اکنون',
                type: 'SYSTEM',
                isRead: false
              });
            }}
            className="p-1.5 bg-[#1f252f] hover:bg-[#28303d] text-slate-300 rounded-lg active:scale-95 transition border border-white/5 flex items-center justify-center"
            title="همگام‌سازی داده‌ها"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Primary Tab Bar Menu */}
      <div className="bg-[#13171d] px-4 py-2 border-b border-[#1b2129] flex overflow-x-auto gap-2.5 items-center scrollbar-none shrink-0">
        {[
          { label: 'داشبورد و آمار بازارچه', icon: TrendingUp },
          { label: 'مدیریت کاربران', icon: Users, badge: userList.length },
          { label: 'احراز صلاحیت غرفه‌ها', icon: Store, badge: vendorList.filter(v => v.status === 'PENDING_APPROVAL').length },
          { label: 'کاتالوگ کالاها', icon: ShoppingBag, badge: products.length },
          { label: 'دسته‌بندی‌ها', icon: FolderTree, badge: categories.length },
          { label: 'سفارشات عموم', icon: FileText, badge: orders.length },
          { label: 'شکایات و تیکت‌ها', icon: AlertTriangle, badge: reportList.filter(r => r.status === 'PENDING').length }
        ].map((tab, idx) => (
          <button
            key={idx}
            onClick={() => {
              addLog('UI', `تغییر تب مدیریت ادمین به: ${tab.label}`);
              setActiveTab(idx);
            }}
            className={`px-3 py-2 rounded-xl text-[10px] font-black whitespace-nowrap transition flex items-center gap-1.5 shrink-0 ${
              activeTab === idx 
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10' 
                : 'text-slate-400 hover:bg-[#1a2028] hover:text-white'
            }`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            <span>{tab.label}</span>
            {tab.badge !== undefined && tab.badge > 0 && (
              <span className={`text-[8px] font-mono px-1.5 py-0.2 rounded-full ${activeTab === idx ? 'bg-indigo-700 text-white' : 'bg-red-500/20 text-red-400'}`}>
                {toPersianDigits(tab.badge)}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Main Console Tab Workspace Frame */}
      <div className="flex-1 overflow-y-auto p-5 text-right flex flex-col gap-5 min-h-0 bg-[#0f1114]">
        
        {/* ========================================================================================= */}
        {/* TAB 0: ANALYTICS & SALES STATISTICS */}
        {/* ========================================================================================= */}
        {activeTab === 0 && (
          <div className="flex flex-col gap-6 animate-fade-in">
            {/* Grid Stats blocks */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-[#161a20] border border-[#212831]/60 p-4 rounded-2xl flex flex-col gap-1 shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/5 rounded-full blur-xl group-hover:scale-150 transition-all duration-500" />
                <span className="text-[10px] text-slate-400 font-bold">کل درآمد و جریان تراز مالی</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-lg font-black text-emerald-400 font-mono">{formatPrice(staticStats.revenue)}</span>
                  <span className="text-[10px] text-slate-400 font-medium">تومان</span>
                </div>
                {/* Micro SVG Sparkline (No dependencies, extremely lightweight & elegant) */}
                <div className="h-6 w-full mt-3 opacity-80">
                  <svg className="w-full h-full" viewBox="0 0 100 20" preserveAspectRatio="none">
                    <path d="M0,15 Q15,4 30,10 T60,5 T80,14 T100,2" fill="none" stroke="#34d399" strokeWidth="2.5" />
                  </svg>
                </div>
                <span className="text-[8px] text-emerald-400 font-black mt-2 flex items-center gap-0.5" dir="ltr">
                  +۱۴.۸٪ ۳۰روز گذشته
                </span>
              </div>

              <div className="bg-[#161a20] border border-[#212831]/60 p-4 rounded-2xl flex flex-col gap-1 shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/5 rounded-full blur-xl group-hover:scale-150 transition-all duration-500" />
                <span className="text-[10px] text-slate-400 font-bold">کل تراکنش‌ها و سفارشات</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-lg font-black text-blue-400 font-mono">{toPersianDigits(staticStats.ordersCount)}</span>
                  <span className="text-[10px] text-slate-400 font-medium">سفارش</span>
                </div>
                <div className="h-6 w-full mt-3 opacity-80">
                  <svg className="w-full h-full" viewBox="0 0 100 20" preserveAspectRatio="none">
                    <path d="M0,10 Q12,18 25,12 T50,2 T75,9 T100,5" fill="none" stroke="#60a5fa" strokeWidth="2.5" />
                  </svg>
                </div>
                <span className="text-[8px] text-blue-400 font-bold mt-2 flex items-center gap-0.5" dir="ltr">
                  {toPersianDigits('18')} سفارش لایو امروز
                </span>
              </div>

              <div className="bg-[#161a20] border border-[#212831]/60 p-4 rounded-2xl flex flex-col gap-1 shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-16 h-16 bg-indigo-500/5 rounded-full blur-xl group-hover:scale-150 transition-all duration-500" />
                <span className="text-[10px] text-slate-400 font-bold">کل کاربران ثبت‌نامی</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-lg font-black text-indigo-400 font-mono">{formatPrice(staticStats.usersCount)}</span>
                  <span className="text-[10px] text-slate-400 font-medium">حساب</span>
                </div>
                <div className="h-6 w-full mt-3 opacity-80">
                  <svg className="w-full h-full" viewBox="0 0 100 20" preserveAspectRatio="none">
                    <path d="M0,18 Q20,12 40,14 T80,3 T100,1" fill="none" stroke="#818cf8" strokeWidth="2.5" />
                  </svg>
                </div>
                <span className="text-[8px] text-indigo-400 font-bold mt-2 flex items-center gap-0.5" dir="ltr">
                  +{toPersianDigits(staticStats.growth)}٪ رشد کاربر فعال
                </span>
              </div>

              <div className="bg-[#161a20] border border-[#212831]/60 p-4 rounded-2xl flex flex-col gap-1 shadow-sm relative overflow-hidden group">
                <div className="absolute top-0 right-0 w-16 h-16 bg-amber-500/5 rounded-full blur-xl group-hover:scale-150 transition-all duration-500" />
                <span className="text-[10px] text-slate-400 font-bold">تعداد غرفه‌های فعال همکار</span>
                <div className="flex items-baseline gap-1 mt-1">
                  <span className="text-lg font-black text-amber-400 font-mono">{toPersianDigits(staticStats.vendorsCount)}</span>
                  <span className="text-[10px] text-slate-400 font-medium">فروشگاه</span>
                </div>
                <div className="h-6 w-full mt-3 opacity-80">
                  <svg className="w-full h-full" viewBox="0 0 100 20" preserveAspectRatio="none">
                    <path d="M0,12 Q24,18 48,15 T72,4 T100,8" fill="none" stroke="#fbbf24" strokeWidth="2.5" />
                  </svg>
                </div>
                <span className="text-[8px] text-amber-400 font-bold mt-2 flex items-center gap-0.5" dir="ltr">
                  {toPersianDigits('2')} غرفه در صف بررسی
                </span>
              </div>
            </div>

            {/* Custom Interactive SVG Graphs for dashboard analytics */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              
              {/* Sales value over time Chart */}
              <div className="bg-[#161a20] border border-[#212831]/60 p-5 rounded-3xl lg:col-span-8 flex flex-col gap-3 relative shadow-md">
                <div className="flex justify-between items-center pb-2 border-b border-[#212831]">
                  <span className="text-xs font-black text-white flex items-center gap-1.5">
                    <Activity className="w-4 h-4 text-indigo-500" />
                    نمودار روند مالی و نمودار فروش فصلی بازارچه
                  </span>
                  <span className="text-[9px] bg-slate-800 text-slate-300 font-bold px-2 py-0.5 rounded">بروزرسانی زنده</span>
                </div>

                <p className="text-[9px] text-slate-400 leading-relaxed font-semibold">
                  دریافت کل حجم فروش بازارچه بر حسب تومان از تراکنش‌های دکمه خرید در شبیه‌ساز تلفن به همراه جریان فروش ۳ ماهه گذشته به صورت لایو.
                </p>

                {/* Aesthetic vector chart layout with SVG grids */}
                <div className="h-44 w-full relative mt-3 bg-black/20 rounded-2xl flex items-center justify-center p-3" dir="ltr">
                  <svg className="w-full h-full flex-1" viewBox="0 0 500 150">
                    {/* SVG Grid lines */}
                    <line x1="0" y1="30" x2="500" y2="30" stroke="#1f2937" strokeWidth="1" strokeDasharray="3,3" />
                    <line x1="0" y1="75" x2="500" y2="75" stroke="#1f2937" strokeWidth="1" strokeDasharray="3,3" />
                    <line x1="0" y1="120" x2="500" y2="120" stroke="#1f2937" strokeWidth="1" strokeDasharray="3,3" />
                    
                    {/* SVG Area Under Path */}
                    <path
                      d="M 50 150 L 50 120 L 125 110 L 200 90 L 275 115 L 350 70 L 425 45 L 450 30 L 450 150 Z"
                      fill="url(#indigoGrad)"
                      opacity="0.15"
                    />
                    
                    {/* SVG Line Graph */}
                    <path 
                      d="M 50 120 L 125 110 L 200 90 L 275 115 L 350 70 L 425 45 L 450 30" 
                      fill="none" 
                      stroke="#6366f1" 
                      strokeWidth="3.5" 
                      strokeLinecap="round"
                    />

                    {/* Gradient Definitions */}
                    <defs>
                      <linearGradient id="indigoGrad" x1="0%" y1="0%" x2="0%" y2="100%">
                        <stop offset="0%" stopColor="#6366f1" />
                        <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
                      </linearGradient>
                    </defs>

                    {/* Nodes of graph */}
                    <circle cx="50" cy="120" r="4.5" fill="#13171d" stroke="#6366f1" strokeWidth="2.5" />
                    <circle cx="125" cy="110" r="4.5" fill="#13171d" stroke="#6366f1" strokeWidth="2.5" />
                    <circle cx="200" cy="90" r="4.5" fill="#13171d" stroke="#6366f1" strokeWidth="2.5" />
                    <circle cx="275" cy="115" r="4.5" fill="#13171d" stroke="#6366f1" strokeWidth="2.5" />
                    <circle cx="350" cy="70" r="4.5" fill="#13171d" stroke="#6366f1" strokeWidth="2.5" />
                    <circle cx="425" cy="45" r="4.5" fill="#13171d" stroke="#6366f1" strokeWidth="2.5" />
                    <circle cx="450" cy="30" r="5" fill="#34d399" stroke="#0f1114" strokeWidth="2" />
                    
                    {/* Tooltip Label on last node */}
                    <text x="350" y="20" fill="#34d399" fontSize="8" fontFamily="monospace" textAnchor="middle" fontWeight="bold">
                      فروش جاری: {toPersianDigits(staticStats.revenue / 1000000)}M+
                    </text>
                  </svg>

                  {/* Absolute X Axis Labels */}
                  <div className="absolute bottom-1 inset-x-0 flex justify-between px-10 text-[7.5px] text-slate-500 font-bold font-mono">
                    <span>فروردین (۱۰M)</span>
                    <span>اردیبهشت (۴۵M)</span>
                    <span>خرداد (امروز)</span>
                  </div>
                </div>
              </div>

              {/* Category distributions & Market share */}
              <div className="bg-[#161a20] border border-[#212831]/60 p-5 rounded-3xl lg:col-span-4 flex flex-col gap-3.5 relative shadow-md">
                <div className="pb-2 border-b border-[#212831]">
                  <span className="text-xs font-black text-white flex items-center gap-1.5">
                    <FolderTree className="w-4 h-4 text-amber-500" />
                    سهم بازار و تنوع دسته‌بندی
                  </span>
                </div>

                <p className="text-[9px] text-slate-400 leading-relaxed font-semibold">
                  نمای گستردگی محصولات فعال بازار بر اساس تک تک گروه‌بندی‌های کاتالوگ فروش.
                </p>

                {/* SVG Radial Chart */}
                <div className="flex-1 min-h-[140px] flex items-center justify-center gap-4 relative mt-2">
                  <div className="w-24 h-24 relative shrink-0">
                    <svg className="w-full h-full transform -rotate-90" viewBox="0 0 36 36">
                      {/* Gray circle backbone */}
                      <circle cx="18" cy="18" r="15.915" fill="none" stroke="#2a323d" strokeWidth="3" />
                      
                      {/* Segment 1: digital (50%) */}
                      <circle cx="18" cy="18" r="15.915" fill="none" stroke="#6366f1" strokeWidth="3.5" 
                        strokeDasharray="50 100" strokeDashoffset="0" />
                      
                      {/* Segment 2: apparel (30%) */}
                      <circle cx="18" cy="18" r="15.915" fill="none" stroke="#f59e0b" strokeWidth="3.5" 
                        strokeDasharray="30 100" strokeDashoffset="-50" />

                      {/* Segment 3: supermarket (20%) */}
                      <circle cx="18" cy="18" r="15.915" fill="none" stroke="#10b981" strokeWidth="3.5" 
                        strokeDasharray="20 100" strokeDashoffset="-80" />
                    </svg>
                    <div className="absolute inset-0 flex flex-col items-center justify-center">
                      <span className="text-[7px] text-slate-400 font-bold">کل کالاها</span>
                      <span className="text-xs font-black text-white font-mono">{toPersianDigits(products.length)}</span>
                    </div>
                  </div>

                  {/* Legend values */}
                  <div className="flex flex-col gap-1.5 text-right flex-1 select-none">
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full bg-indigo-500 shrink-0" />
                      <span className="text-[8px] font-black text-slate-300">دیجیتال: ۵۰٪</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
                      <span className="text-[8px] font-black text-slate-300">مد و لباس: ۳۰٪</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <div className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                      <span className="text-[8px] font-black text-slate-300">سوپرمارکت: ۲۰٪</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* ========================================================================================= */}
        {/* TAB 1: MANAGE USERS */}
        {/* ========================================================================================= */}
        {activeTab === 1 && (
          <div className="flex flex-col gap-4 animate-fade-in">
            {/* Search filter row */}
            <div className="bg-[#161a20] p-4 rounded-2xl flex flex-col md:flex-row gap-3 items-center justify-between border border-[#212831]">
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-slate-500 absolute top-2.5 right-3" />
                <input
                  type="text"
                  placeholder="جستجوی کاربر (نام، ایمیل، موبایل)..."
                  value={userSearch}
                  onChange={(e) => {
                    setUserSearch(e.target.value);
                    // Clear selection when filters change to avoid accidental out-of-view actions
                    setSelectedUserIds([]);
                  }}
                  className="w-full bg-[#1b2129] border border-white/5 py-2 pr-9 pl-4 text-[10px] rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-right font-medium"
                />
              </div>
              <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
                <span className="text-[9px] text-slate-400 font-bold">
                  تعداد موارد یافت شده: {toPersianDigits(filteredUsers.length)} نفر
                </span>
                <button
                  type="button"
                  onClick={handleExportUsers}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-[9px] font-black px-3.5 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
                  id="export-users-csv-btn"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>خروجی گزارش (CSV)</span>
                </button>
              </div>
            </div>

            {/* Bulk actions panel for selected users */}
            {selectedUserIds.length > 0 && (
              <div className="bg-[#141d26] border border-indigo-500/30 p-4 rounded-2xl flex flex-col xl:flex-row gap-4 items-center justify-between text-right animate-fade-in shadow-lg shadow-indigo-950/25">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs ring-2 ring-indigo-500/15">
                    {toPersianDigits(selectedUserIds.length)}
                  </div>
                  <div>
                    <span className="text-xs font-black text-white block">کاربر انتخاب شده برای عملیات گروهی</span>
                    <span className="text-[9px] text-slate-400 mt-0.5 block">نوع عملیات مدیریتی ارشد خود را انتخاب کنید</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2.5" dir="rtl">
                  {/* Bulk Role Update Dropdown */}
                  <span className="text-[9px] font-bold text-slate-300">تغییر نقش گروهی:</span>
                  <select
                    onChange={(e) => {
                      const newRole = e.target.value as AdminUser['role'];
                      if (!newRole) return;
                      setUserList(prev => prev.map(u => selectedUserIds.includes(u.id) ? { ...u, role: newRole } : u));
                      addLog('USECASE', `تغییر وضعیت نقش گروهی کاربران`, `تعداد: ${selectedUserIds.length} نفر به نقش ${newRole}`);
                      onAddNotification({
                        id: Math.random().toString(),
                        title: `تغییر نقش گروهی کاربران 🛡️`,
                        body: `نقش سیستم ${toPersianDigits(selectedUserIds.length)} کاربر به صورت دسته‌جمعی به "${newRole === 'ADMIN' ? 'مدیریت شاپ' : newRole === 'VENDOR' ? 'غرفه‌دار همکار' : 'خریدار عادی'}" ویرایش یافت.`,
                        time: 'هم‌اکنون',
                        type: 'SYSTEM',
                        isRead: false
                      });
                      e.target.value = ''; // Reset select
                    }}
                    className="bg-[#1b2129] border border-slate-700 text-[9px] py-1.5 px-2 bg-transparent rounded-xl text-slate-200 font-bold focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="">-- انتخاب نقش --</option>
                    <option value="BUYER">خـریدار</option>
                    <option value="VENDOR">غرفه‌دار همکار</option>
                    <option value="ADMIN">مدیریت (Admin)</option>
                  </select>

                  <div className="h-5 w-[1px] bg-slate-700/60 hidden sm:block mx-1" />

                  {/* Bulk Ban/Unban Buttons */}
                  <button
                    onClick={() => {
                      setUserList(prev => prev.map(u => selectedUserIds.includes(u.id) ? { ...u, status: 'BANNED' } : u));
                      addLog('USECASE', `مسدودسازی گروهی حساب‌های کاربری`, `تعداد: ${selectedUserIds.length} کاربر`);
                      onAddNotification({
                        id: Math.random().toString(),
                        title: `مسدودسازی گروهی 🚫`,
                        body: `حساب کاربری تعداد علمیاتی ${toPersianDigits(selectedUserIds.length)} نفر به علت نقص قوانین امنیتی مسدود گردید.`,
                        time: 'هم‌اکنون',
                        type: 'SYSTEM',
                        isRead: false
                      });
                    }}
                    className="bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 font-black text-[9px] py-1.5 px-3 rounded-xl active:scale-95 transition flex items-center gap-1 cursor-pointer"
                  >
                    <UserX className="w-3.5 h-3.5" />
                    <span>مسدودسازی گروهی</span>
                  </button>

                  <button
                    onClick={() => {
                      setUserList(prev => prev.map(u => selectedUserIds.includes(u.id) ? { ...u, status: 'ACTIVE' } : u));
                      addLog('USECASE', `رفع مسدودیت گروهی حساب‌های کاربری`, `تعداد: ${selectedUserIds.length} کاربر`);
                      onAddNotification({
                        id: Math.random().toString(),
                        title: `بروزرسانی وضعیت انضباطی کاربران 🟢`,
                        body: `رفع محدودیت گروهی تعداد ${toPersianDigits(selectedUserIds.length)} کاربر با تأیید نهایی ادمین اعمال شد.`,
                        time: 'هم‌اکنون',
                        type: 'SYSTEM',
                        isRead: false
                      });
                    }}
                    className="bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 font-black text-[9px] py-1.5 px-3 rounded-xl active:scale-95 transition flex items-center gap-1 cursor-pointer"
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    <span>فعال‌سازی گروهی</span>
                  </button>

                  {/* Bulk Delete */}
                  <button
                    onClick={() => {
                      if (confirm(`آیا از حذف کامل و پاکسازی دائمی ${selectedUserIds.length} کاربر مشخص‌شده اطمینان دارید؟ این عمل غیرقابل بازگشت است.`)) {
                        setUserList(prev => prev.filter(u => !selectedUserIds.includes(u.id)));
                        addLog('USECASE', `حذف گروهی کاربران از پایگاه داده`, `تعداد: ${selectedUserIds.length} نفر`);
                        setSelectedUserIds([]);
                        onAddNotification({
                          id: Math.random().toString(),
                          title: `حذف دسته‌جمعی کاربران 🗑️`,
                          body: `تعداد ${toPersianDigits(selectedUserIds.length)} حساب کاربری به صورت فیزیکی از دیتابیس ادمین پاکسازی شد.`,
                          time: 'هم‌اکنون',
                          type: 'SYSTEM',
                          isRead: false
                        });
                      }
                    }}
                    className="bg-rose-600 hover:bg-rose-700 text-white font-black text-[9px] py-1.5 px-3 rounded-xl active:scale-95 transition flex items-center gap-1 cursor-pointer shadow-md shadow-rose-950/20"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>حذف دائم گروهی</span>
                  </button>

                  <button
                    onClick={() => setSelectedUserIds([])}
                    className="text-slate-400 hover:text-white text-[9.5px] font-bold px-2 py-1 cursor-pointer"
                  >
                    لغو انتخاب
                  </button>
                </div>
              </div>
            )}

            {/* Users Spreadsheet Grid */}
            <div className="bg-[#161a20] rounded-2xl border border-[#212831] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-right text-[10px] select-none">
                  <thead>
                    <tr className="bg-[#1f252f] text-slate-300 font-black border-b border-[#2d3644]">
                      <th className="p-3 text-center w-12">
                        <input
                          type="checkbox"
                          checked={filteredUsers.length > 0 && filteredUsers.every(u => selectedUserIds.includes(u.id))}
                          onChange={(e) => {
                            if (e.target.checked) {
                              const newSelected = Array.from(new Set([...selectedUserIds, ...filteredUsers.map(u => u.id)]));
                              setSelectedUserIds(newSelected);
                            } else {
                              const filteredIds = filteredUsers.map(u => u.id);
                              setSelectedUserIds(selectedUserIds.filter(id => !filteredIds.includes(id)));
                            }
                          }}
                          className="w-3.5 h-3.5 accent-indigo-600 rounded bg-[#1f252f] border-slate-700 cursor-pointer"
                        />
                      </th>
                      <th className="p-3">شناسه</th>
                      <th className="p-3">نام کاربر</th>
                      <th className="p-3">اطلاعات تماس</th>
                      <th className="p-3 text-center">نقش سیستم</th>
                      <th className="p-3 text-center">انضباط</th>
                      <th className="p-3 text-left">موجودی کیف</th>
                      <th className="p-3 text-center">تاریخ عضویت</th>
                      <th className="p-3 text-center">عملیات ادمین</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1e252e]">
                    {filteredUsers.map((usr) => (
                      <tr key={usr.id} className={`transition-colors hover:bg-[#1a2029] ${selectedUserIds.includes(usr.id) ? 'bg-indigo-950/20' : ''}`}>
                        <td className="p-3 text-center w-12">
                          <input
                            type="checkbox"
                            checked={selectedUserIds.includes(usr.id)}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedUserIds([...selectedUserIds, usr.id]);
                              } else {
                                setSelectedUserIds(selectedUserIds.filter(id => id !== usr.id));
                              }
                            }}
                            className="w-3.5 h-3.5 accent-indigo-600 rounded bg-[#1f252f] border-slate-700 cursor-pointer"
                          />
                        </td>
                        <td className="p-3 font-mono text-slate-500">{usr.id}</td>
                        <td className="p-3 font-semibold text-white">
                          <div className="flex items-center gap-2">
                            <div className="w-7 h-7 bg-indigo-500/10 text-indigo-400 border border-indigo-500/10 rounded-full flex items-center justify-center font-black">
                              {usr.name[0]}
                            </div>
                            <span>{usr.name}</span>
                          </div>
                        </td>
                        <td className="p-3 leading-normal">
                          <span className="block text-slate-300 font-semibold font-mono">{toPersianDigits(usr.phone)}</span>
                          <span className="block text-[8.5px] text-slate-500 font-mono">{usr.email}</span>
                        </td>
                        <td className="p-3 text-center">
                          <select
                            value={usr.role}
                            onChange={(e) => handleUpdateUserRole(usr.id, e.target.value as AdminUser['role'])}
                            className="bg-[#1f2530] border border-white/5 text-[9px] font-black rounded-lg py-1 px-1.5 text-slate-200 outline-none"
                          >
                            <option value="BUYER">خـریدار</option>
                            <option value="VENDOR">غرفه‌دار همکار</option>
                            <option value="ADMIN">مدیریت (Admin)</option>
                          </select>
                        </td>
                        <td className="p-3 text-center">
                          {usr.status === 'ACTIVE' ? (
                            <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full text-[8.5px] font-black">فعال</span>
                          ) : (
                            <span className="bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-full text-[8.5px] font-black">مسدود</span>
                          )}
                        </td>
                        <td className="p-3 font-mono text-left text-indigo-300 font-black">
                          {editingUserId === usr.id ? (
                            <div className="flex items-center gap-1 justify-end">
                              <input
                                type="text"
                                value={editUserBalance}
                                onChange={(e) => setEditUserBalance(e.target.value)}
                                className="w-16 bg-[#1f252f] text-[9.5px] border border-white/10 rounded-md px-1 py-0.5 text-center text-white"
                                placeholder="تومان"
                              />
                              <button onClick={() => handleUpdateUserBalance(usr.id)} className="text-emerald-500 hover:text-emerald-400 font-bold">✔</button>
                              <button onClick={() => setEditingUserId(null)} className="text-red-500 hover:text-red-400 font-bold">✖</button>
                            </div>
                          ) : (
                            <div className="flex items-center justify-end gap-1">
                              <span>{formatPrice(usr.balance)}</span>
                              <button 
                                onClick={() => {
                                  setEditingUserId(usr.id);
                                  setEditUserBalance(usr.balance.toString());
                                }} 
                                className="text-slate-500 hover:text-white"
                                title="تغییر موجودی"
                              >
                                <Wallet className="w-3 h-3" />
                              </button>
                            </div>
                          )}
                        </td>
                        <td className="p-3 text-center text-slate-400">{usr.joinedDate}</td>
                        <td className="p-3 text-center">
                          <button
                            onClick={() => handleToggleUserBan(usr.id)}
                            className={`p-1.5 rounded-lg active:scale-95 transition flex items-center justify-center mx-auto ${
                              usr.status === 'ACTIVE' 
                                ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/10' 
                                : 'bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/10'
                            }`}
                            title={usr.status === 'ACTIVE' ? 'مسدود ساختن کاربر' : 'آزادسازی حساب'}
                          >
                            {usr.status === 'ACTIVE' ? (
                              <UserX className="w-3.5 h-3.5" />
                            ) : (
                              <UserCheck className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================================= */}
        {/* TAB 2: MANAGE VENDORS */}
        {/* ========================================================================================= */}
        {activeTab === 2 && (
          <div className="flex flex-col gap-4 animate-fade-in">
            {/* Filter row */}
            <div className="bg-[#161a20] p-4 rounded-2xl flex flex-col md:flex-row gap-3 items-center justify-between border border-[#212831]">
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-slate-500 absolute top-2.5 right-3" />
                <input
                  type="text"
                  placeholder="جستجوی نام غرفه یا مدیر غرفه..."
                  value={vendorSearch}
                  onChange={(e) => setVendorSearch(e.target.value)}
                  className="w-full bg-[#1b2129] border border-white/5 py-2 pr-9 pl-4 text-[10px] rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-right font-medium"
                />
              </div>
              <span className="text-[9px] text-slate-400 font-bold">
                تعداد کل غرفه‌های تعریف شده: {toPersianDigits(vendorList.length)} غرفه
              </span>
            </div>

            {/* Vendor List Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 select-none">
              {filteredVendors.map((vnd) => (
                <div key={vnd.id} className="bg-[#161a20] border border-[#212831] rounded-2xl p-4 flex flex-col gap-3 relative overflow-hidden">
                  <div className="flex items-center gap-2.5 pb-2.5 border-b border-[#1e252e]">
                    <div className="w-10 h-10 bg-indigo-500/10 text-indigo-400 font-black rounded-lg flex items-center justify-center text-xs">
                      {vnd.logo}
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="text-xs font-black text-white block truncate">{vnd.name}</span>
                      <span className="text-[8.5px] text-slate-400 block mt-0.5">مدیریت: {vnd.ownerName} | گروه کاری: {vnd.category}</span>
                    </div>
                    
                    {/* Status badge */}
                    {vnd.status === 'APPROVED' && (
                      <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[7.5px] px-1.5 py-0.5 rounded-full font-bold">فعال</span>
                    )}
                    {vnd.status === 'PENDING_APPROVAL' && (
                      <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[7.5px] px-1.5 py-0.5 rounded-full font-bold animate-pulse">در صف احراز</span>
                    )}
                    {vnd.status === 'REJECTED' && (
                      <span className="bg-red-500/10 text-red-400 border border-red-500/20 text-[7.5px] px-1.5 py-0.5 rounded-full font-bold">رد شده</span>
                    )}
                  </div>

                  {/* Operational stats */}
                  <div className="grid grid-cols-3 gap-2 bg-[#1b2129] p-2.5 rounded-xl text-center">
                    <div>
                      <span className="text-[7.5px] text-slate-400 block font-semibold">تعداد کالاها</span>
                      <span className="text-[10px] font-black text-white font-mono mt-0.5 block">{toPersianDigits(vnd.productsCount)} قلم</span>
                    </div>
                    <div>
                      <span className="text-[7.5px] text-slate-400 block font-semibold">تراکم سفارشات</span>
                      <span className="text-[10px] font-black text-white font-mono mt-0.5 block">{toPersianDigits(vnd.ordersCount)} بار</span>
                    </div>
                    <div>
                      <span className="text-[7.5px] text-slate-400 block font-semibold">رتبه غرفه</span>
                      <span className="text-[10px] font-black text-amber-400 font-mono mt-0.5 block">★ {toPersianDigits(vnd.rating)}</span>
                    </div>
                  </div>

                  {/* Financial Wallet and action buttons */}
                  <div className="flex items-center justify-between mt-1 pt-1">
                    <div>
                      <span className="text-[7.5px] text-slate-400 block font-semibold text-right">موجودی صندوق غرفه</span>
                      <span className="text-[10px] font-black text-indigo-300 font-mono">{formatPrice(vnd.balance)} تومان</span>
                    </div>

                    <div className="flex gap-1.5" dir="ltr">
                      {vnd.status === 'PENDING_APPROVAL' && (
                        <>
                          <button
                            onClick={() => handleOnboardVendor(vnd.id, 'APPROVED')}
                            className="bg-emerald-600 hover:bg-emerald-700 text-white text-[8px] font-black px-2.5 py-1 rounded"
                          >
                            تایید غرفه
                          </button>
                          <button
                            onClick={() => handleOnboardVendor(vnd.id, 'REJECTED')}
                            className="bg-red-500/15 hover:bg-red-500/20 text-red-400 text-[8px] font-black px-2.5 py-1 rounded"
                          >
                            رد غرفه
                          </button>
                        </>
                      )}

                      {vnd.status === 'APPROVED' && (
                        <div className="flex gap-1">
                          <button
                            onClick={() => handleAdjustVendorBalance(vnd.id, 500000)}
                            className="bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/10 text-[7px] font-extrabold px-1.5 py-1 rounded"
                            title="حق شارژ پرداختی سود ۵۰۰,۰۰۰"
                          >
                            شارژ سود +
                          </button>
                          <button
                            onClick={() => handleAdjustVendorBalance(vnd.id, -500000)}
                            className="bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/10 text-[7px] font-extrabold px-1.5 py-1 rounded"
                            title="تسویه حساب نقدی کسر ۵۰۰,۰۰۰"
                          >
                            تسویه نقدی -
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ========================================================================================= */}
        {/* TAB 3: MANAGE PRODUCTS CATALOGUE */}
        {/* ========================================================================================= */}
        {activeTab === 3 && (
          <div className="flex flex-col gap-4 animate-fade-in">
            {/* Top filter search list */}
            <div className="bg-[#161a20] p-4 rounded-2xl flex flex-col md:flex-row gap-3 items-center justify-between border border-[#212831]">
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-slate-500 absolute top-2.5 right-3" />
                <input
                  type="text"
                  placeholder="جستجوی کالا بر اساس عنوان کالا یا نام غرفه‌دار..."
                  value={productSearch}
                  onChange={(e) => {
                    setProductSearch(e.target.value);
                    // Clear selection when filters change to avoid accidental out-of-view actions
                    setSelectedProductIds([]);
                  }}
                  className="w-full bg-[#1b2129] border border-white/5 py-2 pr-9 pl-4 text-[10px] rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-right font-medium"
                />
              </div>
              <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
                <span className="text-[9px] text-slate-400 font-bold">
                  تعداد اقلام فروشگاه: {toPersianDigits(filteredProducts.length)} کالا
                </span>
                <button
                  type="button"
                  onClick={handleExportProducts}
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-[9px] font-black px-3.5 py-2 rounded-xl flex items-center gap-1.5 cursor-pointer shadow-md transition-all active:scale-95"
                  id="export-products-csv-btn"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>خروجی کاتالوگ (CSV)</span>
                </button>
              </div>
            </div>

            {/* Bulk actions panel for selected products */}
            {selectedProductIds.length > 0 && (
              <div className="bg-[#141d26] border border-indigo-500/30 p-4 rounded-2xl flex flex-col xl:flex-row gap-4 items-center justify-between text-right animate-fade-in shadow-lg shadow-indigo-950/25">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center font-bold text-xs ring-2 ring-indigo-500/15">
                    {toPersianDigits(selectedProductIds.length)}
                  </div>
                  <div>
                    <span className="text-xs font-black text-white block">کالا انتخاب شده برای عملیات گروهی</span>
                    <span className="text-[9px] text-slate-400 mt-0.5 block">نوع عملیات مدیریتی خود را بر روی کاتالوگ اعمال کنید</span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2.5" dir="rtl">
                  {/* Bulk stock reset */}
                  <span className="text-[9px] font-bold text-slate-300">موجودی انبار گروهی:</span>
                  <button
                    onClick={() => {
                      selectedProductIds.forEach(id => {
                        const original = products.find(p => p.id === id);
                        if (original) {
                          onEditProduct({ ...original, stock: 50 });
                        }
                      });
                      addLog('REPOSITORY', `تغییر وضعیت انبار و شارژ مجدد کالاها`, `تعداد: ${selectedProductIds.length} کالا`);
                      onAddNotification({
                        id: Math.random().toString(),
                        title: `شارژ مجدد انبار کالاها 📦`,
                        body: `انبار تعداد ${toPersianDigits(selectedProductIds.length)} کالای منتخب ادمین شارژ مجدد (موجودی ۵۰) گردید.`,
                        time: 'هم‌اکنون',
                        type: 'SYSTEM',
                        isRead: false
                      });
                    }}
                    className="bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-400 border border-indigo-500/20 font-black text-[9px] py-1.5 px-3 rounded-xl active:scale-95 transition flex items-center gap-1 cursor-pointer"
                  >
                    <span>شارژ انبار (موجودی ۵۰)</span>
                  </button>

                  <button
                    onClick={() => {
                      selectedProductIds.forEach(id => {
                        const original = products.find(p => p.id === id);
                        if (original) {
                          onEditProduct({ ...original, stock: 0 });
                        }
                      });
                      addLog('REPOSITORY', `ناموجود کردن گروهی کالاها`, `تعداد: ${selectedProductIds.length} کالا`);
                      onAddNotification({
                        id: Math.random().toString(),
                        title: `ناموجود کردن گروهی کالا 🚫`,
                        body: `تعداد ${toPersianDigits(selectedProductIds.length)} کالای منتخب ادمین در وضعیت ناموجود (انبار صفر) قرار گرفتند.`,
                        time: 'هم‌اکنون',
                        type: 'SYSTEM',
                        isRead: false
                      });
                    }}
                    className="bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/20 font-black text-[9px] py-1.5 px-3 rounded-xl active:scale-95 transition flex items-center gap-1 cursor-pointer"
                  >
                    <span>ناموجود کردن گروهی (انبار ۰)</span>
                  </button>

                  <div className="h-5 w-[1px] bg-slate-700/60 hidden sm:block mx-1" />

                  {/* Bulk Delete Products */}
                  <button
                    onClick={() => {
                      if (confirm(`آیا از حذف دائم و کامل ${selectedProductIds.length} کالا تحت نظارت ادمین اطمینان دارید؟`)) {
                        selectedProductIds.forEach(id => {
                          onDeleteProduct(id);
                        });
                        addLog('USECASE', `حذف گروهی محصولات از کاتالوگ سیستم`, `تعداد: ${selectedProductIds.length} کالا`);
                        setSelectedProductIds([]);
                        onAddNotification({
                          id: Math.random().toString(),
                          title: `حذف گروهی محصولات از کاتالوگ 🗑️`,
                          body: `تعداد ${toPersianDigits(selectedProductIds.length)} کالا توسط ادمین به طور کلی حذف و منقضی شدند.`,
                          time: 'هم‌اکنون',
                          type: 'SYSTEM',
                          isRead: false
                        });
                      }
                    }}
                    className="bg-rose-600 hover:bg-rose-700 text-white font-black text-[9px] py-1.5 px-3 rounded-xl active:scale-95 transition flex items-center gap-1 cursor-pointer shadow-md shadow-rose-950/20"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>حذف دائم گروهی</span>
                  </button>

                  <button
                    onClick={() => setSelectedProductIds([])}
                    className="text-slate-400 hover:text-white text-[9.5px] font-bold px-2 py-1 cursor-pointer"
                  >
                    لغو انتخاب
                  </button>
                </div>
              </div>
            )}

            {/* Products grid spreadsheets */}
            <div className="bg-[#161a20] rounded-2xl border border-[#212831] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-right text-[10px] select-none">
                  <thead>
                    <tr className="bg-[#1f252f] text-slate-300 font-black border-b border-[#2d3644]">
                      <th className="p-3 text-center w-12">
                        <input
                          type="checkbox"
                          checked={filteredProducts.length > 0 && filteredProducts.every(p => selectedProductIds.includes(p.id))}
                          onChange={(e) => {
                            if (e.target.checked) {
                              const newSelected = Array.from(new Set([...selectedProductIds, ...filteredProducts.map(p => p.id)]));
                              setSelectedProductIds(newSelected);
                            } else {
                              const filteredIds = filteredProducts.map(p => p.id);
                              setSelectedProductIds(selectedProductIds.filter(id => !filteredIds.includes(id)));
                            }
                          }}
                          className="w-3.5 h-3.5 accent-indigo-600 rounded bg-[#1f252f] border-slate-700 cursor-pointer"
                        />
                      </th>
                      <th className="p-3">شناسه کالا</th>
                      <th className="p-3 w-56">عنوان کالا</th>
                      <th className="p-3">دسته‌بندی اصلی</th>
                      <th className="p-3 text-center">انبارداری (تعداد موجود)</th>
                      <th className="p-3 text-left">قیمت فروش</th>
                      <th className="p-3 text-center">امتیاز کالا</th>
                      <th className="p-3 text-left">فروشنده همکار</th>
                      <th className="p-3 text-center">حذف و نظارت نهایی</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1e252e]">
                    {filteredProducts.map((prod) => {
                      const stockCount = prod.stock !== undefined ? prod.stock : 10;
                      return (
                        <tr key={prod.id} className={`transition-colors hover:bg-[#1a2029] ${selectedProductIds.includes(prod.id) ? 'bg-indigo-950/20' : ''}`}>
                          <td className="p-3 text-center w-12">
                            <input
                              type="checkbox"
                              checked={selectedProductIds.includes(prod.id)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedProductIds([...selectedProductIds, prod.id]);
                                } else {
                                  setSelectedProductIds(selectedProductIds.filter(id => id !== prod.id));
                                }
                              }}
                              className="w-3.5 h-3.5 accent-indigo-600 rounded bg-[#1f252f] border-slate-700 cursor-pointer"
                            />
                          </td>
                          <td className="p-3 font-mono text-slate-500">{prod.id}</td>
                          <td className="p-3 py-2 font-semibold text-white">
                            <div className="flex items-center gap-2">
                              <img src={prod.image} alt="" className="w-8 h-8 rounded-md object-cover bg-white" referrerPolicy="no-referrer" />
                              <div className="min-w-0 flex-1">
                                <span className="block text-slate-200 line-clamp-1 leading-normal">{prod.title}</span>
                                <span className="block text-[8px] text-slate-500 font-mono font-bold">{prod.englishTitle}</span>
                              </div>
                            </div>
                          </td>
                          <td className="p-3"><span className="bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md font-semibold">{prod.category}</span></td>
                          
                          {/* Live Inventory stocks */}
                          <td className="p-3 text-center font-mono">
                            {quickStockId === prod.id ? (
                              <div className="flex items-center gap-1 justify-center">
                                <input
                                  type="number"
                                  min={0}
                                  value={quickStockVal}
                                  onChange={(e) => setQuickStockVal(parseInt(e.target.value, 10) || 0)}
                                  className="w-12 bg-[#1f252f] text-center rounded text-white py-0.5 border border-white/10"
                                />
                                <button
                                  onClick={() => {
                                    const updated: Product = { ...prod, stock: quickStockVal };
                                    onEditProduct(updated);
                                    setQuickStockId(null);
                                    addLog('REPOSITORY', `ویرایش انبار کالا توسط ادمین: ${prod.title}`, `موجود: ${quickStockVal}`);
                                  }}
                                  className="bg-indigo-600 text-[8px] p-1 rounded"
                                >
                                  ثبت
                                </button>
                              </div>
                            ) : (
                              <div className="flex items-center justify-center gap-1.5">
                                <span className={`font-black ${stockCount === 0 ? 'text-red-500 font-extrabold animate-pulse' : 'text-slate-200'}`}>
                                  {toPersianDigits(stockCount)} کالا
                                </span>
                                <button 
                                  onClick={() => {
                                    setQuickStockId(prod.id);
                                    setQuickStockVal(stockCount);
                                  }}
                                  className="text-slate-500 hover:text-white"
                                >
                                  ✏️
                                </button>
                              </div>
                            )}
                          </td>
                          
                          <td className="p-3 text-left font-mono text-emerald-400 font-black">{formatPrice(prod.price)} تومان</td>
                          <td className="p-3 text-center font-mono text-amber-400 font-bold">★ {toPersianDigits(prod.rating)}</td>
                          <td className="p-3 text-left font-semibold text-slate-300">{prod.vendor.name}</td>
                          <td className="p-3 text-center">
                            <button
                              onClick={() => {
                                if (confirm(`آیا مطمئن هستید که می‌خواهید کالا تحت عنوان "${prod.title}" را با استفاده از اختیارات ادمین به کل مسدود و حذف فرمایید؟`)) {
                                  onDeleteProduct(prod.id);
                                }
                              }}
                              className="p-1 px-2 border border-red-500/10 text-red-100 bg-red-650 hover:bg-red-700 hover:border-red-600 rounded-md active:scale-95 transition"
                            >
                              حذف کالا
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}



        {/* ========================================================================================= */}
        {/* TAB 4: MANAGE CATEGORIES */}
        {/* ========================================================================================= */}
        {activeTab === 4 && (
          <div className="flex flex-col gap-5 animate-fade-in">
            {/* Top creation drawer form */}
            <div className="bg-[#161a20] p-5 rounded-3xl border border-[#212831] flex flex-col gap-3">
              <span className="text-xs font-black text-white flex items-center gap-1.5 mb-1">
                <FolderOpen className="w-4.5 h-4.5 text-indigo-500" />
                راه‌اندازی و تعریف دسته‌بندی جدید در مرکز فروش
              </span>
              
              <form onSubmit={handleCreateCategory} className="grid grid-cols-1 md:grid-cols-4 gap-3.5 items-end">
                <div>
                  <label className="text-[9px] font-black text-slate-300 block mb-1">عنوان دسته‌بندی اصلی</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: کتاب و فرهنگی"
                    value={addCatName}
                    onChange={(e) => setAddCatName(e.target.value)}
                    className="w-full bg-[#1b2129] border border-white/5 py-2 px-3 text-[10px] rounded-xl text-slate-100 outline-none focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="text-[9px] font-black text-slate-300 block mb-1">نام سمبل آیکون (Lucide)</label>
                  <input
                    type="text"
                    required
                    placeholder="BookOpen, Sparkles, Smartphone"
                    value={addCatIcon}
                    onChange={(e) => setAddCatIcon(e.target.value)}
                    className="w-full bg-[#1b2129] border border-white/5 py-2 px-3 text-[10px] rounded-xl text-slate-100 outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-left"
                  />
                </div>

                <div>
                  <label className="text-[9px] font-black text-slate-300 block mb-1">آدرس پیش‌نمایش تصویر زیرشاخه (Link)</label>
                  <input
                    type="text"
                    required
                    value={catImagePreview}
                    onChange={(e) => setCatImagePreview(e.target.value)}
                    className="w-full bg-[#1b2129] border border-white/5 py-2 px-3 text-[8.5px] rounded-xl text-slate-100 outline-none focus:ring-1 focus:ring-indigo-500 font-mono text-left"
                  />
                </div>

                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white font-black text-[10px] py-2 px-4 rounded-xl active:scale-95 transition flex items-center justify-center gap-1.5 h-[34px]"
                >
                  <Plus className="w-4 h-4" />
                  <span>ثبت دسته‌بندی ادمین</span>
                </button>
              </form>
            </div>

            {/* List and update categories */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {categories.map((cat) => (
                <div key={cat.id} className="bg-[#161a20] border border-[#212831] p-4 rounded-2xl flex flex-col gap-2 relative">
                  <div className="flex items-center justify-between pb-2 border-b border-[#1e252e]">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-lg bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
                        <FolderOpen className="w-4 h-4" />
                      </div>
                      <div>
                        {editingCatId === cat.id ? (
                          <input
                            type="text"
                            value={editCatName}
                            onChange={(e) => setEditCatName(e.target.value)}
                            onBlur={() => handleSaveEditCat(cat.id)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSaveEditCat(cat.id);
                            }}
                            className="bg-[#1f2530] text-[10px] px-2 py-0.5 rounded text-white font-semibold outline-none"
                            autoFocus
                          />
                        ) : (
                          <span className="text-xs font-black text-white">{cat.name}</span>
                        )}
                        <span className="block text-[8px] text-slate-500 font-mono mt-0.5">ID: {cat.id} / Icon: {cat.icon}</span>
                      </div>
                    </div>

                    <div className="flex gap-1" dir="ltr">
                      <button
                        onClick={() => {
                          setEditingCatId(cat.id);
                          setEditCatName(cat.name);
                        }}
                        className="p-1 text-slate-400 hover:text-white"
                        title="ویرایش نام"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`آیا می‌خواهید دسته‌بندی با نام "${cat.name}" را به همراه تمام اتصالات فرعی آن به کل زباله و نابود فرمایید؟`)) {
                            onDeleteCategory(cat.id);
                            addLog('USECASE', 'دسته‌بندی بازار زباله و حذف گردید', cat.name);
                          }
                        }}
                        className="p-1 text-red-500 hover:text-red-400"
                        title="حذف دسته‌بندی"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Subcategories list */}
                  <div className="flex flex-wrap gap-1.5 mt-1">
                    {cat.subcategories.map((sub) => (
                      <span key={sub.id} className="bg-slate-800 text-slate-300 font-bold text-[8.5px] px-2.5 py-1 rounded-md">
                        {sub.name}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ========================================================================================= */}
        {/* TAB 5: MANAGE ORDERS LIST */}
        {/* ========================================================================================= */}
        {activeTab === 5 && (
          <div className="flex flex-col gap-4 animate-fade-in">
            {/* Search filter row */}
            <div className="bg-[#161a20] p-4 rounded-2xl flex flex-col md:flex-row gap-3 items-center justify-between border border-[#212831]">
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-slate-500 absolute top-2.5 right-3" />
                <input
                  type="text"
                  placeholder="جستجوی سفارش بر حسب شناسه یا بارکد پستی..."
                  value={orderSearch}
                  onChange={(e) => setOrderSearch(e.target.value)}
                  className="w-full bg-[#1b2129] border border-white/5 py-2 pr-9 pl-4 text-[10px] rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-right font-medium"
                />
              </div>
              <span className="text-[9px] text-slate-400 font-bold">
                تعداد کل فاکتورها: {toPersianDigits(filteredOrders.length)} بار ثبت شده
              </span>
            </div>

            {/* Orders spreadsheet list view */}
            <div className="bg-[#161a20] rounded-2xl border border-[#212831] overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-right text-[10px] select-none">
                  <thead>
                    <tr className="bg-[#1f252f] text-slate-300 font-black border-b border-[#2d3644]">
                      <th className="p-3">سریال فاکتور (ID)</th>
                      <th className="p-3">تاریخ ثبت تراکنش</th>
                      <th className="p-3 text-center">تعداد اقلام خريد</th>
                      <th className="p-3 text-left">مجموع پرداختی ناخالص سفارش</th>
                      <th className="p-3 text-center">بارکد مرسوله پستی</th>
                      <th className="p-3 text-center">وضعیت مرسوله</th>
                      <th className="p-3 text-center">اقدام کنترلی ادمین</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1e252e]">
                    {filteredOrders.map((o) => (
                      <tr key={o.id} className="hover:bg-[#1a2029] transition-colors">
                        <td className="p-3 font-mono font-black text-indigo-400">{o.id}</td>
                        <td className="p-3 font-semibold text-slate-200">{o.date}</td>
                        <td className="p-3 text-center font-mono font-bold text-slate-300">{toPersianDigits(o.itemsCount)} عدد</td>
                        <td className="p-3 text-left font-mono text-emerald-400 font-black">{formatPrice(o.totalPrice)} T</td>
                        <td className="p-3 text-center font-mono font-bold text-slate-500">
                          {o.trackingNumber ? toPersianDigits(o.trackingNumber) : 'بدون بارکد'}
                        </td>
                        <td className="p-3 text-center">
                          {o.status === 'PENDING' && (
                            <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2.5 py-0.5 rounded-full text-[8.5px] font-black">معلق در صف</span>
                          )}
                          {o.status === 'PREPARING' && (
                            <span className="bg-blue-500/10 text-blue-400 border border-blue-500/20 px-2.5 py-0.5 rounded-full text-[8.5px] font-black animate-pulse">آماده‌سازی</span>
                          )}
                          {o.status === 'SHIPPED' && (
                            <span className="bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 px-2.5 py-0.5 rounded-full text-[8.5px] font-black">تحویل پست</span>
                          )}
                          {o.status === 'DELIVERED' && (
                            <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2.5 py-0.5 rounded-full text-[8.5px] font-black">تحویل نهایی مشتری</span>
                          )}
                        </td>
                        <td className="p-3 text-center">
                          <div className="flex gap-1 justify-center">
                            <button
                              onClick={() => {
                                onUpdateOrderStatus(o.id, 'SHIPPED');
                                addLog('USECASE', `تغییر وضعیت مرسوله ${o.id} به ارسالی در پست (SHIPPED)`);
                              }}
                              disabled={o.status === 'SHIPPED' || o.status === 'DELIVERED'}
                              className="px-2 py-1 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-30 disabled:hover:bg-indigo-600 text-white rounded text-[8px] font-black transition active:scale-95"
                            >
                              تحویل پست 🚚
                            </button>
                            <button
                              onClick={() => {
                                onUpdateOrderStatus(o.id, 'DELIVERED');
                                addLog('USECASE', `تغییر وضعیت مرسوله ${o.id} به تحویل شده نهایی (DELIVERED)`);
                              }}
                              disabled={o.status === 'DELIVERED'}
                              className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-30 disabled:hover:bg-emerald-600 text-white rounded text-[8px] font-black transition active:scale-95"
                            >
                              تحویل نهایی ✔
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================================= */}
        {/* TAB 6: MANAGE REPORT TICKETS */}
        {/* ========================================================================================= */}
        {activeTab === 6 && (
          <div className="flex flex-col gap-4 animate-fade-in font-medium select-none">
            {/* Filter row */}
            <div className="bg-[#161a20] p-4 rounded-2xl flex flex-col md:flex-row gap-3 items-center justify-between border border-[#212831]">
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-slate-500 absolute top-2.5 right-3" />
                <input
                  type="text"
                  placeholder="جستجوی شکایات، شاکی کالا..."
                  value={reportSearch}
                  onChange={(e) => setReportSearch(e.target.value)}
                  className="w-full bg-[#1b2129] border border-white/5 py-2 pr-9 pl-4 text-[10px] rounded-xl text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-right font-medium"
                />
              </div>
              <span className="text-[9px] text-slate-400 font-bold">
                تیکت‌های حل نشده: {toPersianDigits(reportList.filter(r => r.status === 'PEND').length)} تیکت
              </span>
            </div>

            {/* Complaints loop cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredReports.map((rep) => (
                <div key={rep.id} className="bg-[#161a20] border border-[#212831] p-4 rounded-2xl flex flex-col gap-3 relative overflow-hidden transition hover:border-slate-800">
                  
                  {/* Category strip */}
                  <div className="flex items-center justify-between pb-2 border-b border-[#1e252e]">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[9.5px] font-mono font-bold text-slate-400">[{rep.id}]</span>
                      <span className="text-xs font-black text-white">{rep.title}</span>
                    </div>

                    <div className="flex items-center gap-1.5" dir="ltr">
                      {rep.severity === 'HIGH' && (
                        <span className="bg-red-500/10 text-red-400 border border-red-500/15 text-[7.5px] px-2 py-0.5 rounded-md font-black animate-pulse">فوری خطیر</span>
                      )}
                      {rep.severity === 'MEDIUM' && (
                        <span className="bg-amber-500/10 text-amber-400 border border-amber-500/15 text-[7.5px] px-2 py-0.5 rounded-md font-black">متوسط</span>
                      )}
                      {rep.severity === 'LOW' && (
                        <span className="bg-[#1f2530] text-slate-400 border border-white/5 text-[7.5px] px-2 py-0.5 rounded-md font-black">عادی عمومی</span>
                      )}
                    </div>
                  </div>

                  {/* Complaint detail body */}
                  <p className="text-[9px] text-slate-300 leading-relaxed font-semibold bg-[#111418] p-3 rounded-xl border border-white/5">
                    {rep.description}
                  </p>

                  {/* Inspector items */}
                  <div className="grid grid-cols-2 gap-3 text-[8.5px] text-slate-400">
                    <div>
                      <span>شاکی پرونده: </span>
                      <strong className="text-slate-200">{rep.reporterName}</strong>
                    </div>
                    <div>
                      <span>هدف بررسی: </span>
                      <strong className="text-slate-200">{rep.targetType === 'PRODUCT' ? 'کالا ' : 'فروشنده '}({rep.targetName})</strong>
                    </div>
                  </div>

                  {/* Status controls and action submit bar */}
                  <div className="flex items-center justify-between border-t border-[#1e252e] pt-2.5 mt-1">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[8px] text-slate-500">وضعیت پرونده: </span>
                      {rep.status === 'PENDING' && (
                        <span className="text-[8.5px] text-amber-400 font-extrabold flex items-center gap-1">● در انتظار مربیگری</span>
                      )}
                      {rep.status === 'RESOLVED' && (
                        <span className="text-[8.5px] text-emerald-400 font-extrabold flex items-center gap-1">✔ خاتمه یافته</span>
                      )}
                      {rep.status === 'DISMISSED' && (
                        <span className="text-[8.5px] text-slate-400 font-extrabold flex items-center gap-1">✖ رد شکایت معلق</span>
                      )}
                    </div>

                    {rep.status === 'PENDING' && (
                      <div className="flex gap-2" dir="ltr">
                        <button
                          onClick={() => handleResolveReport(rep.id, 'RESOLVED')}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white text-[8px] font-black px-2.5 py-1 rounded"
                        >
                          خاتمه و احقاق حق 🎉
                        </button>
                        <button
                          onClick={() => handleResolveReport(rep.id, 'DISMISSED')}
                          className="bg-[#1f2530] hover:bg-[#2a303c] text-slate-300 text-[8px] font-black px-2.5 py-1 rounded border border-white/5"
                        >
                          رد پرونده ✖
                        </button>
                      </div>
                    )}
                  </div>

                </div>
              ))}
            </div>
          </div>
        )}

      </div>
      
    </div>
  );
}
