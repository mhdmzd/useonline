import React, { useState } from 'react';
import { User, Phone, Mail, Wallet, ShoppingBag, MapPin, ShieldCheck, Terminal, ToggleLeft, ToggleRight, Settings, PlusCircle, LogOut, Clock, Package, Truck, CheckCircle2, RefreshCw, ArrowUpDown, Edit, Trash2, Plus, Check, ChevronRight, X } from 'lucide-react';
import { Order, ArchLog, UserAddress } from '../../types';
import { motion, AnimatePresence } from 'motion/react';
import { OrderTrackingModal } from '../OrderTrackingModal';

interface ProfileTabProps {
  userName: string;
  userPhone: string;
  userEmail: string;
  onUpdateProfile: (name: string, phone: string, email: string) => void;
  addresses: UserAddress[];
  onUpdateAddresses: (addresses: UserAddress[]) => void;
  activeAddressId: string;
  onSetActiveAddressId: (id: string) => void;
  addLog: (layer: ArchLog['layer'], message: string, details: string) => void;
  orders: Order[];
  onLogout: () => void;
  vendorMode: boolean;
  onToggleVendorMode: (val: boolean) => void;
  onUpdateOrderStatus?: (orderId: string, nextStatus: Order['status']) => void;
  onOpenPaymentHistory?: () => void;
}

export function ProfileTab({
  userName,
  userPhone,
  userEmail,
  onUpdateProfile,
  addresses,
  onUpdateAddresses,
  activeAddressId,
  onSetActiveAddressId,
  addLog,
  orders,
  onLogout,
  vendorMode,
  onToggleVendorMode,
  onUpdateOrderStatus,
  onOpenPaymentHistory,
}: ProfileTabProps) {
  const [balance, setBalance] = useState(250000); // 250,000 Tomans
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [sortOrder, setSortOrder] = useState<'RECENT' | 'OLDEST'>('RECENT');
  const [selectedOrderForMap, setSelectedOrderForMap] = useState<Order | null>(null);

  // Profile Editing states
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [formName, setFormName] = useState(userName);
  const [formPhone, setFormPhone] = useState(userPhone);
  const [formEmail, setFormEmail] = useState(userEmail);
  const [profileError, setProfileError] = useState('');
  const [profileSuccess, setProfileSuccess] = useState('');
  const [isProfileSaving, setIsProfileSaving] = useState(false);

  // Dynamic User Address Management states
  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [editingAddressId, setEditingAddressId] = useState<string | null>(null);
  
  // Address form fields
  const [addrTitle, setAddrTitle] = useState('');
  const [addrReceiver, setAddrReceiver] = useState('');
  const [addrPhone, setAddrPhone] = useState('');
  const [addrZip, setAddrZip] = useState('');
  const [addrProvince, setAddrProvince] = useState('');
  const [addrCity, setAddrCity] = useState('');
  const [addrDetails, setAddrDetails] = useState('');
  const [addrError, setAddrError] = useState('');
  const [isAddrSaving, setIsAddrSaving] = useState(false);

  const handleOpenAddAddress = () => {
    setEditingAddressId(null);
    setAddrTitle('');
    setAddrReceiver(userName);
    setAddrPhone(userPhone);
    setAddrZip('');
    setAddrProvince('');
    setAddrCity('');
    setAddrDetails('');
    setAddrError('');
    setIsAddingAddress(true);
    addLog('UI', 'باز کردن فرم افزودن نشانی تحویل جدید', 'پیش فرض کلاف');
  };

  const handleOpenEditAddress = (addr: UserAddress) => {
    setEditingAddressId(addr.id);
    setAddrTitle(addr.title);
    setAddrReceiver(addr.receiverName);
    setAddrPhone(addr.phoneNumber);
    setAddrZip(addr.zipCode);
    setAddrProvince(addr.province);
    setAddrCity(addr.city);
    setAddrDetails(addr.details);
    setAddrError('');
    setIsAddingAddress(true);
    addLog('UI', `درخواست ویرایش نشانی با شناسه ${addr.id}`, `عنوان: ${addr.title}`);
  };

  const handleSaveAddress = (e: React.FormEvent) => {
    e.preventDefault();
    setAddrError('');
    
    // Validations
    if (!addrTitle.trim() || !addrReceiver.trim() || !addrPhone.trim() || !addrProvince.trim() || !addrCity.trim() || !addrDetails.trim()) {
      setAddrError('لطفاً تمامی فیلدهای ستاره‌دار را تکمیل کنید.');
      return;
    }
    
    // Phone must be exactly 11 digits
    if (!/^09\d{9}$/.test(addrPhone.trim())) {
      setAddrError('تلفن گیرنده باید ۱۱ رقم بوده و با ۰۹ آغاز شود.');
      return;
    }
    
    // ZIP code (if provided) must be exactly 10 digits
    if (addrZip.trim() && !/^\d{10}$/.test(addrZip.trim())) {
      setAddrError('کد پستی باید دقیقا ۱۰ رقم عددی باشد.');
      return;
    }

    setIsAddrSaving(true);
    addLog('VIEWMODEL', 'بارگذاری نشانی در AddressEditViewModel', 'صحت‌سنجی اطلاعات');
    
    setTimeout(() => {
      let updatedAddresses: UserAddress[];
      if (editingAddressId) {
        // Edit existing
        updatedAddresses = addresses.map(a => a.id === editingAddressId ? {
          id: editingAddressId,
          title: addrTitle.trim(),
          receiverName: addrReceiver.trim(),
          phoneNumber: addrPhone.trim(),
          zipCode: addrZip.trim(),
          province: addrProvince.trim(),
          city: addrCity.trim(),
          details: addrDetails.trim()
        } : a);
        addLog('USECASE', 'فراخوانی EditAddressUseCase', `موجودیت ${editingAddressId} به‌روز شد`);
      } else {
        // Add new
        const newAddr: UserAddress = {
          id: `addr_${Date.now()}`,
          title: addrTitle.trim(),
          receiverName: addrReceiver.trim(),
          phoneNumber: addrPhone.trim(),
          zipCode: addrZip.trim(),
          province: addrProvince.trim(),
          city: addrCity.trim(),
          details: addrDetails.trim()
        };
        updatedAddresses = [...addresses, newAddr];
        onSetActiveAddressId(newAddr.id); // set active
        addLog('USECASE', 'فراخوانی AddAddressUseCase', 'رکورد جدید درج گردید');
      }

      onUpdateAddresses(updatedAddresses);
      setIsAddingAddress(false);
      setEditingAddressId(null);
      setIsAddrSaving(false);
    }, 600);
  };

  const handleDeleteAddress = (id: string, title: string) => {
    addLog('UI', `کلیک بر روی دکمه حذف نشانی: ${title}`, `شناسه: ${id}`);
    const filtered = addresses.filter(a => a.id !== id);
    onUpdateAddresses(filtered);
    
    // If default and addresses remain, choose first
    if (activeAddressId === id && filtered.length > 0) {
      onSetActiveAddressId(filtered[0].id);
    }
    addLog('USECASE', 'فراخوانی DeleteAddressUseCase', `حذف شناسه ${id} انجام شد.`);
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    setProfileError('');
    setProfileSuccess('');

    if (!formName.trim() || !formPhone.trim() || !formEmail.trim()) {
      setProfileError('لطفاً همه فیلدهای مشخصات را تکمیل کنید.');
      return;
    }

    if (!/^09\d{9}$/.test(formPhone.trim())) {
      setProfileError('شماره موبایل باید ۱۱ رقم بوده و با ۰۹ شروع شود.');
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formEmail.trim())) {
      setProfileError('نشانی ایمیل معتبر نیست.');
      return;
    }

    setIsProfileSaving(true);
    addLog('VIEWMODEL', 'ارسال تغییرات مشخصات به EditProfileViewModel', 'آماده‌سازی بازنویسی');

    setTimeout(() => {
      onUpdateProfile(formName.trim(), formPhone.trim(), formEmail.trim());
      setIsProfileSaving(false);
      setIsEditingProfile(false);
      setProfileSuccess('مشخصات کاربری شما با موفقیت تغییر یافت.');
      addLog('USECASE', 'اجرای سناریوی UpdateUserProfileUseCase با موفقیت', `نام جدید: ${formName}`);
    }, 500);
  };

  const toPersianDigits = (num: number | string) => {
    const id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/[0-9]/g, (w) => id[+w]);
  };

  const formatPrice = (price: number) => {
    const formatted = price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return toPersianDigits(formatted);
  };

  const handleTopUp = () => {
    addLog('UI', 'کلیک روی دکمه افزایش موجودی کیف‌پول زنده', 'مبلغ درخواستی: ۵۰۰,۰۰۰ تومان');
    addLog('VIEWMODEL', 'ارسال تراکنش شارژ به WalletViewModel', 'آماده‌سازی پکیج شاپرک');
    addLog('USECASE', 'فراخوانی TopUpWalletUseCase', 'تأیید گیت شارژ');
    addLog('DATASOURCE', 'درخواست اتصال به درگاه بانکی سامان', 'تراکنش بازگشتی موفق');
    
    setBalance(prev => prev + 500000);
    addLog('REPOSITORY', 'ذخیره مانده جدید کیف پول محلی در اتاق پایگاه‌داده (Room SQL)', 'موجودی به‌روز شد');
  };

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'PENDING':
        return <span className="bg-amber-100 text-amber-700 text-[8px] font-bold px-2 py-0.5 rounded-full">در انتظار تأیید</span>;
      case 'PREPARING':
        return <span className="bg-blue-100 text-blue-700 text-[8px] font-bold px-2 py-0.5 rounded-full">در حال آماده‌سازی</span>;
      case 'SHIPPED':
        return <span className="bg-purple-100 text-purple-700 text-[8px] font-bold px-2 py-0.5 rounded-full">ارسال شده (مرسوله پست)</span>;
      case 'DELIVERED':
        return <span className="bg-emerald-100 text-emerald-700 text-[8px] font-bold px-2 py-0.5 rounded-full">تحویل داده شده</span>;
      default:
        return null;
    }
  };

  // Live order progress tracking helpers
  const getProgressWidthValue = (status: Order['status']) => {
    switch (status) {
      case 'PENDING': return '12.5%';
      case 'PREPARING': return '37.5%';
      case 'SHIPPED': return '62.5%';
      case 'DELIVERED': return '100%';
      default: return '0%';
    }
  };

  const getProgressBgColor = (status: Order['status']) => {
    switch (status) {
      case 'PENDING': return 'rgb(245 158 11)'; // amber-500
      case 'PREPARING': return 'rgb(37 99 235)'; // blue-600
      case 'SHIPPED': return 'rgb(79 70 229)'; // indigo-600
      case 'DELIVERED': return 'rgb(16 185 129)'; // emerald-500
      default: return 'rgb(203 213 225)';
    }
  };

  const getStatusWeight = (status: Order['status']) => {
    switch (status) {
      case 'PENDING': return 1;
      case 'PREPARING': return 2;
      case 'SHIPPED': return 3;
      case 'DELIVERED': return 4;
      default: return 0;
    }
  };

  const getNextStatus = (status: Order['status']): Order['status'] => {
    switch (status) {
      case 'PENDING': return 'PREPARING';
      case 'PREPARING': return 'SHIPPED';
      case 'SHIPPED': return 'DELIVERED';
      case 'DELIVERED': return 'PENDING';
    }
  };

  const translateStatusEn = (status: Order['status']) => {
    switch (status) {
      case 'PENDING': return 'Pending';
      case 'PREPARING': return 'Preparing';
      case 'SHIPPED': return 'Shipped';
      case 'DELIVERED': return 'Delivered';
    }
  };

  return (
    <div className="flex flex-col bg-slate-50 h-full pb-20 font-vazir text-right" dir="rtl" id="profile-tab-scroller">
      {/* Header */}
      <div className="bg-gradient-to-l from-blue-700 to-indigo-800 text-white p-5 pt-8 rounded-b-[2rem] shadow-md relative">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur border border-white/20 flex items-center justify-center text-xl font-black text-white shrink-0">
            {userName.charAt(0) || 'U'}
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="text-sm font-black tracking-tight truncate">{userName}</h2>
            <div className="flex flex-col gap-0.5 mt-1 text-[8.5px] text-white/80">
              <span className="flex items-center gap-1 truncate">
                <Phone className="w-2.5 h-2.5" />
                {toPersianDigits(userPhone)}
              </span>
              <span className="flex items-center gap-1 truncate">
                <Mail className="w-2.5 h-2.5" />
                {userEmail}
              </span>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => {
                setFormName(userName);
                setFormPhone(userPhone);
                setFormEmail(userEmail);
                setProfileError('');
                setProfileSuccess('');
                setIsEditingProfile(true);
                addLog('UI', 'باز کردن پنجره ویرایش مشخصات پروفایل', userName);
              }}
              className="p-2 bg-white/10 hover:bg-white/20 rounded-xl transition active:scale-90 text-[10px] font-bold flex items-center gap-1"
              title="ویرایش مشخصات"
            >
              <Edit className="w-3.5 h-3.5" />
            </button>
            <button 
              onClick={() => {
                addLog('UI', 'دکمه خروج از حساب کاربری کلیک شد', 'پاکسازی توکن‌های اعتباری');
                onLogout();
              }}
              className="p-2 bg-white/10 hover:bg-[#ff4d4f]/30 hover:text-red-200 rounded-xl transition active:scale-90"
              title="خروج"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* PROFILE EDITOR MODAL SHEET (OVERLAY) */}
        {isEditingProfile && (
          <div className="absolute inset-0 bg-slate-900/95 rounded-b-[2rem] p-4 flex flex-col justify-center text-white z-20 animate-fade-in relative" id="profile-editor-overlay">
            {/* Close Button in upper corner */}
            <button
              type="button"
              onClick={() => {
                setIsEditingProfile(false);
                addLog('UI', 'بستن پنجره ویرایش پروفایل کاربری از طریق آیکون ضربدر گوشه بالای دکمه', 'رویداد لغو حالت ویرایش');
              }}
              className="absolute left-4 top-4 p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition active:scale-90 cursor-pointer"
              title="بستن"
              id="close-profile-editor-modal-corner-btn"
            >
              <X className="w-4 h-4" />
            </button>

            <form onSubmit={handleSaveProfile} className="flex flex-col gap-3">
              <div className="text-center pb-2 border-b border-white/10">
                <span className="text-xs font-black text-white">ویرایش مشخصات پروفایل کاربری</span>
                <p className="text-[8px] text-slate-400 mt-0.5">به‌روزرسانی همگام‌سازی هویت در سرورهای یوزآنلاین</p>
              </div>

              {profileError && (
                <div className="bg-red-500/15 border border-red-500/30 text-red-300 text-[8.5px] p-2 rounded-xl text-center font-bold">
                  ⚠️ {profileError}
                </div>
              )}

              <div>
                <label className="text-[9px] font-bold text-slate-300 block mb-1">نام و نام خانوادگی</label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 px-3 py-1.5 text-[10px] rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-right"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[9px] font-bold text-slate-300 block mb-1">تلفن همراه (۰۹...)</label>
                  <input
                    type="text"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 px-3 py-1.5 text-[10px] rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-center font-mono"
                    placeholder="09112223344"
                    required
                  />
                </div>
                <div>
                  <label className="text-[9px] font-bold text-slate-300 block mb-1">پست الکترونیکی</label>
                  <input
                    type="email"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 px-3 py-1.5 text-[10px] rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-blue-500 text-left font-mono"
                    placeholder="name@domain.com"
                    required
                  />
                </div>
              </div>

              <div className="flex gap-2 mt-2">
                <button
                  type="submit"
                  disabled={isProfileSaving}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 hover:shadow-lg text-white font-extrabold py-2 rounded-xl text-[10px] active:scale-95 transition flex items-center justify-center gap-1.5"
                >
                  {isProfileSaving ? (
                    <RefreshCw className="w-3 h-3 animate-spin" />
                  ) : (
                    <span>ارسال تغییرات مشخصات</span>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setIsEditingProfile(false)}
                  className="px-4 py-2 border border-slate-700 text-slate-300 rounded-xl text-[10px] hover:bg-slate-800 font-bold"
                >
                  انصراف
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Wallet balances Card banner */}
        <div className="bg-white text-gray-900 rounded-2xl p-3.5 shadow-lg mt-5 flex items-center justify-between border border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Wallet className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[8px] text-gray-400 block font-semibold">موجودی کیف‌پول یوزآنلاین</span>
              <span className="text-xs font-black text-gray-950">{formatPrice(balance)} تومان</span>
            </div>
          </div>
          <button
            onClick={handleTopUp}
            className="flex items-center gap-1 bg-blue-50 hover:bg-blue-100 text-blue-600 font-extrabold text-[9px] px-3 py-1.5 rounded-lg active:scale-95 transition border border-blue-100"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            افزایش اعتبار
          </button>
        </div>
      </div>

      {onOpenPaymentHistory && (
        <div className="px-4 mt-4">
          <button
            onClick={() => {
              addLog('UI', 'کلیک روی ابزارک درگاه پرداخت همه‌جانبه یوزآنلاین از پروفایل', 'نمایش تاریخچه شتاب');
              onOpenPaymentHistory();
            }}
            className="w-full bg-gradient-to-r from-slate-950 to-slate-850 hover:from-slate-900 hover:to-slate-800 text-white rounded-2xl p-3.5 shadow-md flex items-center justify-between border border-slate-800/60 transition active:scale-[0.98] text-right"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center text-lg">
                💳
              </div>
              <div className="text-right">
                <span className="text-[10px] font-black text-white block">سوابق مالی و استرداد وجه شتاب</span>
                <span className="text-[8px] text-slate-400 font-extrabold block mt-0.5">درگاه‌های همکار: زرین‌پال، اسنپ‌پی، دیجی‌پی، تارا و آپ</span>
              </div>
            </div>
            <div className="bg-blue-600 text-white font-black text-[8px] px-2.5 py-1 rounded-lg flex items-center gap-1.5 animate-pulse">
              <span>مشاهده لیست</span>
              <ChevronRight className="w-3" />
            </div>
          </button>
        </div>
      )}

      <div className="px-4 mt-6 flex flex-col gap-4">
        
        {/* Profile Success Toast Banner */}
        {profileSuccess && (
          <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 text-[10px] p-3 rounded-2xl shadow-sm text-center font-bold relative animate-slide-up">
            <button onClick={() => setProfileSuccess('')} className="absolute left-2.5 top-2.5 text-emerald-400">×</button>
            ✓ {profileSuccess}
          </div>
        )}

        {/* COMPLETE ADDRESS MANAGEMENT PANEL */}
        <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm flex flex-col gap-3">
          <div className="flex items-center justify-between border-b border-gray-50 pb-2">
            <div className="flex items-center gap-1.5">
              <MapPin className="w-4 h-4 text-orange-500" />
              <h4 className="text-[10px] font-black text-gray-800">نشانی‌های فعال مرسوله</h4>
            </div>
            <button
              onClick={handleOpenAddAddress}
              className="text-blue-600 hover:text-blue-800 font-black text-[9px] flex items-center gap-0.5 hover:underline"
            >
              <Plus className="w-3 h-3" />
              افزودن نشانی جدید
            </button>
          </div>

          {/* DYNAMIC ADDRESS LISTING */}
          {addresses.length === 0 ? (
            <div className="text-center py-6 text-gray-400 text-[9px] font-semibold">
              هیچ آدرسی ثبت نشده است. آدرس دریافت خود را مشخص کنید!
            </div>
          ) : (
            <div className="flex flex-col gap-2.5">
              {addresses.map((addr) => {
                const isActive = activeAddressId === addr.id;
                return (
                  <div
                    key={addr.id}
                    className={`border p-3 rounded-xl transition relative flex flex-col gap-1.5 ${
                      isActive ? 'bg-orange-50/50 border-orange-500/40 shadow-sm' : 'border-gray-100 bg-slate-50/20'
                    }`}
                  >
                    <div className="flex justify-between items-center bg-slate-50 p-1 rounded-lg">
                      <span className="text-[10px] font-black text-gray-800 flex items-center gap-1">
                        <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-orange-500 animate-pulse' : 'bg-gray-400'}`}></span>
                        {addr.title}
                      </span>
                      {isActive && (
                        <span className="bg-orange-100 text-orange-700 text-[7px] font-bold px-1.5 py-0.5 rounded">
                          نشانی پیش‌فرض
                        </span>
                      )}
                    </div>

                    <p className="text-[9.5px] text-gray-600 leading-normal font-medium">
                      {addr.province}، {addr.city}، {addr.details}
                    </p>

                    <div className="text-[8px] text-gray-400 flex flex-wrap gap-x-3 gap-y-1 font-semibold border-t border-gray-100/60 pt-1.5">
                      <span>گیرنده: {addr.receiverName}</span>
                      <span>تماس: {toPersianDigits(addr.phoneNumber)}</span>
                      {addr.zipCode && <span>کدپستی: {toPersianDigits(addr.zipCode)}</span>}
                    </div>

                    {/* Address action nodes */}
                    <div className="flex items-center gap-1.5 border-t border-gray-50/80 pt-2 mt-1">
                      {!isActive ? (
                        <button
                          onClick={() => {
                            addLog('UI', `تغییر نشانی پیش فرض به: ${addr.title}`, `AddressId: ${addr.id}`);
                            onSetActiveAddressId(addr.id);
                          }}
                          className="bg-orange-500 hover:bg-orange-600 text-white font-bold text-[8.5px] px-2.5 py-1 rounded-lg transition active:scale-95 flex items-center gap-0.5"
                        >
                          <Check className="w-3 h-3" />
                          انتخاب به عنوان پیش‌فرض
                        </button>
                      ) : (
                        <span className="text-[8px] text-orange-600 font-bold flex items-center gap-0.5 ml-auto">
                          ✓ نشانی اصلی تحویل
                        </span>
                      )}

                      <div className="flex gap-1.5 ml-0 mr-auto" dir="ltr">
                        <button
                          onClick={() => handleOpenEditAddress(addr)}
                          className="text-gray-500 hover:text-blue-600 hover:bg-blue-50 p-1 rounded-md border border-gray-100 bg-white"
                          title="ویرایش"
                        >
                          <Edit className="w-3 h-3" />
                        </button>
                        <button
                          onClick={() => handleDeleteAddress(addr.id, addr.title)}
                          className="text-gray-400 hover:text-red-500 hover:bg-red-50 p-1 rounded-md border border-gray-100 bg-white"
                          title="حذف"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* ADD / EDIT ADDRESS DYNAMIC INLINE FORM */}
          {isAddingAddress && (
            <div className="bg-slate-50 border border-slate-100 p-3 rounded-xl mt-2 animate-slide-up relative" id="address-form-portal">
              {/* Close Button in upper corner */}
              <button
                type="button"
                onClick={() => {
                  setIsAddingAddress(false);
                  setEditingAddressId(null);
                  addLog('UI', 'بستن فرم ثبت و ویرایش نشانی جدید کاربری از طریق آیکون ضربدر گوشه بالای دکمه', 'رویداد لغو افزدن یا ویرایش آدرس');
                }}
                className="absolute left-2.5 top-2.5 p-1 rounded-lg bg-gray-200/50 hover:bg-gray-250 text-gray-500 hover:text-gray-800 transition active:scale-90 cursor-pointer"
                title="بستن"
                id="close-address-form-modal-corner-btn"
              >
                <X className="w-3.5 h-3.5" />
              </button>

              <form onSubmit={handleSaveAddress} className="flex flex-col gap-3">
                <div className="text-center pb-1.5 border-b border-gray-200">
                  <span className="text-[10px] font-black text-gray-800">
                    {editingAddressId ? 'ویرایش نشانی مرسوله‌داری' : 'ثبت غرفه نشانی تحویل جدید'}
                  </span>
                </div>

                {addrError && (
                  <div className="bg-red-50 text-red-600 text-[8.5px] p-2 border border-red-100 rounded-lg text-center font-bold">
                    ⚠️ {addrError}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[8.5px] font-bold text-gray-700 block mb-1">عنوان نشانی (ستاره‌دار)</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: آپارتمان شیراز، خانه پدری"
                      value={addrTitle}
                      onChange={(e) => setAddrTitle(e.target.value)}
                      className="w-full bg-white border border-gray-100 px-2 py-1.5 text-[9px] rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 text-right"
                    />
                  </div>
                  <div>
                    <label className="text-[8.5px] font-bold text-gray-700 block mb-1">نام گیرنده (ستاره‌دار)</label>
                    <input
                      type="text"
                      required
                      placeholder="نام کامل تحویل‌گیرنده"
                      value={addrReceiver}
                      onChange={(e) => setAddrReceiver(e.target.value)}
                      className="w-full bg-white border border-gray-100 px-2 py-1.5 text-[9px] rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 text-right"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-1">
                    <label className="text-[8.5px] font-bold text-gray-700 block mb-1">تماس تحویل‌گیرنده</label>
                    <input
                      type="text"
                      required
                      placeholder="0912..."
                      value={addrPhone}
                      onChange={(e) => setAddrPhone(e.target.value)}
                      className="w-full bg-white border border-gray-100 px-2 py-1.5 text-[9px] rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 text-center font-mono"
                    />
                  </div>
                  <div className="col-span-1">
                    <label className="text-[8.5px] font-bold text-gray-700 block mb-1">استان</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: تهران"
                      value={addrProvince}
                      onChange={(e) => setAddrProvince(e.target.value)}
                      className="w-full bg-white border border-gray-100 px-2 py-1.5 text-[9px] rounded-lg focus:outline-none"
                    />
                  </div>
                  <div className="col-span-1">
                    <label className="text-[8.5px] font-bold text-gray-700 block mb-1">شهر</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: شیراز"
                      value={addrCity}
                      onChange={(e) => setAddrCity(e.target.value)}
                      className="w-full bg-white border border-gray-100 px-2 py-1.5 text-[9px] rounded-lg focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-1">
                    <label className="text-[8.5px] font-bold text-gray-700 block mb-1">کد پستی (۱۰ رقم)</label>
                    <input
                      type="text"
                      placeholder="اختیاری"
                      value={addrZip}
                      maxLength={10}
                      onChange={(e) => setAddrZip(e.target.value)}
                      className="w-full bg-white border border-gray-100 px-2 py-1.5 text-[9px] rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500 text-center font-mono"
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="text-[8.5px] font-bold text-gray-700 block mb-1">شرح دقیق آدرس تحویل (ستاره‌دار)</label>
                    <input
                      type="text"
                      required
                      placeholder="خیابان، کوچه، طبقه، پلاک..."
                      value={addrDetails}
                      onChange={(e) => setAddrDetails(e.target.value)}
                      className="w-full bg-white border border-gray-100 px-2 py-1.5 text-[9px] rounded-lg focus:outline-none focus:ring-1 focus:ring-orange-500"
                    />
                  </div>
                </div>

                <div className="flex gap-2.5 mt-1 border-t border-gray-100 pt-2.5">
                  <button
                    type="submit"
                    disabled={isAddrSaving}
                    className="flex-1 bg-orange-500 hover:bg-orange-600 text-white font-extrabold py-2 rounded-xl text-[9.5px] active:scale-95 transition flex items-center justify-center gap-1"
                  >
                    {isAddrSaving ? (
                      <RefreshCw className="w-3 h-3 animate-spin" />
                    ) : (
                      <span>تایید و ذخیره‌سازی نشانی</span>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setIsAddingAddress(false);
                      setEditingAddressId(null);
                    }}
                    className="px-4 py-2 border border-gray-200 text-gray-500 rounded-xl text-[9px] hover:bg-white font-bold"
                  >
                    انصراف
                  </button>
                </div>
              </form>
            </div>
          )}

        </div>

        {/* Order tracking Section */}
        <div>
          <h3 className="text-xs font-black text-gray-800 mb-2.5 flex items-center gap-1.5">
            <ShoppingBag className="w-4 h-4 text-blue-600" />
            مدیریت و پیگیری سفارش‌ها ({toPersianDigits(orders.length)})
          </h3>

          {orders.length === 0 ? (
            <div className="bg-white border border-gray-100 rounded-2xl p-6 text-center text-gray-400 text-[10px]">
              هنوز هیچ سفارشی ثبت نشده است. کالاها را چک کنید!
            </div>
          ) : (
            <>
              {/* Order Sorting Toggle Bar */}
              <div className="flex items-center justify-between mb-3 bg-white border border-gray-100 rounded-2xl p-2 shadow-sm font-sans">
                <div className="flex items-center gap-1.5 text-slate-500 font-bold text-[9px] font-vazir" dir="rtl">
                  <ArrowUpDown className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                  <span>ترتیب نمایش سفارش‌ها:</span>
                </div>
                <div className="flex bg-slate-100 p-0.5 rounded-lg border border-slate-200/50" dir="rtl">
                  <button
                    onClick={() => {
                      setSortOrder('RECENT');
                      addLog('UI', 'تغییر مانیتورینگ تراکنش‌ها به جدیدترین‌ها اول', 'Sort order: RECENT');
                    }}
                    className={`px-3 py-1 text-[8px] font-black rounded-md transition ${
                      sortOrder === 'RECENT' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-900'
                    }`}
                  >
                    جدیدترین‌ها
                  </button>
                  <button
                    onClick={() => {
                      setSortOrder('OLDEST');
                      addLog('UI', 'تغییر مانیتورینگ تراکنش‌ها به قدیمی‌ترین‌ها اول', 'Sort order: OLDEST');
                    }}
                    className={`px-3 py-1 text-[8px] font-black rounded-md transition ${
                      sortOrder === 'OLDEST' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-950'
                    }`}
                  >
                    قدیمی‌ترین‌ها
                  </button>
                </div>
              </div>

              <motion.div 
                key={sortOrder}
                className="flex flex-col gap-2.5"
                initial="hidden"
                animate="visible"
                variants={{
                  visible: {
                    transition: {
                      staggerChildren: 0.15
                    }
                  }
                }}
              >
                {(sortOrder === 'RECENT' ? orders : [...orders].reverse()).map((order) => (
                <motion.div 
                  key={order.id}
                  variants={{
                    hidden: { opacity: 0, y: 12 },
                    visible: { opacity: 1, y: 0 }
                  }}
                  transition={{ duration: 0.4, ease: "easeOut" }}
                  className="bg-white border border-gray-100 rounded-2xl p-3.5 shadow-sm flex flex-col gap-2"
                >
                  <div className="flex items-center justify-between border-b border-gray-50 pb-2">
                    <div className="flex flex-col">
                      <span className="text-[9px] font-black text-gray-900">سفارش {toPersianDigits(order.id)}</span>
                      <span className="text-[8px] text-gray-400 mt-0.5">{toPersianDigits(order.date)}</span>
                    </div>
                    {getStatusBadge(order.status)}
                  </div>

                  <div className="text-[9px] text-gray-500 flex justify-between">
                    <div>
                      <span>اقلام خریداری شده: </span>
                      <span className="font-extrabold text-gray-800">{toPersianDigits(order.itemsCount)} کالا</span>
                    </div>
                    <div>
                      <span>مبلغ فاکتور: </span>
                      <span className="font-extrabold text-blue-600">{formatPrice(order.totalPrice)} تومان</span>
                    </div>
                  </div>

                  {/* Visual Progress Tracker Bar with steps and connect line */}
                  <div className="mt-2.5 pt-2.5 border-t border-gray-50 flex flex-col gap-2">
                    <div className="flex items-center justify-between text-[8px] text-gray-400">
                      <span className="font-semibold text-gray-500">وضیعت پردازش مرسوله فیزیکی:</span>
                      <span className="font-extrabold text-blue-600">رهگیری مرسولات پست پیشتاز</span>
                    </div>

                    <div className="relative flex items-center justify-between w-full mt-2 px-1 mb-1 select-none">
                      {/* Line behind steps */}
                      <div className="absolute top-[10px] left-0 right-0 h-0.5 bg-gray-100 -translate-y-1/2 z-0 rounded"></div>
                      
                      {/* Colored line representing progress */}
                      <div
                        className="absolute top-[10px] right-0 h-0.5 -translate-y-1/2 z-0 transition-all duration-500 ease-in-out rounded"
                        style={{
                          width: getProgressWidthValue(order.status),
                          backgroundColor: getProgressBgColor(order.status),
                        }}
                      ></div>

                      {/* Step 1: PENDING */}
                      <div className="flex flex-col items-center z-10 relative">
                        <div className={`w-5 border h-5 rounded-full flex items-center justify-center transition-all duration-500 ease-in-out ${
                          getStatusWeight(order.status) >= 1
                            ? `bg-amber-500 text-white border-amber-600 shadow-sm shadow-amber-500/20 ring-4 ${
                                order.status === 'PENDING' ? 'ring-amber-300 animate-pulse scale-105' : 'ring-amber-100'
                              }`
                            : 'bg-white text-gray-300 border-gray-200'
                        }`}>
                          <Clock className={`w-2.5 h-2.5 ${order.status === 'PENDING' ? 'animate-spin-slow' : ''}`} />
                        </div>
                        <span className={`text-[8px] mt-1 font-bold transition-all duration-500 ease-in-out ${getStatusWeight(order.status) >= 1 ? 'text-amber-600 font-extrabold' : 'text-gray-400 font-medium'} ${order.status === 'PENDING' ? 'animate-pulse' : ''}`}>ثبت اولیه</span>
                      </div>

                      {/* Step 2: PREPARING */}
                      <div className="flex flex-col items-center z-10 relative">
                        <div className={`w-5 border h-5 rounded-full flex items-center justify-center transition-all duration-500 ease-in-out ${
                          getStatusWeight(order.status) >= 2
                            ? `bg-blue-600 text-white border-blue-700 shadow-sm shadow-blue-500/20 ring-4 ${
                                order.status === 'PREPARING' ? 'ring-blue-300 animate-pulse scale-105' : 'ring-blue-100'
                              }`
                            : 'bg-white text-gray-300 border-gray-200'
                        }`}>
                          <Package className="w-2.5 h-2.5" />
                        </div>
                        <span className={`text-[8px] mt-1 font-bold transition-all duration-500 ease-in-out ${getStatusWeight(order.status) >= 2 ? 'text-blue-600 font-extrabold' : 'text-gray-400 font-medium'} ${order.status === 'PREPARING' ? 'animate-pulse' : ''}`}>پردازش</span>
                      </div>

                      {/* Step 3: SHIPPED */}
                      <div className="flex flex-col items-center z-10 relative">
                        <div className={`w-5 border h-5 rounded-full flex items-center justify-center transition-all duration-500 ease-in-out ${
                          getStatusWeight(order.status) >= 3
                            ? `bg-indigo-600 text-white border-indigo-700 shadow-sm shadow-indigo-500/20 ring-4 ${
                                order.status === 'SHIPPED' ? 'ring-indigo-300 animate-pulse scale-105' : 'ring-indigo-100'
                              }`
                            : 'bg-white text-gray-300 border-gray-200'
                        }`}>
                          <Truck className="w-2.5 h-2.5" />
                        </div>
                        <span className={`text-[8px] mt-1 font-bold transition-all duration-500 ease-in-out ${getStatusWeight(order.status) >= 3 ? 'text-indigo-600 font-extrabold' : 'text-gray-400 font-medium'} ${order.status === 'SHIPPED' ? 'animate-pulse' : ''}`}>ارسال بار</span>
                      </div>

                      {/* Step 4: DELIVERED */}
                      <div className="flex flex-col items-center z-10 relative">
                        <div className={`w-5 border h-5 rounded-full flex items-center justify-center transition-all duration-500 ease-in-out ${
                          getStatusWeight(order.status) >= 4
                            ? `bg-emerald-500 text-white border-emerald-600 shadow-sm shadow-emerald-500/20 ring-4 ${
                                order.status === 'DELIVERED' ? 'ring-emerald-300 animate-pulse scale-105' : 'ring-emerald-100'
                              }`
                            : 'bg-white text-gray-300 border-gray-200'
                        }`}>
                          <CheckCircle2 className="w-2.5 h-2.5" />
                        </div>
                        <span className={`text-[8px] mt-1 font-bold transition-all duration-500 ease-in-out ${getStatusWeight(order.status) >= 4 ? 'text-emerald-600 font-extrabold' : 'text-gray-400 font-medium'} ${order.status === 'DELIVERED' ? 'animate-pulse' : ''}`}>تحویل شد</span>
                      </div>
                    </div>
                  </div>

                  {/* Footer with Post Tracking, Map Viewer & Live Simulator update */}
                  <div className="bg-slate-50 border border-slate-100/50 p-2 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mt-1" dir="rtl">
                    <div className="flex items-center justify-between sm:justify-start gap-3 w-full sm:w-auto">
                      <div className="flex flex-col items-start gap-0.5" dir="ltr">
                        <span className="text-[7px] text-slate-400 font-sans tracking-wide uppercase font-bold">Post Tracking</span>
                        <span className="text-left font-black text-slate-700 font-mono">#{toPersianDigits(order.trackingNumber)}</span>
                      </div>
                      
                      <button
                        onClick={() => {
                          setSelectedOrderForMap(order);
                          addLog('UI', `بازکردن نقشه رهگیری زنده سفارش ${order.id}`, `کد مرسوله: ${order.trackingNumber}`);
                        }}
                        className="bg-blue-600 hover:bg-blue-700 hover:shadow-xs text-white font-black text-[8px] px-3 py-1.5 rounded-lg active:scale-95 transition flex items-center gap-1 cursor-pointer"
                      >
                        <MapPin className="w-2.5 h-2.5" />
                        نقشه رهگیری زنده (LIVE MAP)
                      </button>
                    </div>

                    <button
                      onClick={() => {
                        const nextStatus = getNextStatus(order.status);
                        // Record architecture traces
                        addLog('UI', `تلاش برای به‌روزرسانی زنده سفارش ${order.id} به وضعیت ${translateStatusEn(nextStatus)}`, `وضعیت پیشین: ${translateStatusEn(order.status)}`);
                        addLog('VIEWMODEL', `تحریک جریان داده اکتیو در OrderHistoryViewModel`, `تطبیق فلو با شناسه: ${order.id}`);
                        addLog('REPOSITORY', `به‌روزرسانی موفق موجودیت مرتبه در جدول محلی سفارشات (Standard Room-DB)`, `فیلد وضعیت با موفقیت روی ${nextStatus} تنظیم گردید`);
                        addLog('DATASOURCE', `مخابره کانکشن زنده با سوکت پست پیشتاز کشور`, 'کلاینت و سرور همگام‌سازی شدند');
                        
                        if (onUpdateOrderStatus) {
                          onUpdateOrderStatus(order.id, nextStatus);
                        }
                      }}
                      className="bg-white hover:bg-blue-50 border border-slate-200 hover:border-blue-200 text-blue-600 font-black text-[8px] px-2.5 py-1.5 rounded-lg active:scale-95 transition flex items-center justify-center gap-1.5 shadow-sm"
                      title="شبیه‌سازی مرحله بعدی وضعیت سفارش"
                    >
                      <RefreshCw className="w-2.5 h-2.5 animate-spin-hover" />
                      SIMULATE UPDATE
                    </button>
                  </div>
                </motion.div>
              ))}
            </motion.div>
          </>
          )}
        </div>

        {/* Permissions / Preferences Toggles list */}
        <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm flex flex-col gap-3">
          <h4 className="text-[10px] font-bold text-gray-800 border-b border-gray-50 pb-2 flex items-center gap-1.5">
            <Settings className="w-4 h-4 text-gray-600" />
            تنظیمات اپلیکیشن اندروید یوزآنلاین
          </h4>

          <div className="flex items-center justify-between py-1">
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-gray-800">فعالسازی نوتیفیکیشن‌ها</span>
              <span className="text-[8px] text-gray-400 mt-0.5">دریافت آخرین اخبار سفارش و تخفیف‌ها</span>
            </div>
            <button
              onClick={() => {
                addLog('UI', 'تغییر وضعیت مجوز اعلانات سیستم‌عامل اندروید', `وضعیت: ${!notificationsEnabled}`);
                setNotificationsEnabled(!notificationsEnabled);
              }}
              className="text-gray-400 hover:text-blue-600 active:scale-90 transition"
            >
              {notificationsEnabled ? (
                <ToggleRight className="w-10 h-6 text-blue-600 fill-blue-50" />
              ) : (
                <ToggleLeft className="w-10 h-6 text-gray-300" />
              )}
            </button>
          </div>

          <div className="flex items-center justify-between py-1 border-t border-gray-50 pt-3">
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-gray-800">حالت چندفروشگاهی (Vendor Console)</span>
              <span className="text-[8px] text-gray-400 mt-0.5">مشاهده پنل بارگذاری محصولات جدید برای فروشندگان یوزآنلاین</span>
            </div>
            <button
              onClick={() => {
                addLog('UI', 'سوئیچ به حالت عرضه چندفروشگاهی', `وضعیت: ${!vendorMode}`);
                onToggleVendorMode(!vendorMode);
              }}
              className="text-gray-400 hover:text-blue-600 active:scale-90 transition"
            >
              {vendorMode ? (
                <ToggleRight className="w-10 h-6 text-[#ff4d4f] fill-red-50" />
              ) : (
                <ToggleLeft className="w-10 h-6 text-gray-300" />
              )}
            </button>
          </div>
        </div>

        {/* Android Build Manifest specifications */}
        <div className="bg-slate-900 text-slate-300 border border-slate-800 rounded-2xl p-4 shadow-sm font-mono text-[9px] text-left" dir="ltr">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-2">
            <div className="flex items-center gap-1">
              <Terminal className="w-3.5 h-3.5 text-blue-400" />
              <span className="font-black text-blue-400 uppercase tracking-wider">Android Build Profile</span>
            </div>
            <span className="bg-emerald-500/10 text-emerald-400 px-1.5 py-0.5 rounded text-[8px] font-bold">M3 STABLE</span>
          </div>
          <div className="flex flex-col gap-1 text-slate-400">
            <div><span className="text-slate-500 font-bold">Package:</span> ir.useonline.shop</div>
            <div><span className="text-slate-500 font-bold">MinSDK:</span> 26 (Android 8.0 Oreo)</div>
            <div><span className="text-slate-500 font-bold">TargetSDK:</span> 34 (Android 14 UpsideDownCake)</div>
            <div><span className="text-slate-500 font-bold">Compose:</span> Compiler v1.5.8 | Runtime MD3</div>
            <div><span className="text-slate-500 font-bold">Injection:</span> Dagger-Hilt v2.50 | Coroutines Flow</div>
          </div>
        </div>
      </div>

      {/* Dynamic Animated Order Tracking map Details overlay Dialog */}
      <AnimatePresence>
        {selectedOrderForMap && (
          <OrderTrackingModal
            order={selectedOrderForMap}
            onClose={() => {
              setSelectedOrderForMap(null);
              addLog('UI', 'بستن پنجره رهگیری مرسوله‌ها و جزئیات نقشه', '');
            }}
            addresses={addresses}
            activeAddressId={activeAddressId}
            addLog={addLog}
            onUpdateOrderStatus={(orderId, nextStatus) => {
              // Trigger state updates up to top-level app logic
              if (onUpdateOrderStatus) {
                onUpdateOrderStatus(orderId, nextStatus);
              }
              // Keep modal state updated in sync with the order's active status
              if (selectedOrderForMap && selectedOrderForMap.id === orderId) {
                setSelectedOrderForMap(prev => prev ? { ...prev, status: nextStatus } : null);
              }
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
