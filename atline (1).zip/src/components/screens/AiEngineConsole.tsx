import React, { useState, useEffect } from 'react';
import { 
  Brain, Sparkles, Activity, ShieldAlert, TrendingUp, Cpu, 
  Search, Terminal, Database, ArrowRightLeft, FileCode, CheckCircle, 
  Clock, RotateCcw, HelpCircle, BarChart3, AlertTriangle, Lightbulb, 
  ChevronRight, Calendar, Layers, Code, Play, RefreshCw, Send, HelpCircle as HelpIcon 
} from 'lucide-react';

interface AiEngineConsoleProps {
  products: any[];
  addLog: (layer: string, message: string, details: string) => void;
}

export function AiEngineConsole({ products, addLog }: AiEngineConsoleProps) {
  const [activeTab, setActiveTab] = useState<'blueprint' | 'search' | 'vendor' | 'admin' | 'roadmap'>('blueprint');
  
  // Interactive Search States
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [searchSuggestions, setSearchSuggestions] = useState<string[]>([]);
  const [searchIsSimulated, setSearchIsSimulated] = useState(true);

  // Interactive Assistant Chat States
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'bot'; text: string }>>([
    { sender: 'bot', text: 'سلام! من مغز متفکر یوزآنلاین (UseOnline AICE) هستم. چطور می‌توانم در بهینه‌سازی فروش، موجودی، کمپین‌ها یا تحلیل رفتار مشتریان به شما کمک کنم؟' }
  ]);
  const [isChatLoading, setIsChatLoading] = useState(false);

  // Interactive Forecasting Data State
  const [forecastingData, setForecastingData] = useState<any>(null);
  const [isLoadingForecast, setIsLoadingForecast] = useState(true);
  const [pricingFilter, setPricingFilter] = useState<'ALL' | 'ALARM' | 'STALE'>('ALL');

  // Load forecasting API data
  useEffect(() => {
    fetchForecastData();
  }, []);

  const fetchForecastData = async () => {
    setIsLoadingForecast(true);
    try {
      const res = await fetch('/api/ai/forecasting');
      if (res.ok) {
        const data = await res.json();
        setForecastingData(data);
      } else {
        // Fallback simulated forecasting values
        generateFallbackForecasting();
      }
    } catch (e) {
      generateFallbackForecasting();
    } finally {
      setIsLoadingForecast(false);
    }
  };

  const generateFallbackForecasting = () => {
    // Elegant fallback simulation matching server.ts
    const days = Array.from({ length: 30 }, (_, i) => `روز ${i + 1}`);
    const demandProjections = {
      digital: days.map((_, i) => Math.round(120 + Math.sin(i / 2) * 20 + Math.random() * 8)),
      apparel: days.map((_, i) => Math.round(80 + Math.cos(i / 3) * 15 + Math.random() * 5)),
      home: days.map((_, i) => Math.round(60 + Math.sin(i / 4) * 10 + Math.random() * 4)),
    };
    const inventoryForecasts = [
      { productId: 'p1', title: 'گوشی موبایل سامسونگ گلکسی S24 Ultra', currentStock: 8, dailyDemandRate: 0.8, daysToExhaustion: 10, lowStockAlarm: false, pricingStrategy: 'قیمت بهینه با حاشیه سود پایدار همخوان است', pricingDelta: 0 },
      { productId: 'p2', title: 'هدفون بی‌سیم اپل مدل Airpods Pro 2', currentStock: 3, dailyDemandRate: 1.2, daysToExhaustion: 3, lowStockAlarm: true, pricingStrategy: 'افزایش ۳+ درصد جهت مدیریت تقاضا و تامین شارژ مجدد', pricingDelta: 3 },
      { productId: 'p3', title: 'ساعت هوشمند شیائومی مدل Redmi Watch 4', currentStock: 14, dailyDemandRate: 1.5, daysToExhaustion: 9, lowStockAlarm: false, pricingStrategy: 'قیمت بهینه با حاشیه سود پایدار همخوان است', pricingDelta: 0 },
      { productId: 'p4', title: 'کفش رانینگ مردانه نایک پگاسوس Air Zoom', currentStock: 1, dailyDemandRate: 0.6, daysToExhaustion: 2, lowStockAlarm: true, pricingStrategy: 'افزایش ۵+ درصد اضطراری بدلیل انبار بحرانی', pricingDelta: 5 },
      { productId: 'p5', title: 'قهوه‌ساز نوا مدل Nova 149', currentStock: 18, dailyDemandRate: 0.4, daysToExhaustion: 45, lowStockAlarm: false, pricingStrategy: 'کاهش ۵- درصد همراه با کمپین تخفیفی جهت تخلیه انبار راکد', pricingDelta: -5 },
    ];
    const fraudDetections = [
      { id: 'f1', userId: 'usr-9284', score: 94, reason: 'کلیک‌های متداوم و غیرارادی ربات از آی‌پی مسدودشده', action: 'مسدودسازی موقت نشست', timestamp: '۱۰ دقیقه قبل' },
      { id: 'f2', userId: 'usr-3891', score: 81, reason: 'تعدد درخواست در تست درگاه‌های اعتباری Tara', action: 'نیاز به احراز OTP مجدد', timestamp: '۱ ساعت قبل' },
      { id: 'f3', userId: 'usr-1102', score: 45, reason: 'ثبت ۱۰ نشانی متفاوت در کمتر از ۳ دقیقه', action: 'بررسی ناظر کارشناس', timestamp: '۳ ساعت قبل' }
    ];
    setForecastingData({
      demandProjections,
      inventoryForecasts,
      fraudDetections,
      revenueForecast: days.map((_, i) => Math.round(420000000 + i * 15000000 + Math.sin(i / 1.5) * 25000000))
    });
  };

  const handleSemanticSearchDemo = async (queryStr: string) => {
    const activeQuery = queryStr || searchQuery;
    if (!activeQuery.trim()) return;

    setSearchQuery(activeQuery);
    setIsSearching(true);
    addLog('UI', 'آغاز پردازش تست جستجوی معنایی و خطایاب هوشمند یوزآنلاین', `ورودی: ${activeQuery}`);

    try {
      const res = await fetch('/api/ai/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: activeQuery })
      });

      if (res.ok) {
        const data = await res.json();
        setSearchResults(data.results || []);
        setSearchSuggestions(data.suggestions || []);
        setSearchIsSimulated(data.isSimulated);
        addLog('VIEWMODEL', 'موتور تجزیه معنایی پاسخ داد', `یافت شده: ${data.results.length} کالا`);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsSearching(false);
    }
  };

  const handleAssistantChat = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!chatInput.trim() || isChatLoading) return;

    const userMsg = chatInput;
    setChatInput('');
    setChatMessages((prev) => [...prev, { sender: 'user', text: userMsg }]);
    setIsChatLoading(true);

    addLog('UI', 'کنسول توسعه‌دهنده وب: ارسال پیام چت به پشتیبان هوشمند', userMsg);

    // Build chat history matching server structure
    const historyPayload = chatMessages.slice(1).map(m => ({
      role: m.sender === 'user' ? 'user' : 'model',
      text: m.text
    }));

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMsg, history: historyPayload })
      });

      if (res.ok) {
        const data = await res.json();
        setChatMessages((prev) => [...prev, { sender: 'bot', text: data.response }]);
        addLog('VIEWMODEL', 'دریافت پاسخ سرانجام از دستیار هوشمند', `تکنولوژی: ${data.isSimulated ? 'محلی (Simulated)' : 'Gemini 3.5'}`);
      } else {
        throw new Error('Chat failed');
      }
    } catch (err) {
      setChatMessages((prev) => [
        ...prev, 
        { sender: 'bot', text: 'سرور در این لحظه شلوغ است، ولی نگران نباشید! از خرید نایک پگاسوس ۴۰ و یا سامسونگ اس۲۴ غافل نشوید.' }
      ]);
    } finally {
      setIsChatLoading(false);
    }
  };

  // Helper values
  const getProductTitleFromId = (id: string) => {
    const found = products.find(p => p.id === id);
    return found ? found.title : 'محصول ویژه بازارچه';
  };

  const getProductPriceFromId = (id: string) => {
    const found = products.find(p => p.id === id);
    return found ? found.price : 4500000;
  };

  const formatPrice = (price: number) => {
    return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',') + ' تومان';
  };

  return (
    <div className="bg-[#12161a] border border-[#1e252d] h-full rounded-2xl flex flex-col overflow-hidden text-right font-vazir relative select-none shadow-2xl" dir="rtl" id="ai-engine-console-root">
      
      {/* Top Console Title Header */}
      <div className="bg-[#181d24] border-b border-[#222a33] px-5 py-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 border border-indigo-500/35 flex items-center justify-center animate-pulse">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-black text-white flex items-center gap-1.5">
              موتور تجارت هوش مصنوعی یوزآنلاین (UseOnline AICE)
              <span className="bg-emerald-500/10 text-emerald-400 text-[9px] font-black px-2 py-0.5 rounded-full border border-emerald-500/20 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                هوشمند / متصل
              </span>
            </h2>
            <p className="text-[10px] text-slate-400 mt-0.5">سیستم یکپارچه پیشنهاد، جستجو، و پیش‌بینی موجودی مبتنی بر مدل‌های هوایی Gemini</p>
          </div>
        </div>

        {/* Global Reset / Sync trigger */}
        <button
          onClick={() => {
            fetchForecastData();
            addLog('REPOSITORY', 'همگام‌سازی و بازآموزی زنده مدل‌های داده‌ای AICE انجام شد', 'مدل‌های رگرسیون تکی و طبقه‌بندی شبکه‌ای به روز شدند');
          }}
          className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700/80 px-3 py-1.5 rounded-xl border border-slate-700 transition flex items-center gap-1.5 text-xs font-bold"
          title="بازآموزی مدل"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>بازآموزی زنده موتور</span>
        </button>
      </div>

      {/* Tabs navigation panel */}
      <div className="bg-[#14191f] border-b border-[#1e252d] px-4 py-1.5 flex gap-1 overflow-x-auto">
        {[
          { id: 'blueprint', label: '🧠 معمار و سورس کاتلین', icon: Layers },
          { id: 'search', label: '🔍 تست جستجو و چت', icon: Search },
          { id: 'vendor', label: '📊 پیش‌بینی غرفه‌داران', icon: BarChart3 },
          { id: 'admin', label: '🛡️ نگهبان و امنیت ادمین', icon: ShieldAlert },
          { id: 'roadmap', label: '🚀 نقشه راه و APIها', icon: Calendar },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3 py-2 rounded-lg text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap active:scale-95 ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/10'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <tab.icon className="w-3.5 h-3.5" />
            <span>{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Primary Sandbox Space */}
      <div className="flex-1 overflow-y-auto p-5 text-slate-200">
        
        {/* Tab 1: Blueprint & Kotlin Source code */}
        {activeTab === 'blueprint' && (
          <div className="space-y-5 animate-fade-in">
            
            {/* Visual CSS-based Architecture Pipeline */}
            <div className="bg-[#191f26] border border-slate-800 p-4.5 rounded-2xl relative">
              <span className="absolute top-3 left-3 text-[9px] font-mono text-slate-500 bg-slate-900 px-2 py-0.5 rounded border border-white/5">ARCH DIAGRAM</span>
              <h3 className="text-xs font-black text-indigo-400 mb-3 flex items-center gap-1.5">
                <Cpu className="w-4 h-4" />
                بستر جریان داده و بهینه‌سازی جریان AICE
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center text-center text-[10px] text-slate-300 font-bold mt-4" dir="ltr">
                <div className="bg-slate-800/80 border border-slate-700 p-3 rounded-xl flex flex-col items-center gap-1">
                  <span className="text-blue-400 font-extrabold">Kotlin Client</span>
                  <p className="text-[8px] text-slate-400 font-medium">Jetpack Compose UI & Voice Signals</p>
                </div>
                <div className="text-indigo-400 text-center flex justify-center py-1">➔</div>
                <div className="bg-slate-800/80 border border-slate-700 p-3 rounded-xl flex flex-col items-center gap-1">
                  <span className="text-indigo-400 font-extrabold">AICE REST Proxy</span>
                  <p className="text-[8px] text-slate-400 font-medium">server.ts Node API Server</p>
                </div>
                <div className="text-indigo-400 text-center flex justify-center py-1">➔</div>
                <div className="bg-slate-800/80 border border-indigo-600/50 shadow shadow-indigo-600/10 p-3 rounded-xl flex flex-col items-center gap-1">
                  <span className="text-emerald-400 font-black">Gemini 3.5 Flash / embedding-2</span>
                  <p className="text-[8px] text-slate-400 font-medium">Semantic Reasoning & Vector Retrieval</p>
                </div>
              </div>
            </div>

            {/* Jetpack Compose Kotlin Integration Reference */}
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-850 pb-1.5">
                <h4 className="text-xs font-black text-slate-200">پیاده‌سازی کلاینت در بخش معماری کاتلین (MVVM)</h4>
                <div className="flex items-center gap-1 text-[9px] text-[#22c55e] font-mono bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#22c55e]" />
                  ir.useonline.shop.ai
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Repository implementation code */}
                <div className="bg-[#161a1f] border border-slate-850 rounded-xl p-3 flex flex-col gap-2">
                  <div className="flex justify-between items-center bg-[#1c2229] px-3 py-1 rounded-lg">
                    <span className="text-[9px] font-mono text-slate-400">AiRepositoryImpl.kt</span>
                    <span className="text-[8px] font-bold text-indigo-400">clean architecture</span>
                  </div>
                  <pre className="text-[9px] font-mono text-cyan-400 overflow-x-auto p-1 text-left leading-relaxed max-h-36 overflow-y-auto" dir="ltr">
{`package ir.useonline.shop.data.repository

import ir.useonline.shop.domain.model.AiForecast
import ir.useonline.shop.domain.repository.AiRepository
import io.ktor.client.*
import io.ktor.client.request.*

class AiRepositoryImpl(private val httpClient: HttpClient) : AiRepository {
    override suspend fun getSemanticSearchResults(query: String): List<String> {
        return httpClient.post("/api/ai/search") {
            setBody(SearchRequest(query))
        }
    }
}`}
                  </pre>
                </div>

                {/* Jetpack Compose UI code */}
                <div className="bg-[#161a1f] border border-slate-850 rounded-xl p-3 flex flex-col gap-2">
                  <div className="flex justify-between items-center bg-[#1c2229] px-3 py-1 rounded-lg">
                    <span className="text-[9px] font-mono text-slate-400">AiShoppingAssistantScreen.kt</span>
                    <span className="text-[8px] font-bold text-pink-400">compose ui</span>
                  </div>
                  <pre className="text-[9px] font-mono text-pink-400 overflow-x-auto p-1 text-left leading-relaxed max-h-36 overflow-y-auto" dir="ltr">
{`@Composable
fun AiShoppingAssistantScreen(viewModel: AiAssistantViewModel) {
    val uiState by viewModel.uiState.collectAsState()
    
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        items(uiState.messages) { message ->
            ChatBubble(
                text = message.text,
                isUser = message.isUser,
                shape = RoundedCornerSize(16.dp)
            )
        }
    }
}`}
                  </pre>
                </div>

              </div>
            </div>

          </div>
        )}

        {/* Tab 2: Interactive Search & Chat Sandbox */}
        {activeTab === 'search' && (
          <div className="space-y-6 animate-fade-in grid grid-cols-1 md:grid-cols-12 gap-6 p-1">
            
            {/* Left Col: Typo-Tolerant Semantic Search Sandbox */}
            <div className="md:col-span-6 bg-[#181d24] border border-slate-800 p-4.5 rounded-2xl flex flex-col justify-between gap-4 h-[440px]">
              <div className="space-y-3">
                <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                  <h3 className="text-xs font-black text-white flex items-center gap-1.5">
                    <Search className="w-4 h-4 text-blue-400" />
                    شبیه‌ساز جستجوی معنایی و خطایاب فارسی
                  </h3>
                  <span className="text-[9px] text-[#3b82f6] font-mono bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/15">
                    Typo Tolerance
                  </span>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="یک عبارت با غلط املایی وارد کنید (مثال: سامسونك s24, ایرپاد اپل, کیف کوه)..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="flex-1 bg-slate-900 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-indigo-600 rounded-xl px-3 py-2 text-xs text-right whitespace-nowrap placeholder:text-slate-500"
                    onKeyDown={(e) => e.key === 'Enter' && handleSemanticSearchDemo('')}
                  />
                  <button
                    onClick={() => handleSemanticSearchDemo('')}
                    disabled={isSearching}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1 shrink-0 active:scale-95 transition"
                  >
                    {isSearching ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : 'پردازش'}
                  </button>
                </div>

                {/* Quick pre-made bad spellings buttons */}
                <div>
                  <span className="text-[9px] font-black text-slate-400 block mb-1">غلط‌های املایی نمونه برای تست:</span>
                  <div className="flex gap-1.5 flex-wrap">
                    {[
                      { show: 'سامسونك s24', real: 'سامسونك s24' },
                      { show: 'ایرباد نویزکنسلینگ', real: 'ایرباد نویزکنسلینگ' },
                      { show: 'کفش رانینك نایک', real: 'کفش رانینك نایک' },
                      { show: 'کیف کوهنوردی دیوتر', real: 'کیف کوهنوردی دیوتر' },
                    ].map((badge) => (
                      <button
                        key={badge.show}
                        onClick={() => handleSemanticSearchDemo(badge.real)}
                        className="text-[8px] font-bold bg-slate-800 hover:bg-indigo-950/40 text-indigo-300 hover:text-white px-2 py-1 rounded-lg border border-slate-700 transition"
                      >
                        {badge.show}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Search Results Visual Segment */}
              <div className="flex-1 bg-slate-950/50 rounded-xl border border-[#222a33] p-3 overflow-y-auto mt-2 space-y-2">
                {searchResults.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-slate-500 text-[10px] text-center p-4">
                    <Terminal className="w-6 h-6 text-slate-600 mb-1" />
                    <span>هیچ داده‌ای جستجو نشده است یا موردی یافت نگردید.</span>
                    <p className="text-[9px] text-slate-600 mt-1">تست خطایاب معنایی بالا را بفشارید</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <div className="flex justify-between text-[8px] text-slate-500 mb-1 border-b border-slate-900 pb-1">
                      <span>شناسه کالا / دلیل همخوانی هوشمند</span>
                      <span>امتیاز انطباق معنایی</span>
                    </div>
                    {searchResults.map((r, i) => (
                      <div key={i} className="bg-[#14191e] border border-slate-850 p-2 rounded-lg flex items-center justify-between gap-3 text-right">
                        <div>
                          <span className="text-[10px] font-black text-white block line-clamp-1">{getProductTitleFromId(r.productId)}</span>
                          <span className="text-[8px] font-bold text-indigo-400 block mt-1">{r.reason}</span>
                        </div>
                        <div className="text-left shrink-0">
                          <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-md ${
                            r.relevance > 0.8 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/15' : 'bg-amber-500/10 text-amber-400 border border-amber-500/15'
                          }`}>
                            {Math.round(r.relevance * 100)}٪
                          </span>
                        </div>
                      </div>
                    ))}
                    
                    {searchSuggestions.length > 0 && (
                      <div className="pt-2 border-t border-slate-900">
                        <span className="text-[8px] text-slate-500 block mb-1">کلمات پیشنهادی هوشمند سیستم (Suggestions):</span>
                        <div className="flex gap-1">
                          {searchSuggestions.map((s, i) => (
                            <span key={i} className="text-[8px] font-black bg-slate-900 text-slate-300 border border-slate-800 px-2 py-0.5 rounded-full">
                              {s}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Right Col: Interactive Conversational Shopping Assistant Chat */}
            <div className="md:col-span-6 bg-[#181d24] border border-slate-800 p-4.5 rounded-2xl flex flex-col justify-between gap-3 h-[440px]">
              <div className="flex justify-between items-center border-b border-slate-800 pb-2">
                <h3 className="text-xs font-black text-white flex items-center gap-1.5">
                  <Brain className="w-4 h-4 text-emerald-400 inline animate-pulse" />
                  دستیار صوتی و گفتار یوزآنلاین (Shopping Copilot)
                </h3>
                <span className="text-[9px] text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/15">
                  Gemini API Gateway
                </span>
              </div>

              {/* Conversational Screen Frame */}
              <div className="flex-1 bg-slate-950/60 rounded-xl border border-slate-850 p-3 overflow-y-auto space-y-2.5 flex flex-col">
                {chatMessages.map((msg, i) => (
                  <div 
                    key={i} 
                    className={`max-w-[85%] text-[10px] leading-relaxed p-2.5 rounded-2xl ${
                      msg.sender === 'user' 
                        ? 'bg-indigo-600 text-white self-start rounded-tr-none text-right' 
                        : 'bg-slate-800/90 text-slate-200 self-end rounded-tl-none text-right'
                    }`}
                  >
                    {msg.sender === 'bot' ? (
                      <div className="whitespace-pre-wrap font-medium">
                        {msg.text}
                      </div>
                    ) : (
                      <span>{msg.text}</span>
                    )}
                  </div>
                ))}
                {isChatLoading && (
                  <div className="self-end bg-slate-800/50 text-slate-400 text-[10px] px-3 py-2 rounded-2xl rounded-tl-none flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce" />
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce delay-100" />
                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-bounce delay-200" />
                  </div>
                )}
              </div>

              {/* Quick pre-made assistant prompts matches */}
              <div className="flex gap-1 overflow-x-auto pb-1 scrollbar-none" dir="rtl">
                {[
                  'مقایسه کلاهای گران قیمت',
                  'معرفی هدفون اپل',
                  'پیشنهاد بر اساس بودجه ۵ میلیونی',
                ].map((txt) => (
                  <button
                    key={txt}
                    onClick={() => {
                      setChatInput(txt);
                    }}
                    className="text-[8px] font-black bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white px-2 py-1 rounded-lg border border-slate-800 shrink-0 select-none transition"
                  >
                    {txt}
                  </button>
                ))}
              </div>

              {/* Chat Input form */}
              <form onSubmit={handleAssistantChat} className="flex gap-2 border-t border-slate-800 pt-2 shrink-0">
                <input
                  type="text"
                  placeholder="مشخصات فنی بپرسید، یا بگید بر اساس بودجه‌تون کالا پیدا کنه..."
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  className="flex-1 bg-slate-900 border border-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-500 rounded-xl px-3 py-1.5 text-[10px] text-right placeholder:text-slate-500"
                />
                <button
                  type="submit"
                  disabled={isChatLoading}
                  className="bg-emerald-600 hover:bg-emerald-500 font-bold px-3 py-1.5 rounded-xl text-xs text-white shadow-sm flex items-center justify-center shrink-0 active:scale-95 transition"
                >
                  <Send className="w-3.5 h-3.5 rotate-180" />
                </button>
              </form>
            </div>

          </div>
        )}

        {/* Tab 3: Predictive Forecasting & Inventory Analytics for Vendors */}
        {activeTab === 'vendor' && (
          <div className="space-y-6 animate-fade-in text-right">
            
            {/* Top overview row widgets */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-[#181d24] border border-slate-800 p-4 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[9px] text-slate-400 block font-bold mb-1">دقت پیش‌بینی تقاضا AICE</span>
                  <span className="text-base font-black text-emerald-400">۹۴.۲٪ <span className="text-[10px] font-medium text-slate-500">موفق</span></span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                  <CheckCircle className="w-4 h-4" />
                </div>
              </div>

              <div className="bg-[#181d24] border border-slate-800 p-4 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[9px] text-slate-400 block font-bold mb-1">کالاهای بحرانی کم‌موجودی</span>
                  <span className="text-base font-black text-rose-500">۲ <span className="text-[10px] font-medium text-slate-500">غرفه</span></span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-rose-500/10 text-rose-400 flex items-center justify-center">
                  <AlertTriangle className="w-4 h-4 animate-bounce" />
                </div>
              </div>

              <div className="bg-[#181d24] border border-slate-800 p-4 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[9px] text-slate-400 block font-bold mb-1">پیشنهادات تغییر قیمت</span>
                  <span className="text-base font-black text-blue-400">۳ مورد <span className="text-[10px] font-medium text-slate-500">بهینه</span></span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
                  <Lightbulb className="w-4 h-4" />
                </div>
              </div>

              <div className="bg-[#181d24] border border-slate-800 p-4 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-[9px] text-slate-400 block font-bold mb-1">متوسط چرخش سرمایه انبار</span>
                  <span className="text-base font-black text-yellow-400">۱۲ روز <span className="text-[10px] font-medium text-slate-500">بهبودیافته</span></span>
                </div>
                <div className="w-8 h-8 rounded-lg bg-yellow-500/10 text-yellow-500 flex items-center justify-center">
                  <RotateCcw className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Custom Interactive SVG Graph representing Category wise demand forecasts */}
            <div className="bg-[#181d24] border border-slate-800 p-5 rounded-2xl relative">
              <div className="flex md:flex-row flex-col justify-between items-start md:items-center border-b border-slate-850 pb-3 mb-4 gap-2">
                <div>
                  <h3 className="text-xs font-black text-white flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                    تحلیل زمانی و الگوی تقاضای کالای دیجیتال، مد، و خانه (۳۰ روزه)
                  </h3>
                  <span className="text-[9px] text-slate-400">پیش‌بینی حجم کل سفارش به واحد کالا بر پایه‌ی شبکه‌ی عصبی بازگشتی (LSTM)</span>
                </div>

                <div className="flex gap-3 text-[8px] font-extrabold select-none">
                  <div className="flex items-center gap-1">
                    <span className="w-2.5 h-1 bg-indigo-500 rounded-full" />
                    <span>دیجیتال</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="w-2.5 h-1 bg-emerald-500 rounded-full" />
                    <span>مد و پوشاک</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="w-2.5 h-1 bg-yellow-500 rounded-full" />
                    <span>آشپزخانه</span>
                  </div>
                </div>
              </div>

              {/* Vector responsive line chart */}
              <div className="h-44 w-full relative flex items-end">
                <svg className="w-full h-full overflow-visible" viewBox="0 0 500 120" preserveAspectRatio="none">
                  {/* Grid Lines */}
                  <line x1="0" y1="20" x2="500" y2="20" stroke="#1d242c" strokeWidth="1" />
                  <line x1="0" y1="50" x2="500" y2="50" stroke="#1d242c" strokeWidth="1" />
                  <line x1="0" y1="80" x2="500" y2="80" stroke="#1d242c" strokeWidth="1" />
                  <line x1="0" y1="110" x2="500" y2="110" stroke="#1d242c" strokeWidth="1" strokeDasharray="3 3" />

                  {/* Digital projection line (Purple/indigo) */}
                  <path
                    d="M 0 60 Q 50 20, 100 80 T 200 40 T 300 70 T 400 30 T 500 50"
                    fill="none"
                    stroke="#6366f1"
                    strokeWidth="3.5"
                    strokeLinecap="round"
                  />

                  {/* Apparel line (green) */}
                  <path
                    d="M 0 80 Q 70 50, 140 100 T 280 60 T 420 85 T 500 65"
                    fill="none"
                    stroke="#10b981"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeDasharray="1 1"
                  />

                  {/* Kitchen line (yellow) */}
                  <path
                    d="M 0 100 Q 60 90, 150 110 T 300 80 T 450 95 T 500 90"
                    fill="none"
                    stroke="#f59e0b"
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </svg>

                {/* X labels */}
                <div className="absolute inset-x-0 -bottom-5 flex justify-between text-[8px] text-slate-500 font-mono" dir="ltr">
                  <span>Day 1</span>
                  <span>Day 10</span>
                  <span>Day 20</span>
                  <span>Day 30 (Forecasted target)</span>
                </div>
              </div>
            </div>

            {/* Inventory Predictor & Dynamic Pricing Strategy Matrix */}
            <div className="bg-[#181d24] border border-slate-800 p-5 rounded-2xl relative space-y-3">
              <div className="flex justify-between items-center border-b border-slate-850 pb-2">
                <h3 className="text-xs font-black text-white flex items-center gap-1.5">
                  <Cpu className="w-4 h-4 text-indigo-400" />
                  سامانه بهینه‌سازی زنده قیمت و رصد فرسودگی انبار (Pricing & Inventory Matrix)
                </h3>
                <div className="flex gap-1.5 text-[8px] font-bold">
                  <button onClick={() => setPricingFilter('ALL')} className={`px-2 py-0.5 rounded ${pricingFilter === 'ALL' ? 'bg-[#1e252d] text-white border border-[#2d3844]' : 'text-slate-500'}`}>همه کالاها</button>
                  <button onClick={() => setPricingFilter('ALARM')} className={`px-2 py-0.5 rounded ${pricingFilter === 'ALARM' ? 'bg-red-500/10 text-red-400 border border-red-500/20' : 'text-slate-500'}`}>کم‌موجودی بحرانی</button>
                  <button onClick={() => setPricingFilter('STALE')} className={`px-2 py-0.5 rounded ${pricingFilter === 'STALE' ? 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/20' : 'text-slate-500'}`}>آهنگ چرخش کند</button>
                </div>
              </div>

              {isLoadingForecast ? (
                <div className="text-center py-8 text-xs text-slate-500">در حال بارگیری محاسبات...</div>
              ) : (
                <div className="space-y-3">
                  {forecastingData?.inventoryForecasts
                    .filter((item: any) => {
                      if (pricingFilter === 'ALARM') return item.lowStockAlarm;
                      if (pricingFilter === 'STALE') return item.daysToExhaustion > 30;
                      return true;
                    })
                    .map((item: any) => (
                      <div 
                        key={item.productId} 
                        className={`bg-[#14191e] border p-3 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 text-right ${
                          item.lowStockAlarm ? 'border-red-500/20 bg-red-500/[0.02]' : 'border-slate-850'
                        }`}
                      >
                        <div className="flex-1 min-w-0">
                          <span className="text-[10px] font-black text-white block truncate">{item.title}</span>
                          <div className="flex flex-wrap gap-2 mt-1 px-0.5">
                            <span className="text-[8px] font-bold text-slate-400 block">شناسه غرفه: {item.vendorName}</span>
                            <span className="text-[8px] font-bold text-slate-400 block">•</span>
                            <span className="text-[8px] font-bold text-slate-400 block">سرعت فروش روزانه: ~{item.dailyDemandRate} واحد</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-4 text-right shrink-0">
                          <div className="text-right">
                            <span className="text-[8px] text-slate-400 block">موجودی انبار</span>
                            <span className={`text-[10px] font-extrabold ${item.lowStockAlarm ? 'text-red-400' : 'text-emerald-400'}`}>
                              {item.currentStock} کالا
                            </span>
                          </div>
                          
                          <div className="text-right">
                            <span className="text-[8px] text-slate-400 block">پیش‌بینی دوام انبار</span>
                            <span className={`text-[10px] font-black ${item.lowStockAlarm ? 'text-red-400 animate-pulse' : 'text-slate-200'}`}>
                              {item.daysToExhaustion} روز دیگر
                            </span>
                          </div>

                          <div className="text-right md:max-w-xs">
                            <span className="text-[8px] text-indigo-400 block font-bold">پیشنهاد هوش مصنوعی (Gemini Dynamic Rate)</span>
                            <span className="text-[9px] font-black text-blue-400 block mt-0.5 leading-snug">{item.pricingStrategy}</span>
                          </div>
                        </div>
                      </div>
                    ))
                  }
                </div>
              )}
            </div>

          </div>
        )}

        {/* Tab 4: Admin AI Behavior Cluster & Fraud Prevention */}
        {activeTab === 'admin' && (
          <div className="space-y-6 animate-fade-in">
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Customer Buying cluster diagram */}
              <div className="bg-[#181d24] border border-slate-800 p-4.5 rounded-2xl flex flex-col justify-between h-[360px]">
                <div>
                  <h3 className="text-xs font-black text-white mb-1 flex items-center gap-1.5">
                    <TrendingUp className="w-4 h-4 text-blue-400" />
                    خوشه‌بندی هوشمند مشتریان یوزآنلاین (Customer segments)
                  </h3>
                  <span className="text-[8px] text-slate-400 block mb-3 border-b border-slate-850 pb-1.5">گزارش طبقه‌بندی هوش هوایی مبتنی بر میانگین مقدار سبد و سابقه تعامل</span>
                </div>

                <div className="flex-1 flex items-center justify-center p-3 relative h-40">
                  {/* CSS bento coordinate cluster representation */}
                  <div className="w-full h-full border border-slate-800/80 rounded-lg relative overflow-hidden backdrop-blur-3xl bg-slate-900/60 p-1">
                    {/* Y-axis label */}
                    <div className="absolute left-2 top-2 text-[6px] font-mono text-slate-500 rotate-90 origin-left">سقف خرید (تومان)</div>
                    {/* X-axis label */}
                    <div className="absolute right-2 bottom-1 text-[6px] font-mono text-slate-500">بسامد خرید (سالیانه)</div>

                    {/* Cluster circle 1 (Elite Buyers) */}
                    <div className="absolute top-4 right-10 w-16 h-16 bg-blue-500/10 border border-blue-500/40 rounded-full flex flex-col items-center justify-center text-center animate-pulse">
                      <span className="text-[7px] font-black text-blue-400 block">وفادار / مرفه</span>
                      <span className="text-[6px] text-slate-400 block">۱۲٪ اعضا</span>
                    </div>

                    {/* Cluster circle 2 (Discount Hunters) */}
                    <div className="absolute bottom-6 left-6 w-20 h-20 bg-[#ff4d4f]/10 border border-red-500/30 rounded-full flex flex-col items-center justify-center text-center">
                      <span className="text-[7px] font-black text-red-400 block">شکارچیان تخفیف</span>
                      <span className="text-[6px] text-slate-400 block">۴۵٪ اعضا</span>
                    </div>

                    {/* Cluster circle 3 (Moderate Digital Tech) */}
                    <div className="absolute top-12 left-20 w-14 h-14 bg-yellow-500/10 border border-yellow-500/30 rounded-full flex flex-col items-center justify-center text-center">
                      <span className="text-[7px] font-black text-yellow-400 block">فن‌دوست / دیجیتال</span>
                      <span className="text-[6px] text-slate-400 block">۲۸٪ اعضا</span>
                    </div>
                  </div>
                </div>

                <div className="pt-2">
                  <p className="text-[9px] text-slate-400 leading-normal leading-relaxed text-right font-medium">
                    <span className="text-blue-500 font-extrabold">پیشنهاد اتوماسیون:</span> کمپین اختصاصی اعتباری Tara برای بخش <span className="text-red-400 font-bold">شکارچیان تخفیف</span> جهت ارتقای ضریب وفاداری تا ۱۵ درصد توصیه می‌شود.
                  </p>
                </div>
              </div>

              {/* Fraud prevention panel */}
              <div className="bg-[#181d24] border border-slate-800 p-4.5 rounded-2xl flex flex-col justify-between h-[360px]">
                <div>
                  <h3 className="text-xs font-black text-rose-500 mb-1 flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 animate-pulse inline" />
                    نگهبان و سپر سایبری تراکنش‌های مشکوک (AICE Anti-Fraud)
                  </h3>
                  <span className="text-[8px] text-slate-400 block mb-3 border-b border-slate-850 pb-1.5">سامانه زنده یادگیری تقویتی جهت رهگیری تلاش‌های تکراری و کلاه‌برداری نشست</span>
                </div>

                {/* Fraud logs matches list */}
                <div className="flex-1 overflow-y-auto space-y-2 px-1">
                  {forecastingData?.fraudDetections.map((f: any) => (
                    <div key={f.id} className="bg-[#14191e] border border-slate-850 p-2.5 rounded-xl flex items-center justify-between text-right">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] font-black text-white">{f.userId}</span>
                          <span className={`text-[8px] font-extrabold px-1.5 py-0.5 rounded ${
                            f.score > 85 ? 'bg-red-500/10 text-red-500 border border-red-500/20' : 'bg-yellow-500/10 text-yellow-500'
                          }`}>
                            خطر {f.score}٪
                          </span>
                        </div>
                        <span className="text-[8px] text-slate-400 block mt-1 leading-normal">دلیل: {f.reason}</span>
                      </div>
                      <div className="text-left shrink-0">
                        <span className="text-[8px] font-mono text-slate-500 block mb-1">{f.timestamp}</span>
                        <span className="text-[8px] font-black text-emerald-400 block bg-emerald-500/5 px-2 py-0.5 rounded border border-emerald-500/10">{f.action}</span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="pt-2 text-[9px] text-[#ff4d4f] font-bold bg-red-500/[0.02] border border-red-500/10 p-2.5 rounded-xl leading-normal text-right">
                  سیستم خودکار به طور زنده درگاه‌های SnappPay را ردیابی کرده و تاکنون ۲۳ تلاش هکی ناموفق را مسدود کرده است.
                </div>
              </div>

            </div>

          </div>
        )}

        {/* Tab 5: Implementation Roadmap & APIs */}
        {activeTab === 'roadmap' && (
          <div className="space-y-6 animate-fade-in text-right">
            
            {/* API Specifications explorer */}
            <div className="space-y-3">
              <h3 className="text-xs font-black text-white flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-cyan-400" />
                سند فنی و لیست اندپوینت‌های هوش مصنوعی (API Endpoints & Specs)
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Chat JSON Endpoint */}
                <div className="bg-[#14191e] border border-slate-850 p-3 rounded-xl space-y-2">
                  <div className="flex justify-between items-center bg-[#1c222a] px-2.5 py-1 rounded-lg">
                    <span className="text-[8px] font-mono text-cyan-400 font-extrabold">POST /api/ai/chat</span>
                    <span className="text-[8px] text-slate-400">Shopping Assistant</span>
                  </div>
                  <pre className="text-[8px] font-mono text-slate-300 overflow-x-auto text-left leading-normal" dir="ltr">
{`{
  "message": "مقایسه هدفون اپل و ساعت شیائومی",
  "history": [
    { "role": "user", "text": "سلام" },
    { "role": "model", "text": "به بازارچه خوش آمدید..." }
  ]
}`}
                  </pre>
                </div>

                {/* Forecast JSON Endpoint */}
                <div className="bg-[#14191e] border border-slate-850 p-3 rounded-xl space-y-2">
                  <div className="flex justify-between items-center bg-[#1c222a] px-2.5 py-1 rounded-lg">
                    <span className="text-[8px] font-mono text-indigo-400 font-extrabold">GET /api/ai/forecasting</span>
                    <span className="text-[8px] text-slate-400">Inventory & Fraud Engine</span>
                  </div>
                  <pre className="text-[8px] font-mono text-slate-300 overflow-x-auto text-left leading-normal" dir="ltr">
{`{
  "demandProjections": { "digital": [120, 115, ...], "apparel": [...] },
  "inventoryForecasts": [
    { "productId": "p1", "daysToExhaustion": 10, "lowStockAlarm": false }
  ]
}`}
                  </pre>
                </div>

              </div>
            </div>

            {/* Interactive Gantt Roadmap */}
            <div className="space-y-4">
              <div className="border-b border-slate-850 pb-2">
                <h3 className="text-xs font-black text-white flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-emerald-400" />
                  برنامه اجرایی چهارمرحله‌ای تا پیاده‌سازی تولیدی (AICE Launch Roadmap)
                </h3>
                <span className="text-[8px] text-slate-400">نقشه تضمین کارکرد و راه‌اندازی گام به گام ماژول‌ها توسط تیم مهندسی UseOnline</span>
              </div>

              <div className="relative border-r border-[#312e81] pr-5 space-y-4 text-right">
                
                {[
                  { title: 'فاز اول: توسعه محلی و آماده‌سازی برد تعبیه‌شده داده‌ها', time: 'هفته ۱ تا ۲', desc: 'بارگذاری کاتالوگ محصولات اتمیک UseOnline در پایگاه داده و تنظیم سیستم لایه‌بندی در کاتلین', status: 'کامل شده' },
                  { title: 'فاز دوم: اتصال به واسط‌های زنده و بهینه‌سازی بومی Gemini API', time: 'هفته ۳ تا ۴', desc: 'یکپارچه‌سازی هاب Express با سیستم REST اندروید و پیاده‌سازی توابع معنایی صوتی', status: 'در حال توسعه' },
                  { title: 'فاز سوم: راه‌اندازی پیش‌بین‌های انبار و هوش تجاری غرفه‌داران', time: 'هفته ۵ تا ۶', desc: 'توسعه داشبوردهای تحلیلی با استفاده از مدل‌های پیش‌بینی سری‌های زمانی صفت', status: 'برنامه‌ریزی شده' },
                  { title: 'فاز چهارم: تست‌های رفتاری A/B و سیستم‌های ایمنی نگهبان', time: 'هفته ۷ تا ۸', desc: 'پیکربندی سیستم کشف رفتارهای انحرافی کلاهبران و بهینه‌سازی سرعت واکشی معنایی کالاها', status: 'برنامه‌ریزی شده' },
                ].map((step, i) => (
                  <div key={i} className="relative">
                    {/* Circle timeline decorator */}
                    <div className="absolute -right-[25px] top-1 w-2.5 h-2.5 rounded-full bg-indigo-500 border border-slate-900 shadow shadow-indigo-500/50" />
                    
                    <div className="bg-[#181d24] border border-slate-850 p-3 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3 text-right">
                      <div>
                        <span className="text-[10px] font-black text-white">{step.title}</span>
                        <p className="text-[8.5px] text-slate-400 leading-normal mt-1 leading-relaxed font-medium">{step.desc}</p>
                      </div>
                      <div className="text-left shrink-0">
                        <span className="text-[8px] font-mono text-indigo-400 block font-bold">{step.time}</span>
                        <span className={`text-[8.5px] font-black px-2 py-0.5 rounded mt-1.5 inline-block ${
                          step.status === 'کامل شده' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/15' : 'bg-slate-700/50 text-slate-400'
                        }`}>{step.status}</span>
                      </div>
                    </div>
                  </div>
                ))}

              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
