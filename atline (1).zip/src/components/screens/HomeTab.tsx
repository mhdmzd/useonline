import React, { useState, useEffect } from 'react';
import { Search, Bell, ShoppingCart, Sparkles, Flame, Percent, Star, ArrowLeft, ArrowRight, ShieldCheck, Mic, Laptop, Shirt, Home, LayoutGrid, Brain, ChevronRight, X, Send } from 'lucide-react';
import { mockBanners } from '../../data/mockProducts';
import { Product, ArchLog } from '../../types';

interface HomeTabProps {
  onProductSelect: (p: Product) => void;
  favorites: string[];
  toggleFavorite: (p: Product) => void;
  onNavigateToTab: (index: number) => void;
  addLog: (layer: ArchLog['layer'], message: string, details: string) => void;
  onOpenNotifications: () => void;
  notificationCount: number;
  products: Product[];
  cartCount?: number;
}

export function HomeTab({
  onProductSelect,
  favorites,
  toggleFavorite,
  onNavigateToTab,
  addLog,
  onOpenNotifications,
  notificationCount,
  products = [],
  cartCount = 0,
}: HomeTabProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [bannerIndex, setBannerIndex] = useState(0);
  const [timeLeft, setTimeLeft] = useState({ hours: 2, minutes: 48, seconds: 54 });
  const [isListening, setIsListening] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // AICE Customer Chat States
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);
  const [clientChatInput, setClientChatInput] = useState('');
  const [clientChatMessages, setClientChatMessages] = useState<Array<{ role: 'user' | 'model'; text: string }>>([
    { role: 'model', text: 'سلام! من دستیار هوشمند و الیار خرید یوزآنلاین (UseOnline Copilot) هستم. چطور می‌توانم برای یک خرید پرنشاط، مطمئن و سودآور به شما کمک کنم؟ مثلاً بپرسید: تفاوت قیمت کالاها، معرفی بهترین پرچمدار، یا تناسب محصول با بودجه شما.' }
  ]);
  const [isClientChatLoading, setIsClientChatLoading] = useState(false);

  const handleClientChatSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientChatInput.trim() || isClientChatLoading) return;

    const userMessage = clientChatInput;
    setClientChatInput('');
    setClientChatMessages((prev) => [...prev, { role: 'user', text: userMessage }]);
    setIsClientChatLoading(true);

    addLog('UI', 'سیستم اندرویدی: انتقال پیام به سرور هوش مصنوعی یوزآنلاین', userMessage);

    // payload preparation
    const historyPayload = clientChatMessages.slice(1).map(m => ({
      role: m.role,
      text: m.text
    }));

    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMessage, history: historyPayload })
      });

      if (res.ok) {
        const data = await res.json();
        setClientChatMessages((prev) => [...prev, { role: 'model', text: data.response }]);
        addLog('VIEWMODEL', 'پاسخ دستیار با موفقیت دریافت و رندر گردید', `تارگت هوشمند: ${data.isSimulated ? 'شبیه‌سازی آفلاین' : 'Gemini AI'}`);
      } else {
        throw new Error('API request failed');
      }
    } catch (err) {
      setClientChatMessages((prev) => [...prev, { role: 'model', text: 'ارتباط با غرفه هوشمند قطع شده است. تلاش مجمدد فرمایید.' }]);
    } finally {
      setIsClientChatLoading(false);
    }
  };

  // Carousel auto-slide
  useEffect(() => {
    const bannerTimer = setInterval(() => {
      setBannerIndex((prev) => (prev + 1) % mockBanners.length);
    }, 5000);
    return () => clearInterval(bannerTimer);
  }, []);

  // Flash sales countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          return { hours: 2, minutes: 59, seconds: 59 }; // Reset
        }
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleProductCardClick = (product: Product) => {
    addLog('UI', 'کلیک بر روی کارت محصول در صفحه اصلی', `عنوان: ${product.title}`);
    addLog('VIEWMODEL', 'بارگذاری جزئیات محصول در ItemDetailViewModel', `productId = ${product.id}`);
    addLog('USECASE', 'فراخوانی GetProductDetailsUseCase', 'بررسی کش یا دریافت از منبع داده سرور');
    onProductSelect(product);
  };

  const startVoiceSearch = () => {
    if (isListening) return;
    setIsListening(true);
    addLog('UI', 'رویداد تشخیص صوتی (SpeechRecognizer Intent) درخواست شد', 'آغاز شنود سیگنال لغتی از مایک هندست');
    addLog('VIEWMODEL', 'تغییر وضعیت و اتصال کانال صوتی در SpeechUiState.Recording', 'آغاز شبیه‌ساز ضبط بهینه بستر اندروید');

    const phrases = ['سامسونگ', 'مک‌بوک', 'هدفون', 'کتانی', 'قهوه‌ساز'];
    const selectedPhrase = phrases[Math.floor(Math.random() * phrases.length)];

    setTimeout(() => {
      setSearchQuery(selectedPhrase);
      setIsListening(false);
      addLog('USECASE', 'تحلیل سیگنال صوتی با SpeechToTextUseCase سیستم', `تشخیص قطعی کلام کاربر: "${selectedPhrase}"`);
      addLog('REPOSITORY', `فیلتر کاتالوگ سراسری دیتابیس با کلیدواژه تشخیص داده شده`, `کلید تگ: "${selectedPhrase}"`);
      addLog('UI', `جاگذاری متن شناسایی شده در فیلد جستجوی کلاینت: "${selectedPhrase}"`, 'فیلتر مستقیم محصولات');
    }, 1800);
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    addLog('UI', 'اجرای رویداد جستجوی کالا', `Query: ${searchQuery}`);
    addLog('VIEWMODEL', 'انجام فیلتر صفت در SearchViewModel', `متن جستجو شده: ${searchQuery}`);
  };

  const toPersianDigits = (num: number | string) => {
    const id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/[0-9]/g, (w) => id[+w]);
  };

  const formatPrice = (price: number) => {
    const formatted = price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return toPersianDigits(formatted);
  };

  const getParentCategoryId = (prodCategoryId: string): string => {
    if (['phones', 'laptops', 'audio', 'accessories'].includes(prodCategoryId)) return 'digital';
    if (['men-clothing', 'women-clothing', 'shoes', 'bags'].includes(prodCategoryId)) return 'apparel';
    if (['kitchen', 'decor', 'furniture'].includes(prodCategoryId)) return 'home';
    if (['skincare', 'perfume', 'makeup'].includes(prodCategoryId)) return 'cosmetics';
    if (['beverages', 'snacks', 'staples'].includes(prodCategoryId)) return 'supermarket';
    return '';
  };

  const filteredProducts = products.filter((p) => {
    const matchesSearch =
      p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.englishTitle.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (!matchesSearch) return false;
    
    if (selectedCategory === 'ALL') return true;
    return getParentCategoryId(p.categoryId) === selectedCategory;
  });

  return (
    <div className="flex flex-col bg-slate-50 min-h-full pb-20 font-vazir text-right relative" dir="rtl" id="home-tab-scroller">
      
      {/* Absolute Voice UI Listening Overlay inside the screen viewport */}
      {isListening && (
        <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex flex-col items-center justify-center text-white animate-fade-in rounded-3xl" id="voice-overlay-portal">
          <div className="bg-slate-800 rounded-3xl p-6 flex flex-col items-center border border-slate-700/50 shadow-2xl max-w-[240px] text-center">
            <div className="w-16 h-16 bg-red-500 text-white rounded-full flex items-center justify-center animate-bounce mb-4 shadow-lg shadow-red-500/30">
              <Mic className="w-8 h-8 animate-pulse text-white" />
            </div>
            <h4 className="text-xs font-black">در حال شنیدن گفتار شما...</h4>
            <p className="text-[10px] text-slate-300 mt-1.5 leading-normal">سیستم درگاه پردازش صدای یوزآنلاین فعال است</p>
            
            {/* Audio wave simulator */}
            <div className="flex gap-1 mt-4">
              <span className="w-1 h-3 bg-red-400 rounded-full animate-pulse"></span>
              <span className="w-1 h-6 bg-red-400 rounded-full animate-bounce"></span>
              <span className="w-1 h-4 bg-red-400 rounded-full animate-pulse"></span>
              <span className="w-1 h-7 bg-red-400 rounded-full animate-bounce"></span>
              <span className="w-1 h-2 bg-red-400 rounded-full animate-pulse"></span>
            </div>
          </div>
        </div>
      )}

      {/* Header Search Field */}
      <div className="sticky top-0 z-10 bg-white shadow-sm px-4 pt-3 pb-2.5 flex flex-col gap-2">
        <div className="flex items-center gap-3">
          <form onSubmit={handleSearch} className="relative flex-1">
            <Search className="absolute right-3 top-3 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="جستجوی کالا در یوزآنلاین..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-100 pr-10 pl-10 py-2 text-xs rounded-xl focus:outline-none focus:ring-1 focus:ring-blue-600 transition text-right"
            />
            <button
              type="button"
              onClick={startVoiceSearch}
              className={`absolute left-3 top-2.5 p-0.5 rounded-lg transition ${
                isListening ? 'text-red-600' : 'text-gray-400 hover:text-blue-600 hover:bg-slate-200'
              }`}
              title="جستجوی صوتی"
            >
              <Mic className="w-4 h-4" />
            </button>
          </form>
          <button
            onClick={() => {
              addLog('UI', 'باز کردن کشوی اعلانات اندرویدی', 'نمایش Notification Shade');
              onOpenNotifications();
            }}
            className="relative p-2.5 bg-slate-100 rounded-xl text-gray-700 active:scale-90 transition cursor-pointer"
            title="اعلانات"
          >
            <Bell className="w-4 h-4" />
            {notificationCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 text-white font-mono text-[9px] flex items-center justify-center rounded-full">
                {notificationCount}
              </span>
            )}
          </button>

          <button
            onClick={() => {
              addLog('UI', 'ناوبری هدایت سریع به صفحه سبد خرید', 'تغییر تب فعال بازارچه به سبد خرید');
              onNavigateToTab(2);
            }}
            className="relative p-2.5 bg-slate-100 hover:bg-slate-200 rounded-xl text-gray-700 active:scale-90 transition cursor-pointer"
            title="سبد خرید"
            id="heading-cart-icon-btn"
          >
            <ShoppingCart className="w-4 h-4 text-slate-800" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[16px] h-4 bg-red-500 text-white font-mono text-[8px] font-black flex items-center justify-center rounded-full px-1 shadow-sm ring-1 ring-white">
                {toPersianDigits(cartCount)}
              </span>
            )}
          </button>
        </div>

        {/* Categories Filter Chip Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-0.5 scrollbar-none" dir="rtl">
          {[
            { id: 'ALL', label: 'همه کالاها', icon: LayoutGrid },
            { id: 'digital', label: 'کالای دیجیتال', icon: Laptop },
            { id: 'apparel', label: 'مد و پوشاک', icon: Shirt },
            { id: 'home', label: 'خانه و آشپزخانه', icon: Home },
          ].map((chip) => {
            const IconComponent = chip.icon;
            const isSelected = selectedCategory === chip.id;
            return (
              <button
                key={chip.id}
                onClick={() => {
                  setSelectedCategory(chip.id);
                  addLog('UI', `تغییر دسته‌بندی فیلتر اصلی به "${chip.label}"`, `شناسه: ${chip.id}`);
                  addLog('VIEWMODEL', 'بارگذاری فید پویای فیلتر شده بر اساس صفت کلیدی', `دسته: ${chip.id}`);
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[10px] font-black transition-all duration-200 shrink-0 border select-none ${
                  isSelected
                    ? 'bg-blue-600 text-white border-blue-700 shadow-sm shadow-blue-500/20 active:scale-95'
                    : 'bg-slate-100 text-gray-600 hover:text-gray-950 border-slate-100 hover:bg-slate-200 active:scale-95'
                }`}
                id={`filter-chip-${chip.id}`}
              >
                <IconComponent className={`w-3.5 h-3.5 ${isSelected ? 'text-white' : 'text-gray-500'}`} />
                <span>{chip.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Prominent AI Companion Banner */}
      <div className="px-4 mt-3 select-none">
        <button
          onClick={() => {
            setIsAiAssistantOpen(true);
            addLog('UI', 'رویداد فعال‌سازی دستیار خرید هوشمند در شبیه‌ساز اندروید', 'بارگذاری دستیار سخن‌گو و مشاور');
          }}
          className="w-full bg-gradient-to-r from-blue-600 via-indigo-600 to-indigo-700 hover:from-blue-700 hover:to-indigo-800 text-white rounded-2xl p-3 flex items-center justify-between shadow-md shadow-indigo-600/10 cursor-pointer active:scale-[0.98] transition border border-white/10"
        >
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 bg-white/15 text-white rounded-lg flex items-center justify-center border border-white/10 shrink-0">
              <Brain className="w-4 h-4 animate-pulse" />
            </div>
            <div className="text-right">
              <span className="text-[10px] font-black block leading-none text-white">دستیار صوتی و متنی هوشمند یوزآنلاین</span>
              <span className="text-[8px] text-blue-100 block font-bold mt-1 leading-snug">پیشنهاد بودجه، مقایسه فنی و سبد مکمل با Gemini</span>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-blue-100 shrink-0" />
        </button>
      </div>

      {searchQuery === '' ? (
        <>
          {/* Slider Banners */}
          <div className="px-4 mt-4">
            <div className={`relative h-44 rounded-2xl overflow-hidden bg-gradient-to-tr ${mockBanners[bannerIndex].color} text-white p-5 flex flex-col justify-between shadow-md`}>
              <div className="absolute inset-0 opacity-20 mix-blend-overlay">
                <img src={mockBanners[bannerIndex].image} alt="Promotion" className="w-full h-full object-cover" />
              </div>
              <div className="relative z-10">
                <span className="bg-white/20 text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded-full">فستیوال یوزآنلاین</span>
                <h3 className="text-sm font-bold mt-2 leading-snug max-w-xs">{mockBanners[bannerIndex].title}</h3>
                <p className="text-[10px] text-white/80 mt-1 max-w-xs">{mockBanners[bannerIndex].subtitle}</p>
              </div>
              <button 
                onClick={() => onNavigateToTab(1)}
                className="relative z-10 self-start text-[10px] bg-white text-gray-900 font-extrabold px-3 py-1.5 rounded-lg active:scale-95 transition"
              >
                مشاهده محصولات
              </button>
              {/* Carousel Indicators */}
              <div className="absolute left-4 bottom-4 flex gap-1">
                {mockBanners.map((_, i) => (
                  <div
                    key={i}
                    className={`w-2 h-1.5 rounded-full transition-all ${i === bannerIndex ? 'bg-white w-4' : 'bg-white/40'}`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Quick Categories Bar */}
          <div className="px-4 mt-6">
            <h4 className="text-xs font-black text-gray-800 mb-3 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              دسته‌بندی‌های پیشنهادی
            </h4>
            <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-none" dir="rtl">
              <div
                onClick={() => onNavigateToTab(1)}
                className="flex flex-col items-center gap-2 cursor-pointer shrink-0"
              >
                <div className="w-12 h-12 rounded-full bg-blue-50 border border-blue-100 flex items-center justify-center text-blue-600 shadow-sm">
                  📱
                </div>
                <span className="text-[10px] font-bold text-gray-600">دیجیتال</span>
              </div>
              <div
                onClick={() => onNavigateToTab(1)}
                className="flex flex-col items-center gap-2 cursor-pointer shrink-0"
              >
                <div className="w-12 h-12 rounded-full bg-pink-50 border border-pink-100 flex items-center justify-center text-pink-600 shadow-sm">
                  👕
                </div>
                <span className="text-[10px] font-bold text-gray-600">پوشاک</span>
              </div>
              <div
                onClick={() => onNavigateToTab(1)}
                className="flex flex-col items-center gap-2 cursor-pointer shrink-0"
              >
                <div className="w-12 h-12 rounded-full bg-green-50 border border-green-100 flex items-center justify-center text-green-600 shadow-sm">
                  🍳
                </div>
                <span className="text-[10px] font-bold text-gray-600">خانه</span>
              </div>
              <div
                onClick={() => onNavigateToTab(1)}
                className="flex flex-col items-center gap-2 cursor-pointer shrink-0"
              >
                <div className="w-12 h-12 rounded-full bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-600 shadow-sm">
                  ✨
                </div>
                <span className="text-[10px] font-bold text-gray-600">آرایشی</span>
              </div>
              <div
                onClick={() => onNavigateToTab(1)}
                className="flex flex-col items-center gap-2 cursor-pointer shrink-0"
              >
                <div className="w-12 h-12 rounded-full bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 shadow-sm">
                  🍎
                </div>
                <span className="text-[10px] font-bold text-gray-600">سوپرمارکت</span>
              </div>
            </div>
          </div>

          {/* Flash Deal section */}
          <div className="mt-6 bg-red-500 p-4 rounded-3xl mx-4 shadow-lg text-white">
            <div className="flex items-center justify-between mb-3">
              <span className="flex items-center gap-1 font-bold text-xs bg-white/20 px-2.5 py-1 rounded-full text-white">
                <Flame className="w-4 h-4 fill-white animate-bounce" />
                شگفت‌انگیز اختصاصی یوزآنلاین
              </span>
              <div className="flex items-center gap-1.5 text-xs text-red-500 font-bold" dir="ltr">
                <span className="bg-white px-1.5 py-0.5 rounded-md min-w-[20px] text-center">
                  {toPersianDigits(timeLeft.seconds.toString().padStart(2, '0'))}
                </span>
                <span className="text-white">:</span>
                <span className="bg-white px-1.5 py-0.5 rounded-md min-w-[20px] text-center">
                  {toPersianDigits(timeLeft.minutes.toString().padStart(2, '0'))}
                </span>
                <span className="text-white">:</span>
                <span className="bg-white px-1.5 py-0.5 rounded-md min-w-[20px] text-center">
                  {toPersianDigits(timeLeft.hours.toString().padStart(2, '0'))}
                </span>
              </div>
            </div>

            <div className="flex gap-3 overflow-x-auto pb-1 scrollbar-none" dir="rtl">
              {products
                .filter((p) => p.discountPercentage !== undefined)
                .map((product) => (
                  <div
                    key={product.id}
                    onClick={() => handleProductCardClick(product)}
                    className="bg-white text-gray-900 rounded-2xl w-36 p-2.5 flex-shrink-0 cursor-pointer shadow-sm hover:scale-[1.02] active:scale-95 transition duration-300"
                  >
                    <div className="relative">
                      <img src={product.image} alt={product.title} className="w-full h-24 object-cover rounded-xl" />
                      <span className="absolute top-1 right-1 bg-[#ff4d4f] text-white text-[9px] font-semibold px-1.5 py-0.5 rounded-full">
                        {toPersianDigits(product.discountPercentage || 0)}٪
                      </span>
                    </div>
                    <h5 className="text-[10px] font-bold text-gray-800 line-clamp-2 mt-2 leading-normal h-8">{product.title}</h5>
                    <div className="mt-1 flex flex-col items-end">
                      {product.originalPrice && (
                        <span className="text-[9px] text-red-400 line-through">
                          {formatPrice(product.originalPrice)}
                        </span>
                      )}
                      <span className="text-xs font-black text-gray-950 flex items-center gap-0.5 self-start">
                        {formatPrice(product.price)} <span className="text-[8px] font-medium text-gray-500">تومان</span>
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </div>

          {/* Dynamic Feed Catalog */}
          <div className="px-4 mt-6">
            <h4 className="text-xs font-black text-gray-800 mb-3 flex items-center justify-between">
              <span>تمامی کالاهای فروشگاه</span>
              <button 
                onClick={() => {
                  setSelectedCategory('ALL');
                  setSearchQuery('');
                  addLog('UI', 'پاک کردن تمامی فیلترها و نمایش همه‌ کالاها', 'Clear filters');
                }}
                className="text-[10px] text-blue-600 font-bold hover:underline"
              >
                پاک‌سازی فیلترها
              </button>
            </h4>

            {filteredProducts.length > 0 ? (
              /* Grid Layout */
              <div className="grid grid-cols-2 gap-3" id="main-catalog-grid">
                {filteredProducts.map((product) => {
                  const isFavorite = favorites.includes(product.id);
                  return (
                    <div
                      key={product.id}
                      className="bg-white border border-gray-100 rounded-2xl p-2.5 flex flex-col justify-between cursor-pointer hover:shadow-md transition duration-300 relative group"
                      onClick={() => handleProductCardClick(product)}
                    >
                      <div>
                        {/* Favorite Button Overlay */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            addLog('UI', 'کلیک روی ضربدر علاقه‌مندی به کالا', `محصول: ${product.title}`);
                            toggleFavorite(product);
                          }}
                          className={`absolute top-2 right-2 w-7 h-7 rounded-lg flex items-center justify-center transition border ${
                            isFavorite
                              ? 'bg-red-50 text-[#ff4d4f] border-red-200'
                              : 'bg-white text-gray-400 border-gray-200 hover:text-red-500'
                          }`}
                        >
                          <HeartIcon className="w-3.5 h-3.5" fill={isFavorite} />
                        </button>

                        <img
                          src={product.image}
                          alt={product.title}
                          className="w-full h-28 object-cover rounded-xl font-sans"
                        />
                        <div className="flex items-center gap-1.5 mt-2.5">
                          <span className="text-[8px] text-blue-600 bg-blue-50 border border-blue-100 font-extrabold px-1.5 py-0.5 rounded">
                            {product.category}
                          </span>
                          <div className="flex items-center gap-0.5 text-[10px] text-amber-500 font-semibold">
                            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                            <span>{toPersianDigits(product.rating.toFixed(1))}</span>
                          </div>
                        </div>
                        <h5 className="text-[10px] font-bold text-gray-800 leading-normal line-clamp-2 mt-2 h-8">
                          {product.title}
                        </h5>
                      </div>

                      <div className="mt-3">
                        <div className="flex items-center justify-between text-[8px] text-gray-400 border-t border-slate-50 pt-2 mb-1.5">
                          <span className="flex items-center gap-0.5 font-medium">
                            <ShieldCheck className="w-3 h-3 text-emerald-500" />
                            {product.vendor.name}
                          </span>
                        </div>
                        <div className="flex items-baseline justify-between">
                          {product.discountPercentage && (
                            <span className="bg-[#ff4d4f] text-white text-[9px] font-black px-1.5 py-0.5 rounded-full">
                              {toPersianDigits(product.discountPercentage)}٪
                            </span>
                          )}
                          <span className="text-xs font-black text-gray-900 flex items-center gap-0.5 mr-auto">
                            {formatPrice(product.price)} <span className="text-[8px] font-bold text-gray-400">تومان</span>
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-10 bg-white rounded-2xl border border-gray-150/50 p-6 shadow-sm">
                <span className="text-3xl block filter saturate-50">🛍️</span>
                <p className="text-xs text-gray-500 mt-3 font-semibold leading-relaxed">هیچ کالایی متناسب با این دسته‌بندی فیلتر شده یافت نشد.</p>
                <button
                  onClick={() => {
                    setSelectedCategory('ALL');
                    addLog('UI', 'بازنشانی فیلتر دسته‌بندی', 'Reset category filter to ALL');
                  }}
                  className="mt-3.5 px-4 py-1.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-600 font-bold text-[10px] rounded-xl active:scale-95 transition"
                >
                  نمایش همه محصولات
                </button>
              </div>
            )}
          </div>
        </>
      ) : (
        /* Render Search Results */
        <div className="px-4 mt-4">
          <h4 className="text-xs font-bold text-gray-800 mb-4">
            نتایج جستجو برای: <span className="text-blue-600">«{searchQuery}»</span> ({toPersianDigits(filteredProducts.length)} مورد)
          </h4>

          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-2 gap-3">
              {filteredProducts.map((product) => {
                const isFavorite = favorites.includes(product.id);
                return (
                  <div
                    key={product.id}
                    className="bg-white border border-gray-100 rounded-2xl p-2.5 flex flex-col justify-between cursor-pointer hover:shadow-md transition duration-300 relative"
                    onClick={() => handleProductCardClick(product)}
                  >
                    <div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(product);
                        }}
                        className={`absolute top-2 right-2 w-7 h-7 rounded-lg flex items-center justify-center transition border ${
                          isFavorite
                            ? 'bg-red-50 text-[#ff4d4f] border-red-200'
                            : 'bg-white text-gray-400 border-gray-200 hover:text-red-500'
                        }`}
                      >
                        <HeartIcon className="w-3.5 h-3.5" fill={isFavorite} />
                      </button>
                      <img src={product.image} alt={product.title} className="w-full h-28 object-cover rounded-xl" />
                      <span className="text-[8px] text-blue-600 bg-blue-50 font-bold px-1.5 py-0.5 rounded mt-2 inline-block">{product.category}</span>
                      <h5 className="text-[10px] font-bold text-gray-800 line-clamp-2 mt-1.5 h-8 leading-snug">{product.title}</h5>
                    </div>
                    <div className="mt-2 text-left">
                      <span className="text-xs font-black text-gray-950 block">
                        {formatPrice(product.price)} تومان
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-10">
              <span className="text-3xl">🔍</span>
              <p className="text-xs text-gray-500 mt-2 font-medium">هیچ محصولی با عنوان جستجو شده یافت نشد.</p>
            </div>
          )}
        </div>
      )}

      {/* Full screen Chat overlay for Customer Shopping Assistant */}
      {isAiAssistantOpen && (
        <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-sm z-50 flex flex-col justify-end animate-fade-in" id="mobile-ai-assistant-modal">
          <div className="bg-white rounded-t-[2.5rem] h-[85%] flex flex-col overflow-hidden relative shadow-2xl p-4">
            
            {/* Header notch */}
            <div className="w-10 h-1 bg-gray-200 rounded-full mx-auto mb-2 shrink-0" />

            {/* Header details */}
            <div className="flex items-center justify-between border-b border-gray-100 pb-3 mb-3 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md shadow-blue-500/20 shrink-0">
                  <Sparkles className="w-4.5 h-4.5 animate-pulse" />
                </div>
                <div className="text-right">
                  <h4 className="text-xs font-black text-gray-950">دستیار خرید الیار یوزآنلاین</h4>
                  <span className="text-[8px] text-emerald-600 font-bold block mt-0.5">فعال - متصل به Gemini 3.5</span>
                </div>
              </div>
              
              <button
                onClick={() => setIsAiAssistantOpen(false)}
                className="w-8 h-8 bg-slate-100 text-gray-400 hover:text-gray-700 rounded-full flex items-center justify-center transition shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Farsi Chat lists flow */}
            <div className="flex-1 overflow-y-auto space-y-3 p-1 flex flex-col scrollbar-thin">
              {clientChatMessages.map((m, idx) => (
                <div 
                  key={idx}
                  className={`max-w-[85%] text-[10px] leading-relaxed p-2.5 rounded-2xl ${
                    m.role === 'user'
                      ? 'bg-blue-600 text-white self-start rounded-tr-none text-right shadow-sm shadow-blue-500/10'
                      : 'bg-slate-100 text-gray-800 self-end rounded-tl-none text-right border border-slate-150'
                  }`}
                >
                  <div className="whitespace-pre-wrap font-medium">{m.text}</div>
                </div>
              ))}
              {isClientChatLoading && (
                <div className="self-end bg-slate-100 text-slate-400 text-[9px] px-3 py-2 rounded-2xl rounded-tl-none flex items-center gap-1 shrink-0 border border-slate-150">
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce" />
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce delay-100" />
                  <span className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-bounce delay-200" />
                </div>
              )}
            </div>

            {/* Assistant Quick Suggestions pills */}
            <div className="flex gap-1.5 overflow-x-auto py-2 border-t border-gray-100 scrollbar-none shrink-0" dir="rtl">
              {[
                'S24 Ultra چه مشخصاتی دارد؟',
                'پیشنهاد بر اساس بودجه ۵ میلیونی',
                'درباره قهوه‌ساز نوا ۱۴۹ اطلاعات بده',
              ].map((suggest) => (
                <button
                  key={suggest}
                  onClick={() => setClientChatInput(suggest)}
                  className="text-[8px] font-black bg-slate-50 text-slate-600 border border-slate-200 px-2.5 py-1.5 rounded-xl shrink-0 hover:bg-slate-100 active:scale-95 transition"
                >
                  {suggest}
                </button>
              ))}
            </div>

            {/* Farsi Chat Input form */}
            <form onSubmit={handleClientChatSubmit} className="flex gap-2 border-t border-gray-100 pt-3 shrink-0">
              <input
                type="text"
                placeholder="اینجا کلامی تایپ کنید..."
                value={clientChatInput}
                onChange={(e) => setClientChatInput(e.target.value)}
                className="flex-1 bg-slate-100 border-none rounded-2xl px-4 py-2.5 text-[10px] text-right focus:outline-none focus:ring-1 focus:ring-blue-500 placeholder:text-gray-400"
              />
              <button
                type="submit"
                disabled={isClientChatLoading}
                className="bg-blue-600 hover:bg-blue-700 text-white rounded-2xl px-4 py-2.5 transition active:scale-95 flex items-center justify-center shrink-0 shadow-md shadow-blue-500/10"
              >
                <Send className="w-3.5 h-3.5 rotate-180" />
              </button>
            </form>

          </div>
        </div>
      )}
    </div>
  );
}

// Simple internal icon helper represent Solid Heart vs Outline Heart
function HeartIcon({ className, fill }: { className?: string; fill?: boolean }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill={fill ? 'currentColor' : 'none'}
      stroke="currentColor"
      strokeWidth="2.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
    </svg>
  );
}
