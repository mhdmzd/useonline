import React, { useState } from 'react';
import { ShoppingBasket, Trash2, Plus, Minus, Ticket, CreditCard, ChevronRight, Check } from 'lucide-react';
import { CartItem, ArchLog } from '../../types';

interface CartTabProps {
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onClear: () => void;
  onCheckout: (discountApplied: number) => void;
  addLog: (layer: ArchLog['layer'], message: string, details: string) => void;
}

export function CartTab({
  cartItems,
  onUpdateQuantity,
  onClear,
  onCheckout,
  addLog,
}: CartTabProps) {
  const [coupon, setCoupon] = useState('');
  const [discountPercent, setDiscountPercent] = useState(0);
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState('');

  const toPersianDigits = (num: number | string) => {
    const id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/[0-9]/g, (w) => id[+w]);
  };

  const formatPrice = (price: number) => {
    const formatted = price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return toPersianDigits(formatted);
  };

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    setCouponSuccess('');
    
    addLog('UI', 'درخواست ثبت کد تخفیف در فیلد متریال', `کد: ${coupon}`);

    if (coupon.toUpperCase() === 'USEONLINE' || coupon.toUpperCase() === 'ATLINE') {
      addLog('VIEWMODEL', 'محاسبه درصد تخفیف کد معتبر در CartViewModel', 'ثبت ۱۰ درصد تخفیف عمومی');
      setDiscountPercent(10);
      setCouponSuccess('کد تخفیف یوزآنلاین با موفقیت اعمال شد (۱۰٪ تخفیف)');
    } else if (coupon.toUpperCase() === 'OFF50') {
      addLog('VIEWMODEL', 'محاسبه درصد تخفیف کد معتبر در CartViewModel', 'ثبت ۵۰ درصد تخفیف روی کل سبد');
      setDiscountPercent(50);
      setCouponSuccess('تخفیف شگفت‌انگیز افتتاحیه با موفقیت اعمال شد (۵۰٪ تخفیف!)');
    } else {
      addLog('REPOSITORY', 'ارزیابی کد تخفیف فاقد اعتبار در دیتا سورس', 'خطای کد نامعتبر');
      setCouponError('کد تخفیف معتبر نیست! (کدهای تست: USEONLINE یا OFF50)');
    }
  };

  const rawSubtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discountAmount = Math.round((rawSubtotal * discountPercent) / 100);
  const shippingFee = rawSubtotal > 15000000 || rawSubtotal === 0 ? 0 : 49000;
  const grandTotal = rawSubtotal - discountAmount + shippingFee;

  const handleCheckoutClick = () => {
    if (cartItems.length === 0) return;
    
    addLog('UI', 'دکمه تسویه حساب و ثبت سفارش فشرده شد', `مبلغ کل: ${grandTotal} تومان`);
    addLog('VIEWMODEL', 'ثبت تراکنش در OrderViewModel', 'آماده‌سازی مدل سفارش خرید');
    addLog('USECASE', 'فراخوانی PlaceOrderUseCase', 'ارسال مدل سفارش به گیت‌های کنترل دامنه');
    addLog('REPOSITORY', 'احضار متد OrderRepository.saveOrder()', 'ثبت سفارش در صف همگام‌سازی ابری');
    
    onCheckout(discountPercent);
  };

  return (
    <div className="flex flex-col bg-slate-50 h-full pb-20 font-vazir text-right" dir="rtl" id="cart-tab-scroller">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-white shadow-sm px-4 py-3 flex items-center justify-between">
        <h2 className="text-sm font-black text-gray-950 flex items-center gap-1.5">
          <ShoppingBasket className="w-4 h-4 text-blue-600" />
          سبد خرید یوزآنلاین
        </h2>
        {cartItems.length > 0 && (
          <button
            onClick={() => {
              addLog('UI', 'پاکسازی کل سبد خرید و تخلیه سشن', 'درخواست تخلیه');
              onClear();
            }}
            className="flex items-center gap-1 text-red-500 text-[10px] font-bold p-1 hover:bg-red-50 rounded"
          >
            <Trash2 className="w-3.5 h-3.5" />
            خالی کردن سبد
          </button>
        )}
      </div>

      {cartItems.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center p-8 text-center" id="empty-cart-state">
          <span className="text-5xl mb-4 animate-pulse">🛒</span>
          <h3 className="text-xs font-bold text-gray-900">سبد خرید شما در حال حاضر خالی است</h3>
          <p className="text-[10px] text-gray-400 mt-1 max-w-xs leading-normal">
            می‌توانید به صفحات خانه یا دسته‌بندی‌ها رفته و محصولات موردعلاقه‌تان را به سبد خرید اضافه کنید.
          </p>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-3">
          {/* Cart Products List */}
          <div className="flex flex-col gap-2.5">
            {cartItems.map((item) => (
              <div
                key={item.product.id}
                className="bg-white border border-gray-100 rounded-2xl p-3 flex gap-3 shadow-sm hover:shadow transition"
              >
                <img src={item.product.image} alt={item.product.title} className="w-16 h-16 object-cover rounded-xl shrink-0" />
                
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="text-[10px] font-black text-gray-800 line-clamp-1 leading-snug">{item.product.title}</h4>
                    <span className="text-[8px] text-gray-400 font-semibold block mt-0.5">فروشنده: {item.product.vendor.name}</span>
                  </div>

                  <div className="flex items-center justify-between mt-1">
                    {/* Size and price stats */}
                    <span className="text-xs font-black text-blue-600">
                      {formatPrice(item.product.price)} <span className="text-[8px] text-gray-400">تومان</span>
                    </span>

                    {/* Quantity Selector buttons */}
                    <div className="flex items-center border border-gray-100 bg-slate-50 rounded-lg py-0.5 px-1 gap-2">
                      <button
                        onClick={() => {
                          addLog('UI', 'افزودن تعداد کالا در سبد خرید', `محصول: ${item.product.title}`);
                          onUpdateQuantity(item.product.id, 1);
                        }}
                        className="p-1 hover:text-blue-600 active:scale-90"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold text-gray-800 w-3.5 text-center">
                        {toPersianDigits(item.quantity)}
                      </span>
                      <button
                        onClick={() => {
                          addLog('UI', 'کاهش تعداد کالا در سبد خرید', `محصول: ${item.product.title}`);
                          onUpdateQuantity(item.product.id, -1);
                        }}
                        className="p-1 hover:text-[#ff4d4f] active:scale-90"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Coupon discount input form */}
          <div className="bg-white border border-gray-100 rounded-2xl p-3 shadow-sm mt-2">
            <h4 className="text-[10px] font-black text-gray-800 mb-2.5 flex items-center gap-1">
              <Ticket className="w-3.5 h-3.5 text-amber-500" />
              کد تخفیف داری؟
            </h4>
            <form onSubmit={handleApplyCoupon} className="flex gap-2">
              <input
                type="text"
                placeholder="کد تخفیف (مثال: USEONLINE)"
                value={coupon}
                onChange={(e) => setCoupon(e.target.value)}
                className="flex-1 bg-slate-50 border border-slate-100 pr-3 py-2 rounded-xl text-xs focus:outline-none focus:border-amber-500 uppercase font-bold text-center tracking-widest text-right"
              />
              <button
                type="submit"
                className="bg-amber-500 hover:bg-amber-600 text-white font-bold px-4 py-2 rounded-xl text-xs active:scale-95 transition"
              >
                اعمال
              </button>
            </form>
            {couponError && <p className="text-[9px] text-[#ff4d4f] font-semibold mt-1.5">{couponError}</p>}
            {couponSuccess && (
              <p className="text-[9px] text-emerald-600 font-semibold mt-1.5 flex items-center gap-0.5">
                <Check className="w-3 h-3" />
                {couponSuccess}
              </p>
            )}
          </div>

          {/* Checkout Details invoice card */}
          <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm mt-1 flex flex-col gap-2.5">
            <h4 className="text-[10px] font-black text-gray-800 border-b border-gray-100 pb-2 mb-1 flex items-center gap-1.5">
              <CreditCard className="w-4 h-4 text-emerald-500" />
              فاکتور تسویه حساب
            </h4>
            
            <div className="flex justify-between text-xs text-gray-500">
              <span>قیمت کالاها ({toPersianDigits(cartItems.length)})</span>
              <span className="font-semibold text-gray-800">{formatPrice(rawSubtotal)} تومان</span>
            </div>

            {discountPercent > 0 && (
              <div className="flex justify-between text-xs text-[#ff4d4f] font-semibold">
                <span>تخفیف کدهای کوپن اعمال‌شده ({toPersianDigits(discountPercent)}٪)</span>
                <span>{formatPrice(discountAmount)}- تومان</span>
              </div>
            )}

            <div className="flex justify-between text-xs text-gray-500">
              <span>هزینه ارسال مرسوله اختصاصی یوزآنلاین</span>
              <span className="font-semibold text-gray-800">
                {shippingFee === 0 ? 'رایگان (خریدهای بالای ۱۵ میلیون)' : `${formatPrice(shippingFee)} تومان`}
              </span>
            </div>

            <div className="flex justify-between items-center text-sm font-black border-t border-gray-100 pt-3 mt-2.5">
              <span className="text-gray-950">مبلغ نهایی پرداخت</span>
              <span className="text-blue-600 text-base">{formatPrice(grandTotal)} تومان</span>
            </div>

            <button
              onClick={handleCheckoutClick}
              className="w-full mt-2 py-3 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow-md shadow-blue-100 active:scale-[0.97] transition"
            >
              تکمیل خرید و ثبت سفارش یوزآنلاین
              <ChevronRight className="w-4 h-4 scale-x-[-1]" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
