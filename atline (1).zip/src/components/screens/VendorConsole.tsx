import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Store, 
  Package, 
  TrendingUp, 
  DollarSign, 
  CheckCircle, 
  AlertCircle, 
  PlusCircle, 
  Edit,
  ArrowLeft, 
  ArrowRight, 
  Check, 
  Clipboard, 
  Image as ImageIcon, 
  Layers, 
  Sliders, 
  ShieldCheck, 
  Trash2,
  FileSpreadsheet,
  RefreshCw,
  Award,
  MessageSquare,
  Wallet,
  Settings,
  User,
  MapPin,
  Phone,
  CreditCard,
  Bell,
  Send,
  Clock
} from 'lucide-react';
import { Product, Category, ArchLog, Order, VendorShop, NotificationItem } from '../../types';

// Preselected high-quality Unsplash image presets to make uploaded items look gorgeous
const PRODUCT_IMAGE_PRESETS: { [category: string]: Array<{ label: string; url: string }> } = {
  'phones': [
    { label: 'گوشی موبایل پیکسل ۸ پرو', url: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=500&auto=format&fit=crop&q=80' },
    { label: 'آیفون ۱۵ پرو تیتانیوم', url: 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=500&auto=format&fit=crop&q=80' }
  ],
  'laptops': [
    { label: 'لپ‌تاپ مک‌بوک پرو ام۳', url: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=500&auto=format&fit=crop&q=80' },
    { label: 'سرفیس بوک مایکروسافت', url: 'https://images.unsplash.com/photo-1585776245991-cf89dd7fc73a?w=500&auto=format&fit=crop&q=80' }
  ],
  'audio': [
    { label: 'هدفون مانیتورینگ سونی', url: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=500&auto=format&fit=crop&q=80' },
    { label: 'اسپیکر قابل حمل جی‌بی‌ال', url: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=500&auto=format&fit=crop&q=80' }
  ],
  'shoes': [
    { label: 'کتانی ورزشی هوکا ادونچر', url: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&auto=format&fit=crop&q=80' },
    { label: 'کفش پیاده‌روی ریباک کلاسیک', url: 'https://images.unsplash.com/photo-1539185441755-769473a23570?w=500&auto=format&fit=crop&q=80' }
  ],
  'kitchen': [
    { label: 'قهوه‌ساز خانگی دلونگی اسپرسو', url: 'https://images.unsplash.com/photo-1517256064527-09c53b2d0bc6?w=500&auto=format&fit=crop&q=80' },
    { label: 'کتری برقی استنلی فولادی', url: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?w=500&auto=format&fit=crop&q=80' }
  ],
  'perfume': [
    { label: 'عطر زنانه کوکو شنل پرفیوم', url: 'https://images.unsplash.com/photo-1588405748373-122b2321bc31?w=500&auto=format&fit=crop&q=80' },
    { label: 'ادکلن دیور ساواج خنک', url: 'https://images.unsplash.com/photo-1523293182086-7651a899d37f?w=500&auto=format&fit=crop&q=80' }
  ],
  'default': [
    { label: 'کالای سفارشی شیک', url: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&auto=format&fit=crop&q=80' }
  ]
};

const LOGO_COLLECTION = [
  { char: '👑', label: 'رویال' },
  { char: '📱', label: 'دیجیتال' },
  { char: '👗', label: 'پوشاک' },
  { char: '☕', label: 'کافه' },
  { char: '📦', label: 'لوجستیک' },
  { char: '☘️', label: 'ارگانیک' },
];

interface VendorOrder {
  id: string;
  user: string;
  avatar: string;
  productTitle: string;
  productImg: string;
  quantity: number;
  price: number;
  date: string;
  status: 'PENDING' | 'PREPARING' | 'SHIPPED' | 'DELIVERED';
}

interface CustomerMessage {
  id: string;
  senderName: string;
  senderAvatar: string;
  lastMessage: string;
  time: string;
  unreadCount: number;
  chatHistory: Array<{
    sender: 'CUSTOMER' | 'VENDOR';
    text: string;
    time: string;
  }>;
}

interface WithdrawRequest {
  id: string;
  amount: number;
  date: string;
  shaba: string;
  status: 'PENDING' | 'PAID' | 'REJECTED';
}

interface VendorNotification {
  id: string;
  title: string;
  body: string;
  time: string;
  type: 'ORDER' | 'SYSTEM' | 'WALLET';
  isRead: boolean;
}

interface VendorConsoleProps {
  onBackToBuyer: () => void;
  products: Product[];
  onAddProduct: (p: Product) => void;
  onEditProduct: (p: Product) => void;
  onDeleteProduct: (id: string) => void;
  addLog: (layer: ArchLog['layer'], message: string, details: string) => void;
  shop: VendorShop | null;
  onRegisterShop: (shop: VendorShop) => void;
  onUpdateShop?: (shop: VendorShop) => void;
  categories: Category[];
}

export function VendorConsole({
  onBackToBuyer,
  products,
  onAddProduct,
  onEditProduct,
  onDeleteProduct,
  addLog,
  shop,
  onRegisterShop,
  onUpdateShop,
  categories = [],
}: VendorConsoleProps) {
  // Navigation sidebar tab state - 0: Dashboard, 1: Products & Variants, 2: Orders Queue, 3: CRM Chats, 4: Wallet & Withdraw, 5: Shop Profile & Logo
  const [activeTab, setActiveTabInner] = useState(0);

  // Registration Form credentials
  const [regName, setRegName] = useState('');
  const [regCategory, setRegCategory] = useState('digital');
  const [regDesc, setRegDesc] = useState('');
  const [regLogo, setRegLogo] = useState('👑');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regAddress, setRegAddress] = useState('');
  const [regShaba, setRegShaba] = useState('');
  const [regError, setRegError] = useState('');

  // Editing Profile states
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [profName, setProfName] = useState('');
  const [profDesc, setProfDesc] = useState('');
  const [profPhone, setProfPhone] = useState('');
  const [profEmail, setProfEmail] = useState('');
  const [profAddress, setProfAddress] = useState('');
  const [profShaba, setProfShaba] = useState('');
  const [profLogo, setProfLogo] = useState('');
  const [profBanner, setProfBanner] = useState('');

  // Form states for Product Upload with variant values
  const [prodTitle, setProdTitle] = useState('');
  const [prodEngTitle, setProdEngTitle] = useState('');
  const [prodCategory, setProdCategory] = useState('phones');
  const [prodPrice, setProdPrice] = useState('');
  const [prodImgType, setProdImgType] = useState('preset'); // 'preset' | 'custom'
  const [prodPresetImg, setProdPresetImg] = useState('');
  const [prodCustomImg, setProdCustomImg] = useState('');
  const [prodDesc, setProdDesc] = useState('');
  
  // Dynamic Product Variants states
  const [tempVariantName, setTempVariantName] = useState('');
  const [tempVariantVal, setTempVariantVal] = useState('');
  const [variantsList, setVariantsList] = useState<Array<{ name: string; value: string }>>([
    { name: 'گارانتی', value: '۱۸ ماهه شرکتی هماهنگ' },
    { name: 'رنگ', value: 'مشکی خاکستری' }
  ]);

  // Product edit modal controller
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editEngTitle, setEditEngTitle] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editPrice, setEditPrice] = useState('');
  const [editStock, setEditStock] = useState<number>(10);
  const [editImgUrl, setEditImgUrl] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [editVariants, setEditVariants] = useState<Array<{ name: string; value: string }>>([]);
  const [editVarKey, setEditVarKey] = useState('');
  const [editVarVal, setEditVarVal] = useState('');
  const [editError, setEditError] = useState('');

  // CRM Chat Simulation local datastore
  const [chatThreads, setChatThreads] = useState<CustomerMessage[]>([
    {
      id: 'chat_1',
      senderName: 'سینا خلیلی',
      senderAvatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100',
      lastMessage: 'درود، من تبلت خریدم کی به دستم می‌رسه؟',
      time: '۱۰ دقیقه پیش',
      unreadCount: 1,
      chatHistory: [
        { sender: 'CUSTOMER', text: 'سلام و خسته نباشید غرفه‌دار محترم', time: 'امروز، ۱۰:۰۰' },
        { sender: 'VENDOR', text: 'سلام، روز بخیر همکار گرامی. در خدمتیم.', time: 'امروز، ۱۰:۰۲' },
        { sender: 'CUSTOMER', text: 'من تبلت خریدم کی به دستم می‌رسه؟ هزینه ارسال چقدره؟', time: 'امروز، ۱۰:۰۵' }
      ]
    },
    {
      id: 'chat_2',
      senderName: 'مرجان صفری',
      senderAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100',
      lastMessage: 'کیفیت ساخت کالا چطوره؟ بدنه پلاستیکی هست؟',
      time: 'دیروز',
      unreadCount: 0,
      chatHistory: [
        { sender: 'CUSTOMER', text: 'سلام خسته نباشید. عذر میخوام ساعت Redmi Watch 4 بدنه فلزی داره یا پلاستیکی؟', time: 'دیروز، ۱۵:۱0' },
        { sender: 'VENDOR', text: 'سلام خدمت شما خانم صفری. فریم دور ساعت آلومینیومی هست و پشتش پلاستیک فشرده مرغوب.', time: 'دیروز، ۱۵:۱۵' },
        { sender: 'CUSTOMER', text: 'بسیار عالی. ممنون از پاسخگویی سریع شما.', time: 'دیروز، ۱۵:۱۸' }
      ]
    },
    {
      id: 'chat_3',
      senderName: 'رضا کرمی',
      senderAvatar: 'https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=100',
      lastMessage: 'خیلی تشکر کالا عالی بود و سریع رسید.',
      time: '۳ روز پیش',
      unreadCount: 0,
      chatHistory: [
        { sender: 'VENDOR', text: 'سلام جناب کرمی، سفارش شما ارسال شد و طبق کد رهگیری تحویل شد.', time: '۳ روز پیش، ۱۲:۰۰' },
        { sender: 'CUSTOMER', text: 'بله دستم رسید. خیلی تشکر کالا عالی بود و سریع رسید.', time: '۳ روز پیش، ۱۲:۳۰' }
      ]
    }
  ]);
  const [activeChatId, setActiveChatId] = useState('chat_1');
  const [typedMessage, setTypedMessage] = useState('');

  // Wallets, Withdraw and payout flows
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawError, setWithdrawError] = useState('');
  const [withdrawSuccess, setWithdrawSuccess] = useState('');
  const [withdrawRequests, setWithdrawRequests] = useState<WithdrawRequest[]>([
    { id: 'pay_101', amount: 3500000, date: '۱۴۰۵/۰۳/۱' , shaba: 'IR890120000000012345678901', status: 'PAID' },
    { id: 'pay_102', amount: 5000000, date: '۱۴۰۵/۰۳/۱۲', shaba: 'IR890120000000012345678901', status: 'PENDING' }
  ]);

  // Private notification states
  const [notifications, setNotifications] = useState<VendorNotification[]>([
    { id: 'vn_1', title: 'سفارش جدید دریافتی 🛒', body: 'مشتری "سینا خلیلی" یک عدد گوشی سامسونگ ثبت کرد.', time: '۱۰ دقیقه پیش', type: 'ORDER', isRead: false },
    { id: 'vn_2', title: 'تایید هویت غرفه 🏅', body: 'تضمین صلاحیت فروشگاهی با موفقیت احراز گردید.', time: 'امروز، ۰۹:۰۰', type: 'SYSTEM', isRead: true },
    { id: 'vn_3', title: 'تراکنش موفق کیف پول 💳', body: 'تسویه حساب مبلغ ۳,۵۰۰,۰۰۰ تومان به شماره شبا واریز شد.', time: 'دیروز، ۱۸:۳۰', type: 'WALLET', isRead: true },
  ]);

  // Seeding vendor orders state with persistent simulated orders
  const [vendorOrders, setVendorOrders] = useState<VendorOrder[]>([
    {
      id: 'VO-2901',
      user: 'سینا خلیلی',
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100',
      productTitle: 'گوشی موبایل سامسونگ گلکسی S24 Ultra دو سیم‌کارت',
      productImg: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=100',
      quantity: 1,
      price: 68900000,
      date: 'امروز، ۱۰:۴۲',
      status: 'PENDING'
    },
    {
      id: 'VO-1823',
      user: 'مرجان صفری',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100',
      productTitle: 'ساعت هوشمند شیائومی مدل Redmi Watch 4',
      productImg: 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=100',
      quantity: 2,
      price: 4350000,
      date: 'دیروز، ۱۵:۲۰',
      status: 'SHIPPED'
    }
  ]);

  // Helper values to localize digits
  const toPersianDigits = (num: number | string) => {
    const id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/[0-9]/g, (w) => id[+w]);
  };

  const formatPrice = (price: number) => {
    const formatted = price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return toPersianDigits(formatted);
  };

  // Populate info on mount of edit mode
  useEffect(() => {
    if (shop) {
      setProfName(shop.name);
      setProfDesc(shop.description);
      setProfPhone(shop.phone || '09121112222');
      setProfEmail(shop.email || 'seller@useonline.shop');
      setProfAddress(shop.address || 'تهران، خیابان شریعتی، مجتمع یوزآنلاین');
      setProfShaba(shop.shaba || 'IR890120000000012345678901');
      setProfLogo(shop.logo || '👑');
      setProfBanner(shop.bannerColor || 'from-[#059669] to-[#10b981]');
    }
  }, [shop]);

  // Initialize and check current status
  const isShopApproved = shop && shop.status === 'APPROVED';
  const isShopPending = shop && shop.status === 'PENDING_APPROVAL';
  const isShopRejected = shop && shop.status === 'REJECTED';

  // Overriding ActiveTab when shop is not approved
  const setActiveTab = (tabIdx: number) => {
    if (!isShopApproved && tabIdx !== 0) {
      // Unverified shop cannot browse other tabs than dashboard/verification
      return;
    }
    setActiveTabInner(tabIdx);
  };

  // 1. Core Actions - Submit Registration
  const handleRegisterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRegError('');

    if (!regName.trim() || !regDesc.trim() || !regPhone.trim() || !regShaba.trim()) {
      setRegError('لطفاً اطلاعات اصلی و فیلدهای ستاره‌دار را با دقت تکمیل کنید.');
      return;
    }

    if (!regShaba.toUpperCase().startsWith('IR') || regShaba.length < 10) {
      setRegError('شماره شبا بانک ملی یا عضو شتاب باید با IR شروع شود و معتبر باشد.');
      return;
    }

    addLog('UI', 'دکمه درخواست ثبت‌نام آنلاین غرفه کلیک شد', `نام برند: ${regName}`);
    addLog('VIEWMODEL', 'تولید آبجکت غرفه جدید با وضعیت تعلیق ادمین', 'RegisterVendorViewModel');
    addLog('USECASE', 'درخواست احراز صلاحیت (Onload Registration) فرستاده شد', regName);

    const newShop: VendorShop = {
      name: regName.trim(),
      category: regCategory,
      description: regDesc.trim(),
      logo: regLogo,
      rating: 5.0,
      balance: 15450000, // starting balance (mock sales)
      ordersCount: 2,
      status: 'PENDING_APPROVAL',
      phone: regPhone.trim(),
      email: regEmail.trim() || 'me@useonline.shop',
      address: regAddress.trim() || 'تهران، ایران',
      shaba: regShaba.trim().toUpperCase(),
      joinedDate: '۱۴۰۵/۰۳/۱۷',
      bannerColor: 'from-[#0d9488] to-[#14b8a6]'
    };

    onRegisterShop(newShop);
    
    // Add inside notifications
    setNotifications(prev => [
      {
        id: `vn_${Date.now()}`,
        title: '⏳ پرونده احراز غرفه فرستاده شد',
        body: `درخواست راه‌اندازی برند "${regName}" هم‌اینک وارد چرخه پردازش ادمین شد. برای ارزیابی سریع در تب مدیریت ادمین بپذیرید.`,
        time: 'هم‌اکنون',
        type: 'SYSTEM',
        isRead: false
      },
      ...prev
    ]);
  };

  // Profile update submission
  const handleProfileSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!shop || !onUpdateShop) return;

    const updated: VendorShop = {
      ...shop,
      name: profName,
      description: profDesc,
      phone: profPhone,
      email: profEmail,
      address: profAddress,
      shaba: profShaba,
      logo: profLogo,
      bannerColor: profBanner
    };

    onUpdateShop(updated);
    setIsEditingProfile(false);
    addLog('REPOSITORY', 'پروفایل غرفه با موفقیت تصحیح گردید', profName);
  };

  // New product addition with dynamic specs/variants
  const handleProductSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodTitle.trim() || !prodPrice.trim() || !prodDesc.trim()) {
      addLog('UI', 'فیلد ناقص در بارگذاری محصول', 'کابین بارگذاری');
      return;
    }

    const priceNum = parseInt(prodPrice.replace(/[^0-9]/g, ''), 10);
    if (isNaN(priceNum) || priceNum <= 0) {
      addLog('UI', 'خطای مقدار عددی قیمت', 'کاتالوگ');
      return;
    }

    // Resolve image
    let finalImg = 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&auto=format&fit=crop&q=80';
    if (prodImgType === 'preset' && prodPresetImg) {
      finalImg = prodPresetImg;
    } else if (prodImgType === 'custom' && prodCustomImg.trim()) {
      finalImg = prodCustomImg.trim();
    } else {
      const catPresets = PRODUCT_IMAGE_PRESETS[prodCategory] || PRODUCT_IMAGE_PRESETS['default'];
      finalImg = catPresets[0].url;
    }

    // Adapt variants to specification object
    const specMap: { [key: string]: string } = {};
    variantsList.forEach(v => {
      if (v.name.trim() && v.value.trim()) {
        specMap[v.name.trim()] = v.value.trim();
      }
    });

    const categoryObj = categories.find(c => 
      c.subcategories.some(sc => sc.id === prodCategory)
    );
    const categoryName = categoryObj ? categoryObj.name : 'کالای دیجیتال';

    const newProduct: Product = {
      id: `p_v_${Date.now()}`,
      title: prodTitle.trim(),
      englishTitle: prodEngTitle.trim() || 'Custom Variant Item',
      price: priceNum,
      image: finalImg,
      category: categoryName,
      categoryId: prodCategory,
      rating: 5.0,
      reviewsCount: 0,
      stock: 15,
      vendor: {
        name: shop?.name || 'فروشگاه شما',
        rating: 5.0,
        logo: shop?.logo || '👑'
      },
      description: prodDesc.trim(),
      specifications: specMap
    };

    onAddProduct(newProduct);
    
    // Reset states
    setProdTitle('');
    setProdEngTitle('');
    setProdPrice('');
    setProdPresetImg('');
    setProdCustomImg('');
    setProdDesc('');
    setVariantsList([
      { name: 'گارانتی', value: '۱۸ ماهه شرکتی هماهنگ' },
      { name: 'رنگ', value: 'مشکی خاکستری' }
    ]);

    // Redirect to Products catalog tab
    setActiveTab(1);

    addLog('REPOSITORY', 'همگام‌سازی و درج کالا در کاتالوگ فروشگاه', newProduct.title);
  };

  // Open Edit Product dialog
  const handleOpenEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setEditTitle(prod.title);
    setEditEngTitle(prod.englishTitle || '');
    setEditCategory(prod.categoryId || 'phones');
    setEditPrice(prod.price.toString());
    setEditStock(prod.stock !== undefined ? prod.stock : 10);
    setEditImgUrl(prod.image);
    setEditDesc(prod.description || '');

    const varArr: Array<{ name: string; value: string }> = [];
    if (prod.specifications) {
      Object.entries(prod.specifications).forEach(([k, v]) => {
        varArr.push({ name: k, value: v });
      });
    }
    setEditVariants(varArr);
    setEditError('');
  };

  // Save edited product records
  const handleSaveEditedProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editTitle.trim() || !editPrice.trim()) {
      setEditError('لطفاً عنوان و قیمت کالا را پر کنید.');
      return;
    }

    const priceNum = parseInt(editPrice.replace(/[^\d]/g, ''), 10);
    if (isNaN(priceNum) || priceNum <= 0) {
      setEditError('قیمت نامعتبر است.');
      return;
    }

    const specObj: { [key: string]: string } = {};
    editVariants.forEach(v => {
      if (v.name.trim() && v.value.trim()) {
        specObj[v.name.trim()] = v.value.trim();
      }
    });

    if (editingProduct) {
      const updated: Product = {
        ...editingProduct,
        title: editTitle.trim(),
        englishTitle: editEngTitle.trim(),
        price: priceNum,
        stock: editStock,
        image: editImgUrl.trim(),
        description: editDesc.trim(),
        specifications: specObj
      };
      onEditProduct(updated);
      setEditingProduct(null);
      addLog('REPOSITORY', 'اصلاح پرونده مشخصات کالا در دیتابیس کاتالوگ', updated.title);
    }
  };

  // Update Stock Directly
  const handleUpdateStockDirectly = (prod: Product, newStock: number) => {
    if (newStock < 0) return;
    const updated: Product = {
      ...prod,
      stock: newStock
    };
    onEditProduct(updated);
    addLog('REPOSITORY', `تغییر سریع موجودی کالا: ${prod.title}`, `قبلی: ${prod.stock} -> جدید: ${newStock}`);
  };

  // Order workflow triggers
  const handleUpdateStatus = (orderId: string, newStatus: VendorOrder['status']) => {
    setVendorOrders(prev => prev.map(o => 
      o.id === orderId ? { ...o, status: newStatus } : o
    ));

    addLog('UI', `تغییر وضعیت فاکتور به ${newStatus}`, `سفارش: ${orderId}`);

    setNotifications(prev => [
      {
        id: `vn_${Date.now()}`,
        title: '📦 به‌روزرسانی فاکتور سفارش',
        body: `وضعیت سفارش "${orderId}" به "${newStatus === 'PREPARING' ? 'در حال آماده‌سازی' : newStatus === 'SHIPPED' ? 'ارسال شده' : 'تحویل موفق'}" تغییر یافت.`,
        time: 'هم‌اکنون',
        type: 'ORDER',
        isRead: false
      },
      ...prev
    ]);
  };

  // Send interactive CRM message
  const handleSendMessage = () => {
    if (!typedMessage.trim()) return;

    setChatThreads(prev => prev.map(t => {
      if (t.id === activeChatId) {
        return {
          ...t,
          lastMessage: typedMessage.trim(),
          time: 'هم‌اکنون',
          unreadCount: 0,
          chatHistory: [
            ...t.chatHistory,
            { sender: 'VENDOR', text: typedMessage.trim(), time: 'امروز، ' + new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) }
          ]
        };
      }
      return t;
    }));

    addLog('UI', 'پاسخ مستقیم مرچنت به ارتباط با خریدار', typedMessage);
    setTypedMessage('');

    // Trigger mock user automated query replies for realism
    setTimeout(() => {
      setChatThreads(prev => prev.map(t => {
        if (t.id === activeChatId) {
          return {
            ...t,
            lastMessage: 'خیلی ممنون از تعهد همکاران فروش غرفه شما. بررسی میکنم.',
            time: 'هم‌اکنون',
            chatHistory: [
              ...t.chatHistory,
              { sender: 'CUSTOMER', text: 'خیلی ممنون از تعهد همکاران فروش غرفه شما. بررسی میکنم.', time: 'امروز، چند لحظه بعد' }
            ]
          };
        }
        return t;
      }));
    }, 2800);
  };

  // Withdraw payout request transaction submitter
  const handleWithdrawSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawError('');
    setWithdrawSuccess('');

    if (!shop) return;

    const amountNum = parseInt(withdrawAmount.replace(/[^\d]/g, ''), 10);
    if (isNaN(amountNum) || amountNum <= 0) {
      setWithdrawError('لطفاً مبلغ معتبری برای تسویه حساب وارد کنید.');
      return;
    }

    if (amountNum > shop.balance) {
      setWithdrawError('مبلغ درخواستی نمی‌تواند از موجودی فعلی صندوق بیشتر باشد.');
      return;
    }

    const newReq: WithdrawRequest = {
      id: `pay_${Math.floor(100 + Math.random() * 900)}`,
      amount: amountNum,
      date: '۱۴۰۵/۰۳/۱۷',
      shaba: shop.shaba || 'IR890120000000012345678901',
      status: 'PENDING'
    };

    setWithdrawRequests(prev => [newReq, ...prev]);
    
    // deduct balance tentatively or keep standard until PAID (simulation keeps state clear)
    const updatedShop: VendorShop = {
      ...shop,
      balance: shop.balance - amountNum
    };
    if (onUpdateShop) {
      onUpdateShop(updatedShop);
    }

    setWithdrawAmount('');
    setWithdrawSuccess(`درخواست تسویه مباغ ${formatPrice(amountNum)} تومان با موفقیت ثبت شد و در صف پرداخت حسابداری است.`);
    addLog('REPOSITORY', 'درخواست تسویه کیف پول غرفه ثبت گردید', `${amountNum} تومان`);

    setNotifications(prev => [
      {
        id: `vn_${Date.now()}`,
        title: '💸 مالی: درخواست تسویه صندوق',
        body: `درخواست پی اوت به مبلغ ${formatPrice(amountNum)} تومان دریافت و برای پردازش واحد مالی ارسال شد.`,
        time: 'هم‌اکنون',
        type: 'WALLET',
        isRead: false
      },
      ...prev
    ]);
  };

  // Helper values calculations
  const totalRevenue = vendorOrders
    .filter(o => o.status !== 'PENDING')
    .reduce((acc, o) => acc + (o.price * o.quantity), 0);

  const pendingOrdersCount = vendorOrders.filter(o => o.status === 'PENDING').length;
  const deliveredOrdersCount = vendorOrders.filter(o => o.status === 'DELIVERED').length;
  const vendorProducts = products.filter(p => p.vendor?.name === shop?.name);
  const lowStockCount = vendorProducts.filter(p => (p.stock !== undefined && p.stock < 3)).length;

  return (
    <div className="flex flex-col bg-[#f8fafc] h-full pb-20 font-vazir text-right overflow-y-auto" dir="rtl" id="vendor-console-viewport">
      
      {/* 1. STATE: UNREGISTERED / NOT REGISTERED YET */}
      {!shop ? (
        <div className="flex-1 flex flex-col justify-between p-4" id="vendor-unregistered-view">
          <div className="bg-gradient-to-l from-emerald-700 to-teal-800 text-white p-6 rounded-3xl shadow-xl">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center text-2xl border border-white/20">
                🏪
              </div>
              <div>
                <h2 className="text-base font-black tracking-tight">راه‌اندازی فوری پنل غرفه‌داری و چندفروشندگی یوزآنلاین</h2>
                <p className="text-[10px] text-emerald-100/90 mt-1 leading-relaxed">با ارسال چند کلیک غرفه الکترونیکی خود را فعال کنید، سفارش بگیرید و درآمد کسب کنید.</p>
              </div>
            </div>
          </div>

          <div className="my-6">
            <form onSubmit={handleRegisterSubmit} className="bg-white border border-slate-100 rounded-3xl p-5 shadow-md flex flex-col gap-4">
              <div className="text-center py-2 border-b border-slate-100 mb-2">
                <span className="text-sm font-black text-slate-800">فرم ثبت‌نام و فعال‌سازی غرفه همکار</span>
                <p className="text-[9px] text-slate-400 mt-1">تمام اطلاعات زیر توسط لایه ادمین ارزیابی می‌شود</p>
              </div>

              {regError && (
                <div className="bg-red-50 text-red-600 text-[9px] p-2.5 rounded-xl border border-red-100 font-extrabold text-center">
                  ⚠️ {regError}
                </div>
              )}

              <div>
                <label className="text-[10px] font-black text-slate-700 block mb-1">نام غرفه تجاری شما <span className="text-red-500">*</span></label>
                <input 
                  type="text" 
                  required
                  placeholder="مثال: رویال دیجیتال، فروشگاه چرم پارسا"
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2.5 text-[10px] rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 transition text-right"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black text-slate-700 block mb-1">رسته صنف فعالیت <span className="text-red-500">*</span></label>
                  <select 
                    value={regCategory}
                    onChange={(e) => setRegCategory(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 px-3 py-2.5 text-[10px] rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 transition text-right"
                  >
                    <option value="digital">کالای دیجیتال</option>
                    <option value="apparel">مد و پوشاک</option>
                    <option value="home">خانه و آشپزخانه</option>
                    <option value="cosmetics">آرایشی و بهداشتی</option>
                    <option value="shoes">کفش و کتانی ورزشی</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-black text-slate-700 block mb-1">لوگوی سمبلیک املایی <span className="text-red-500">*</span></label>
                  <select 
                    value={regLogo}
                    onChange={(e) => setRegLogo(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 px-3 py-2.5 text-[10px] rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 transition text-right"
                  >
                    {LOGO_COLLECTION.map(l => (
                      <option key={l.char} value={l.char}>{l.char} {l.label}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-[10px] font-black text-slate-700 block mb-1">شماره تماس غرفه <span className="text-red-500">*</span></label>
                  <input 
                    type="tel"
                    required
                    placeholder="مثال: 09121112222"
                    value={regPhone}
                    onChange={(e) => setRegPhone(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2.5 text-[10px] rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 transition text-left font-mono"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="text-[10px] font-black text-slate-700 block mb-1">ایمیل تجاری</label>
                  <input 
                    type="email"
                    placeholder="sales@shop.com"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2.5 text-[10px] rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 transition text-left font-mono"
                    dir="ltr"
                  />
                </div>
              </div>

              <div>
                <label className="text-[10px] font-black text-slate-700 block mb-1">شماره شبای بانکی جهت تسویه درآمد (۲۴ رقم) <span className="text-red-500">*</span></label>
                <input 
                  type="text" 
                  required
                  placeholder="IR890120000000012345678901"
                  value={regShaba}
                  onChange={(e) => setRegShaba(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2.5 text-[10px] rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 transition text-left font-mono placeholder:text-right"
                  dir="ltr"
                />
              </div>

              <div>
                <label className="text-[10px] font-black text-slate-700 block mb-1">بیو و چکیده اهداف فعالیت غرفه <span className="text-red-500">*</span></label>
                <textarea 
                  required
                  rows={2}
                  placeholder="مزایا، سابقه و زمینه دقیق محصولات قابل عرضه را مرقوم فرمایید..."
                  value={regDesc}
                  onChange={(e) => setRegDesc(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2 text-[10px] rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 transition text-right resize-none"
                />
              </div>

              <div>
                <label className="text-[10px] font-black text-slate-700 block mb-1">آدرس پستی غرفه یا انبار اصلی</label>
                <input 
                  type="text" 
                  placeholder="آدرس دقیق جهت عودت کالا یا مراجعه پست"
                  value={regAddress}
                  onChange={(e) => setRegAddress(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2.5 text-[10px] rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 transition text-right"
                />
              </div>

              <button
                type="submit"
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black py-3.5 rounded-2xl transition active:scale-[98] shadow-md shadow-emerald-100 flex items-center justify-center gap-2 cursor-pointer mt-2"
              >
                <Store className="w-4 h-4" />
                تایید نهایی داده‌ها و ارسال به صف احراز صلاحیت ادمین
              </button>
            </form>
          </div>

          <button
            onClick={onBackToBuyer}
            className="w-full border border-slate-200 text-slate-500 text-xs py-3 rounded-2xl hover:bg-slate-100 active:scale-[98] transition flex items-center justify-center gap-2 bg-white"
          >
            <ArrowLeft className="w-4 h-4" />
            بازگشت به لایه کاربری خریدار
          </button>
        </div>
      ) : (

        /* 2. STATE: SHOP IS REGISTERED (PENDING, APPROVED, OR REJECTED) */
        <div className="flex-1 flex flex-col" id="vendor-registered-dashboard">
          
          {/* Header Store Banner Info Box */}
          <div className={`bg-gradient-to-l ${shop.bannerColor || 'from-emerald-700 to-teal-800'} text-white p-5 pt-8 rounded-b-[2.5rem] shadow-xl relative`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-white/20 select-none flex items-center justify-center text-2xl border border-white/25 shadow-inner">
                  {shop.logo}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-sm font-black">{shop.name}</h2>
                    {isShopApproved && (
                      <span className="bg-emerald-500/25 text-emerald-200 border border-emerald-400/30 text-[7px] font-black px-1.5 py-0.5 rounded">
                        غرفه فعال همکار
                      </span>
                    )}
                    {isShopPending && (
                      <span className="bg-amber-500/25 text-amber-200 border border-amber-400/30 text-[7px] font-black px-1.5 py-0.5 rounded animate-pulse">
                        در انتظار احراز هویت
                      </span>
                    )}
                    {isShopRejected && (
                      <span className="bg-red-500/25 text-red-200 border border-red-400/30 text-[7px] font-black px-1.5 py-0.5 rounded">
                        رد شده توسط ادمین
                      </span>
                    )}
                  </div>
                  <p className="text-[9px] text-white/80 line-clamp-1 mt-0.5 max-w-sm">{shop.description}</p>
                </div>
              </div>

              <button
                onClick={onBackToBuyer}
                className="bg-white/10 hover:bg-white/20 py-2 px-3 text-[8px] font-black rounded-xl transition border border-white/10 flex items-center gap-1 scale-x-[-1] cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span className="scale-x-[-1]">صندوق خرید خانه</span>
              </button>
            </div>

            {/* Navigation Tabs Menu (Locked if Pending or Rejected) */}
            <div className={`flex bg-white/10 rounded-2xl p-1 mt-5 text-[8.5px] font-black border border-white/5 overflow-x-auto gap-0.5 scrollbar-none`}>
              {[
                { label: 'داشبورد صنف', icon: Sliders, tab: 0, forceAllow: true },
                { label: 'طرح کالا و کاتالوگ', icon: Package, tab: 1, forceAllow: false },
                { label: 'پردازش بار خریداران', icon: Clipboard, tab: 2, forceAllow: false },
                { label: 'گفتگو با خریدار', icon: MessageSquare, tab: 3, forceAllow: false },
                { label: 'کیف‌ پول و تسویه', icon: Wallet, tab: 4, forceAllow: false },
                { label: 'پروفایل و نمایه غرفه', icon: Settings, tab: 5, forceAllow: false },
              ].map(item => {
                const isItemLocked = !isShopApproved && !item.forceAllow;
                return (
                  <button
                    key={item.tab}
                    onClick={() => {
                      if (isItemLocked) return;
                      addLog('UI', `تغییر تب کنسول غرفه‌داری به: ${item.label}`, `بخش: ${item.tab}`);
                      setActiveTab(item.tab);
                    }}
                    className={`flex-1 py-1.5 px-2 rounded-xl text-center flex items-center justify-center gap-1.5 whitespace-nowrap transition cursor-pointer select-none ${
                      isItemLocked ? 'opacity-40 cursor-not-allowed' : ''
                    } ${
                      activeTab === item.tab ? 'bg-white text-emerald-950 shadow-md font-extrabold' : 'text-white/85 hover:text-white'
                    }`}
                  >
                    <item.icon className="w-3 h-3 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Main SubTab Contents Area */}
          <div className="p-4 flex-1">
            
            {/* SUBTAB 0: DASHBOARD PERFORMANCE (ALWAY ACCESSIBLE OR PENDING PROMPT) */}
            {activeTab === 0 && (
              <div className="flex flex-col gap-4 animate-fade-in">
                
                {/* 2.1 SHOP IS NOT APPROVED PANEL */}
                {!isShopApproved && (
                  <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm text-center flex flex-col gap-4" id="payout-verification-card">
                    <div className="w-12 h-12 bg-amber-500/10 text-amber-600 rounded-full flex items-center justify-center text-xl mx-auto border border-amber-500/20">
                      🗝️
                    </div>
                    <div>
                      <h3 className="text-xs font-black text-slate-800">وضعیت پرونده: {isShopPending ? 'در صف ارزیابی و استعلام' : 'رد صلاحیت موقت'}</h3>
                      <p className="text-[9.5px] text-slate-500 mt-1 lines-relaxed">
                        {isShopPending 
                          ? 'پرونده صنف غرفه آنلاین شما با موفقیت به ادمین فرستاده شد. ادمین می‌تواند در "کنسول ادمین" بخش "احراز صلاحیت غرفه‌ها" برند شما را فوراً تایید و افتتاح نماید.'
                          : 'متاسفانه مدارک یا مشخصات فرستاده شده غرفه شما مورد تایید ناظر بازارچه قرار نگرفته است. لطفاً اصلاح نموده و ارسال بفرمایید.'
                        }
                      </p>
                    </div>

                    {/* Pending checklists timeline */}
                    <div className="text-right flex flex-col gap-2.5 bg-slate-50 p-4 rounded-2xl border border-slate-100/80 font-medium">
                      <span className="text-[10px] font-black text-slate-800">مراحل و چک‌لیست‌های ارزیابی تا افتتاح:</span>
                      
                      <div className="flex items-center gap-2 text-[9px] text-emerald-600 font-bold">
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>مرحله ۱: دریافت پرونده ثبت‌نام غرفه و احراز شبا (تکمیل شد)</span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-[9px] text-emerald-600 font-bold">
                        <CheckCircle className="w-3.5 h-3.5" />
                        <span>مرحله ۲: بررسی شماره تماس و انطباق ایمیل (تکمیل شد)</span>
                      </div>

                      <div className="flex items-center gap-2 text-[9px]">
                        {isShopPending ? (
                          <Clock className="w-3.5 h-3.5 text-amber-500 animate-spin-slow" />
                        ) : (
                          <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
                        )}
                        <span className={isShopPending ? 'text-amber-600 font-black' : 'text-slate-400 font-bold'}>
                          {isShopPending ? 'مرحله ۳: تایید نهایی مجوز فعالیت تجاری بازارچه توسط ادمین' : 'مرحله ۳: اتمام بررسی (رد صلاحیت شده)'}
                        </span>
                      </div>
                    </div>

                    {isShopRejected && (
                      <button
                        onClick={() => {
                          setIsEditingProfile(true);
                          setActiveTabInner(5); // Go directly to Profile Settings to update
                        }}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white text-[9.5px] font-black py-2.5 rounded-xl cursor-pointer"
                      >
                        اصلاح مشخصات غرفه و ثبت مجدد درخواست
                      </button>
                    )}
                  </div>
                )}

                {/* 2.2 MAIN SALES & REVENUE PERFORMANCE FOR APPROVED SHOPS */}
                {isShopApproved && (
                  <div className="flex flex-col gap-4">
                    
                    {/* Visual Card indicators */}
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      <div className="bg-white border border-slate-100 p-4 rounded-3xl shadow-sm flex flex-col justify-between">
                        <div className="flex items-center justify-between text-slate-400">
                          <span className="text-[9px] font-black">کل فروش ناخالص</span>
                          <DollarSign className="w-4 h-4 text-emerald-600 border border-emerald-500/10 p-0.5 rounded-lg bg-emerald-500/5 bg-emerald-50" />
                        </div>
                        <span className="text-sm font-black text-slate-900 mt-2">
                          {formatPrice(totalRevenue)} <span className="text-[7.5px] text-slate-400">تومان</span>
                        </span>
                      </div>

                      <div className="bg-white border border-slate-100 p-4 rounded-3xl shadow-sm flex flex-col justify-between">
                        <div className="flex items-center justify-between text-slate-400">
                          <span className="text-[9px] font-black">موجودی صندوق غرفه</span>
                          <Wallet className="w-4 h-4 text-emerald-600 border border-emerald-500/10 p-0.5 rounded-lg bg-emerald-500/5 bg-emerald-50" />
                        </div>
                        <span className="text-sm font-black text-emerald-600 mt-2">
                          {formatPrice(shop.balance)} <span className="text-[7.5px] text-emerald-500">تومان</span>
                        </span>
                      </div>

                      <div className="bg-white border border-slate-100 p-4 rounded-3xl shadow-sm flex flex-col justify-between col-span-2 md:col-span-1">
                        <div className="flex items-center justify-between text-slate-400">
                          <span className="text-[9px] font-black">وضعیت انبار و موجودی</span>
                          <Package className="w-4 h-4 text-emerald-600 border border-emerald-500/10 p-0.5 rounded-lg bg-emerald-500/5 bg-emerald-50" />
                        </div>
                        <div className="flex items-center gap-1.5 mt-2">
                          <span className="text-sm font-black text-slate-900">{toPersianDigits(vendorProducts.length)} <span className="text-[7.5px] text-slate-400">قلم کالا</span></span>
                          {lowStockCount > 0 && (
                            <span className="text-[7px] bg-red-50 text-red-600 font-extrabold px-1.5 py-0.5 rounded border border-red-100 animate-pulse">
                              {toPersianDigits(lowStockCount)} کالا رو به اتمام!
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Chart widgets: Sales report Daily/Weekly/Monthly */}
                    <div className="bg-white border border-slate-100 p-4 rounded-3xl shadow-sm flex flex-col gap-3">
                      <div className="flex justify-between items-center border-b border-slate-50 pb-2">
                        <span className="text-[10px] font-black text-slate-800 flex items-center gap-1">
                          <TrendingUp className="w-3.5 h-3.5 text-emerald-600" />
                          گزارش مقایسه‌ای مالی و رونق بازاریابی غرفه
                        </span>
                        <span className="text-[8px] text-slate-400 font-bold bg-slate-50 border border-slate-100 px-2 py-0.5 rounded">
                          به‌روزرسانی: لایو
                        </span>
                      </div>

                      <p className="text-[8.5px] text-slate-400 leading-relaxed font-semibold">تراز فروش غرفه شما به تفکیک تحلیل سه بازه روزانه، هفتگی و ماهانه از دیتابیس تراکنشی:</p>

                      <div className="grid grid-cols-3 gap-3 pt-2">
                        {/* Daily Sales Bar */}
                        <div className="flex flex-col items-center bg-slate-50/50 p-2.5 rounded-2xl border border-slate-100/60">
                          <span className="text-[8px] text-slate-400 font-black mb-1">فروش روزانه</span>
                          <div className="h-20 w-8 bg-slate-100/80 rounded-lg flex items-end overflow-hidden border border-slate-100">
                            <div className="w-full bg-indigo-500 rounded-t h-[35%]" title="امروز"></div>
                          </div>
                          <span className="text-[8px] text-slate-700 font-black mt-2">{formatPrice(790000)} تومان</span>
                          <span className="text-[7px] text-indigo-500 font-bold mt-0.5">۳ سفارش</span>
                        </div>

                        {/* Weekly Sales Bar */}
                        <div className="flex flex-col items-center bg-slate-50/50 p-2.5 rounded-2xl border border-slate-100/60">
                          <span className="text-[8px] text-slate-400 font-black mb-1">فروش هفتگی</span>
                          <div className="h-20 w-8 bg-slate-100/80 rounded-lg flex items-end overflow-hidden border border-slate-100">
                            <div className="w-full bg-emerald-500 rounded-t h-[65%]" title="هفته جاری"></div>
                          </div>
                          <span className="text-[8px] text-slate-700 font-black mt-2">{formatPrice(4350000)} تومان</span>
                          <span className="text-[7px] text-emerald-500 font-bold mt-0.5">۸ سفارش</span>
                        </div>

                        {/* Monthly Sales Bar */}
                        <div className="flex flex-col items-center bg-slate-50/50 p-2.5 rounded-2xl border border-slate-100/60">
                          <span className="text-[8px] text-slate-400 font-black mb-1">فروش ماهانه</span>
                          <div className="h-20 w-8 bg-slate-100/80 rounded-lg flex items-end overflow-hidden border border-slate-100">
                            <div className="w-full bg-teal-500 rounded-t h-[90%]" title="ماه جاری"></div>
                          </div>
                          <span className="text-[8px] text-slate-700 font-black mt-2">{formatPrice(15450000)} تومان</span>
                          <span className="text-[7px] text-teal-500 font-bold mt-0.5">۲۴ سفارش</span>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      
                      {/* Top sold products */}
                      <div className="bg-white border border-slate-100 p-4 rounded-3xl shadow-sm flex flex-col gap-3">
                        <span className="text-[10px] font-black text-slate-800 flex items-center gap-1 border-b border-slate-50 pb-2">
                          <Award className="w-3.5 h-3.5 text-amber-500" />
                          کالاهای پرفروش و محبوب شما
                        </span>

                        <div className="flex flex-col gap-2">
                          {vendorProducts.slice(0, 3).map((item, index) => (
                            <div key={item.id} className="flex items-center gap-2 py-1.5 border-b border-slate-50 last:border-0">
                              <span className="text-[10px] font-black text-slate-400 w-4">#{index + 1}</span>
                              <img src={item.image} alt={item.title} className="w-8 h-8 rounded-lg object-cover" />
                              <div className="flex-1 min-w-0">
                                <span className="text-[9px] font-bold text-slate-800 block truncate">{item.title}</span>
                                <span className="text-[7.5px] text-slate-400 block mt-0.5">فروش موفق: {toPersianDigits(12 - index)} بار | موجودی: {toPersianDigits(item.stock || 10)}</span>
                              </div>
                            </div>
                          ))}
                          {vendorProducts.length === 0 && (
                            <div className="text-center py-4 text-[9px] text-slate-400">محصولی در کاتالوگ شما موجود نیست.</div>
                          )}
                        </div>
                      </div>

                      {/* Micro orders and logs stats */}
                      <div className="bg-white border border-slate-100 p-4 rounded-3xl shadow-sm flex flex-col gap-3">
                        <span className="text-[10px] font-black text-slate-800 flex items-center gap-1 border-b border-slate-50 pb-2">
                          <Bell className="w-3.5 h-3.5 text-blue-500" />
                          آخرین آلارم‌های غرفه تجاری
                        </span>

                        <div className="flex flex-col gap-2 max-h-36 overflow-y-auto pr-1">
                          {notifications.map(n => (
                            <div key={n.id} className="flex items-start gap-2 py-1.5 border-b border-slate-50/50 last:border-0">
                              <span className="text-xs shrink-0 select-none">
                                {n.type === 'ORDER' && '🛒'}
                                {n.type === 'WALLET' && '💳'}
                                {n.type === 'SYSTEM' && '⚙️'}
                              </span>
                              <div className="flex-1 min-w-0 text-right">
                                <span className="text-[9.5px] font-black text-slate-800 block">{n.title}</span>
                                <p className="text-[7.5px] text-slate-500 mt-0.5 leading-relaxed">{n.body}</p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Operational Performance bar */}
                    <div className="bg-emerald-500/5 border border-emerald-500/10 p-3.5 rounded-3xl flex items-center gap-3">
                      <span className="text-xl">🛡️</span>
                      <div className="flex-1 text-right">
                        <span className="text-[9.5px] font-black text-emerald-950 block">سامانه چندفروشندگی غرفه‌داران یوزآنلاین</span>
                        <p className="text-[8px] text-emerald-800 leading-relaxed mt-0.5">آمار مالی، تراکنش‌ها، تنوع کالا و گفتگوها طبق الگوی Clean Web-App کاملاً لایو همگام‌سازی می‌شود.</p>
                      </div>
                    </div>

                  </div>
                )}
              </div>
            )}

            {/* SUBTAB 1: PRODUCT CATALOGUE & VARIANTS MANAGER */}
            {activeTab === 1 && (
              <div className="flex flex-col gap-4 animate-fade-in">
                
                {/* Variant-friendly Catalog layout */}
                <div className="bg-white border border-slate-100 rounded-3xl p-4 shadow-sm flex flex-col gap-4 text-right font-medium">
                  <div className="pb-2 border-b border-slate-50 flex items-center justify-between">
                    <span className="text-[10px] font-black text-slate-800">تنوع محصولات، گارانتی و قیمت فروش</span>
                    <span className="text-[8px] bg-slate-50 border border-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-bold">
                      عرضه شده: {toPersianDigits(vendorProducts.length)} کالا
                    </span>
                  </div>

                  <p className="text-[8.5px] text-slate-400 leading-relaxed">
                    در لیست زیر، کدهای تنوع (Variants) هر کالا اعم از گارانتی، گرید فنی یا رنگ بر اساس ارزش مشخصاتی و قیمتی فهرست شده است.
                  </p>

                  <div className="flex flex-col gap-3 mt-1">
                    {vendorProducts.map(item => {
                      const stockCount = item.stock !== undefined ? item.stock : 10;
                      const hasLowStock = stockCount < 3;
                      
                      return (
                        <div key={item.id} className="border border-slate-100 bg-slate-50/25 p-3 rounded-2xl flex items-center gap-3 relative hover:shadow-md transition">
                          <img
                            src={item.image}
                            alt={item.title}
                            className="w-12 h-12 rounded-xl object-cover bg-white border border-slate-100 shrink-0"
                            referrerPolicy="no-referrer"
                          />
                          
                          <div className="flex-1 min-w-0 flex flex-col gap-1 text-right">
                            <span className="text-[10px] font-black text-slate-900 truncate">{item.title}</span>
                            <div className="flex items-center gap-2 text-[8px] text-slate-400 font-semibold font-mono">
                              <span>شاخه: {item.category}</span>
                              <span className="text-slate-200">|</span>
                              <span className="text-emerald-600 font-black">{formatPrice(item.price)} تومان</span>
                            </div>

                            {/* Specifications / Variants overview */}
                            {item.specifications && Object.keys(item.specifications).length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-1">
                                {Object.entries(item.specifications).map(([k, v]) => (
                                  <span key={k} className="bg-white border border-slate-100 text-[6.5px] text-slate-500 font-bold px-1.5 py-0.5 rounded">
                                    {k}: {v}
                                  </span>
                                ))}
                              </div>
                            )}

                            {/* Stock adjuster inline */}
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-[8px] text-slate-400 font-black">موجودی صندوق کالا:</span>
                              <div className="flex items-center border border-slate-100 bg-white rounded-lg px-1.5 py-0.5 gap-2" dir="ltr">
                                <button
                                  type="button"
                                  onClick={() => handleUpdateStockDirectly(item, stockCount + 1)}
                                  className="text-emerald-600 hover:text-emerald-800 font-extrabold text-[11px] active:scale-90 px-1 transition"
                                >
                                  +
                                </button>
                                <span className={`text-[8.5px] font-black font-mono w-4 text-center ${hasLowStock ? 'text-red-500' : 'text-slate-900'}`}>
                                  {toPersianDigits(stockCount)}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => handleUpdateStockDirectly(item, Math.max(0, stockCount - 1))}
                                  className="text-red-500 hover:text-red-700 font-extrabold text-[11px] active:scale-90 px-1 transition"
                                >
                                  -
                                </button>
                              </div>

                              {hasLowStock && (
                                <span className="bg-red-50 text-red-500 text-[6.5px] border border-red-100 font-black px-1.5 py-0.5 rounded animate-pulse">
                                  {stockCount === 0 ? 'اتمام موجودی' : 'رو به اتمام'}
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Action elements delete/edit */}
                          <div className="flex gap-1.5 pl-0 pr-auto" dir="ltr">
                            <button
                              onClick={() => handleOpenEditProduct(item)}
                              className="bg-white text-indigo-600 border border-slate-100 hover:bg-slate-50 p-2 rounded-xl active:scale-90 transition flex items-center justify-center shrink-0 cursor-pointer"
                              title="ویرایش کل مشخصات"
                            >
                              <Edit className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`آیا از حذف دائم کالا تحت عنوان "${item.title}" اطمینان دارید؟`)) {
                                  onDeleteProduct(item.id);
                                }
                              }}
                              className="bg-white text-red-500 border border-slate-100 hover:bg-slate-50 p-2 rounded-xl active:scale-90 transition flex items-center justify-center shrink-0 cursor-pointer"
                              title="حذف کالا"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}

                    {vendorProducts.length === 0 && (
                      <div className="text-center py-6 text-[9.5px] text-slate-400 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                        غرفه شما فاقد کالای فعال است. با دکمه زیر اولین کالای متنوع خود را بارگذاری کنید.
                      </div>
                    )}
                  </div>
                </div>

                {/* PRODUCT UPLOAD PANEL ACCORDION */}
                <form onSubmit={handleProductSubmit} className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm flex flex-col gap-4 text-right">
                  <div className="pb-2 border-b border-slate-50 mb-1">
                    <span className="text-[10px] font-black text-slate-800">کابین درج و تولید کالای جدید</span>
                    <p className="text-[7.5px] text-slate-400 mt-1 lines-relaxed">انتخاب نام، قیمت تنوعی و گالری عکس محصول</p>
                  </div>

                  <div>
                    <label className="text-[9.5px] font-black text-slate-700 block mb-1">عنوان فارسی کالا</label>
                    <input 
                      type="text" 
                      required
                      placeholder="مثال: گوشی آیفون ۱۵ حافظه ۲۵۶ گیگابایت"
                      value={prodTitle}
                      onChange={(e) => setProdTitle(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-100 px-3.5 py-2 text-[9px] rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 transition text-right"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[9.5px] font-black text-slate-700 block mb-1">شاخه و ردیف کالا</label>
                      <select 
                        value={prodCategory}
                        onChange={(e) => setProdCategory(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-100 px-3 py-2 text-[9px] rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 text-right"
                      >
                        <option value="phones">گوشی موبایل</option>
                        <option value="laptops">لپ‌تاپ و تبلت</option>
                        <option value="audio">هدفون و پخش‌صوت</option>
                        <option value="shoes">کفش و کتانی ورزش</option>
                        <option value="kitchen">لوازم آشپزخانه</option>
                        <option value="perfume">عطر و ادکلن</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-[9.5px] font-black text-slate-700 block mb-1">قیمت نقدی کالا (تومان)</label>
                      <input 
                        type="text" 
                        required
                        placeholder="مثال: ۴۵,۰۰۰,۰۰۰"
                        value={prodPrice}
                        onChange={(e) => setProdPrice(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-100 px-3.5 py-2 text-[9px] rounded-xl focus:outline-none focus:ring-1 focus:ring-emerald-500 text-left font-mono"
                        dir="ltr"
                      />
                    </div>
                  </div>

                  {/* Dynamic Variant tags form */}
                  <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100">
                    <span className="text-[9px] font-black text-slate-800 block mb-2">تعریف پارامتر تنوع (کد تنوع کالا)</span>
                    
                    <div className="flex gap-2 mb-2">
                      <input 
                        type="text"
                        placeholder="عنوان: رنگ"
                        value={tempVariantName}
                        onChange={(e) => setTempVariantName(e.target.value)}
                        className="flex-1 bg-white border border-slate-100 px-2.5 py-1 text-[8.5px] rounded-lg"
                      />
                      <input 
                        type="text"
                        placeholder="ارزش: مشکی تیتانیوم"
                        value={tempVariantVal}
                        onChange={(e) => setTempVariantVal(e.target.value)}
                        className="flex-1 bg-white border border-slate-100 px-2.5 py-1 text-[8.5px] rounded-lg"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (tempVariantName.trim() && tempVariantVal.trim()) {
                            setVariantsList(p => [...p, { name: tempVariantName.trim(), value: tempVariantVal.trim() }]);
                            setTempVariantName('');
                            setTempVariantVal('');
                          }
                        }}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white text-[8px] font-black px-3 rounded-lg cursor-pointer"
                      >
                        درج تنوع
                      </button>
                    </div>

                    {variantsList.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {variantsList.map((v, idx) => (
                          <span key={idx} className="bg-white border border-slate-200 text-[8px] text-slate-600 px-2.5 py-1 rounded-lg flex items-center gap-1">
                            <strong>{v.name}:</strong> {v.value}
                            <button
                              type="button"
                              onClick={() => setVariantsList(p => p.filter((_, i) => i !== idx))}
                              className="text-red-500 font-extrabold hover:text-red-700 text-[9px] cursor-pointer"
                            >
                              ×
                            </button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Dual Choice image selection */}
                  <div>
                    <label className="text-[9.5px] font-black text-slate-700 block mb-1">آدرس عکس کالا</label>
                    <div className="flex gap-2 mb-2 bg-slate-50 p-1.5 rounded-xl border border-slate-100">
                      <button
                        type="button"
                        onClick={() => setProdImgType('preset')}
                        className={`flex-1 py-1.5 text-[8.5px] font-black rounded-lg transition ${
                          prodImgType === 'preset' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-400'
                        }`}
                      >
                        کاتالوگ باکیفیت و نمونه
                      </button>
                      <button
                        type="button"
                        onClick={() => setProdImgType('custom')}
                        className={`flex-1 py-1.5 text-[8.5px] font-black rounded-lg transition ${
                          prodImgType === 'custom' ? 'bg-white text-emerald-700 shadow-sm' : 'text-slate-400'
                        }`}
                      >
                        آدرس تصویر وب (Custom URL)
                      </button>
                    </div>

                    {prodImgType === 'preset' ? (
                      <select 
                        value={prodPresetImg}
                        onChange={(e) => setProdPresetImg(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-100 px-3 py-1.5 text-[9px] rounded-xl text-right focus:outline-none"
                      >
                        <option value="">-- یک عکس آماده انتخاب کنید --</option>
                        {(PRODUCT_IMAGE_PRESETS[prodCategory] || PRODUCT_IMAGE_PRESETS['default']).map(p => (
                          <option key={p.url} value={p.url}>{p.label}</option>
                        ))}
                      </select>
                    ) : (
                      <input 
                        type="url"
                        placeholder="https://images.unsplash.com/photo-..."
                        value={prodCustomImg}
                        onChange={(e) => setProdCustomImg(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-100 px-3.5 py-1.5 text-[9px] rounded-xl text-left font-mono focus:outline-none"
                        dir="ltr"
                      />
                    )}
                  </div>

                  <div>
                    <label className="text-[9.5px] font-black text-slate-700 block mb-1">توضیحات و نقد فارسی کالا</label>
                    <textarea 
                      required
                      rows={2}
                      placeholder="برجستگی‌ها و قابلیت‌های کاربردی کالا را به خریداران بنویسید..."
                      value={prodDesc}
                      onChange={(e) => setProdDesc(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-100 px-3.5 py-2 text-[9px] rounded-xl focus:outline-none resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] py-3 rounded-2xl shadow-md cursor-pointer font-black flex items-center justify-center gap-2 mt-1"
                  >
                    <PlusCircle className="w-4 h-4" />
                    قرار دادن این کالای متنوع در کاتالوگ فروشگاه
                  </button>
                </form>

              </div>
            )}

            {/* SUBTAB 2: ORDERS PROCESSING QUEUE */}
            {activeTab === 2 && (
              <div className="flex flex-col gap-4 animate-fade-in font-medium">
                
                <div className="bg-white border border-slate-100 rounded-3xl p-4 shadow-sm flex flex-col gap-3">
                  <div className="pb-1.5 border-b border-slate-50 flex items-center justify-between">
                    <span className="text-[10px] font-black text-slate-800 flex items-center gap-1.5">
                      <Clipboard className="w-3.5 h-3.5 text-emerald-600" />
                      کارپوشه مدیریت مرسوله‌های سفارشی
                    </span>
                    <span className="text-[8.5px] bg-slate-50 text-slate-500 font-extrabold px-2.5 py-0.5 rounded border border-slate-100">
                      کارتابل فعال: {toPersianDigits(vendorOrders.length)} باربری
                    </span>
                  </div>

                  <p className="text-[8.5px] text-slate-400">
                    زمانی که کاربری خریدی ثبت کند فاکتور آن فوراً در زیر درج می‌گردد. جهت جلوگیری از لغو و حفظ امتیاز غرفه، کالا را سریع تایید و تحول مامور یوزآنلاین پست دهید.
                  </p>

                  <div className="flex flex-col gap-3 mt-1">
                    {vendorOrders.map(order => (
                      <div key={order.id} className="bg-slate-50/20 border border-slate-100/90 rounded-2xl p-4 flex flex-col gap-3">
                        <div className="flex justify-between items-center border-b border-slate-50 pb-2 bg-slate-50 p-2 rounded-xl">
                          <div className="flex items-center gap-2">
                            <img src={order.avatar} alt={order.user} className="w-5 h-5 rounded-full object-cover border border-slate-200" />
                            <div className="text-right">
                              <span className="text-[9.5px] font-black text-slate-900 block">{order.user}</span>
                              <span className="text-[7.5px] text-slate-400 block mt-0.5">تاریخ: {order.date} | کدبار: {order.id}</span>
                            </div>
                          </div>

                          {order.status === 'PENDING' && (
                            <span className="bg-rose-50 text-rose-600 text-[7.5px] border border-rose-100 font-black px-2 py-0.5 rounded-full animate-pulse">در انتظار بررسی</span>
                          )}
                          {order.status === 'PREPARING' && (
                            <span className="bg-blue-50 text-blue-600 text-[7.5px] border border-blue-100 font-black px-2 py-0.5 rounded-full">تایید شده / آماده‌سازی</span>
                          )}
                          {order.status === 'SHIPPED' && (
                            <span className="bg-indigo-50 text-indigo-600 text-[7.5px] border border-indigo-100 font-black px-2 py-0.5 rounded-full">تحویل به مامور پست</span>
                          )}
                          {order.status === 'DELIVERED' && (
                            <span className="bg-emerald-50 text-emerald-600 text-[7.5px] border border-emerald-100 font-black px-2 py-0.5 rounded-full">تحویل نهایی شد</span>
                          )}
                        </div>

                        {/* Product visual info */}
                        <div className="flex gap-3 items-center">
                          <img src={order.productImg} alt={order.productTitle} className="w-10 h-10 rounded-xl object-cover border border-slate-200/50" />
                          <div className="flex-1 min-w-0">
                            <h4 className="text-[9.5px] font-bold text-slate-800 line-clamp-1 leading-normal">{order.productTitle}</h4>
                            <div className="flex justify-between items-center text-[8px] text-slate-400 mt-2">
                              <span>تعداد سفارش: {toPersianDigits(order.quantity)} عدد</span>
                              <span className="font-bold text-emerald-600">ارزش تراکنش: {formatPrice(order.price)} تومان</span>
                            </div>
                          </div>
                        </div>

                        {/* Actions tracking */}
                        <div className="flex items-center gap-1 border-t border-slate-50/50 pt-2 pb-1 bg-slate-50/30 px-2 rounded-xl">
                          <span className="text-[8px] text-slate-400 font-bold ml-auto">اقدام تایید و جریان:</span>

                          {order.status === 'PENDING' && (
                            <button
                              onClick={() => handleUpdateStatus(order.id, 'PREPARING')}
                              className="bg-emerald-600 hover:bg-emerald-700 text-white font-heavy text-[8px] px-3 py-1.5 rounded-xl cursor-pointer"
                            >
                              پذیرش سفارش خریدار
                            </button>
                          )}

                          {order.status === 'PREPARING' && (
                            <button
                              onClick={() => handleUpdateStatus(order.id, 'SHIPPED')}
                              className="bg-blue-600 hover:bg-blue-700 text-white font-heavy text-[8px] px-3 py-1.5 rounded-xl cursor-pointer"
                            >
                              تحویل به مامور یوزآنلاین پست
                            </button>
                          )}

                          {order.status === 'SHIPPED' && (
                            <button
                              onClick={() => handleUpdateStatus(order.id, 'DELIVERED')}
                              className="bg-indigo-600 hover:bg-indigo-700 text-white font-heavy text-[8px] px-3 py-1.5 rounded-xl cursor-pointer"
                            >
                              تکمیل و اعلام تحویل موفق به مشتری
                            </button>
                          )}

                          {order.status === 'DELIVERED' && (
                            <span className="text-emerald-600 text-[8px] font-black flex items-center gap-0.5">
                              <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                              تسویه حساب تراکنش موفق غرفه‌ای
                            </span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}

            {/* SUBTAB 3: CUSTOMER CRM CHATS */}
            {activeTab === 3 && (
              <div className="bg-white border border-slate-100 rounded-3xl p-4 shadow-sm flex flex-col md:flex-row gap-4 h-[440px] animate-fade-in">
                {/* Chat users list */}
                <div className="w-full md:w-64 border-l border-slate-50 flex flex-col gap-2 overflow-y-auto">
                  <span className="text-[9px] font-black text-slate-800 px-2 pb-2 border-b border-slate-50">صندوق گفتگو با خریداران ({toPersianDigits(chatThreads.length)})</span>
                  {chatThreads.map(chat => (
                    <button
                      key={chat.id}
                      onClick={() => setActiveChatId(chat.id)}
                      className={`w-full text-right p-2.5 rounded-2xl flex items-center gap-2.5 transition cursor-pointer select-none ${
                        activeChatId === chat.id ? 'bg-indigo-50/50 border border-indigo-100 text-indigo-950' : 'hover:bg-slate-50'
                      }`}
                    >
                      <img src={chat.senderAvatar} alt={chat.senderName} className="w-8 h-8 rounded-full object-cover border border-slate-200" />
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center">
                          <span className="text-[9.5px] font-black text-slate-800">{chat.senderName}</span>
                          <span className="text-[7.5px] text-slate-400 font-mono">{chat.time}</span>
                        </div>
                        <p className="text-[8px] text-slate-400 truncate mt-0.5">{chat.lastMessage}</p>
                      </div>
                      {chat.unreadCount > 0 && (
                        <span className="bg-red-500 text-white text-[7px] font-bold w-4 h-4 rounded-full flex items-center justify-center shrink-0">
                          {toPersianDigits(chat.unreadCount)}
                        </span>
                      )}
                    </button>
                  ))}
                </div>

                {/* Chat window panel */}
                <div className="flex-1 flex flex-col justify-between h-full bg-slate-50/50 rounded-2xl border border-slate-100 overflow-hidden">
                  {/* Chat header */}
                  {(() => {
                    const currentChat = chatThreads.find(c => c.id === activeChatId);
                    if (!currentChat) return null;
                    return (
                      <>
                        <div className="bg-slate-100/80 p-3 flex items-center gap-2 border-b border-slate-200/55">
                          <img src={currentChat.senderAvatar} alt={currentChat.senderName} className="w-7 h-7 rounded-full object-cover" />
                          <div className="text-right">
                            <span className="text-[10px] font-black text-slate-900 block">{currentChat.senderName}</span>
                            <span className="text-[7.5px] text-emerald-600 font-bold block mt-0.5">پاسخگویی غرفه آنلاین شما</span>
                          </div>
                        </div>

                        {/* Messages logs */}
                        <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-2.5 font-medium">
                          {currentChat.chatHistory.map((h, hIdx) => {
                            const isVendor = h.sender === 'VENDOR';
                            return (
                              <div
                                key={hIdx}
                                className={`flex flex-col max-w-[75%] ${isVendor ? 'mr-auto items-end' : 'ml-auto items-start'}`}
                              >
                                <div className={`px-3 py-2 rounded-2xl text-[9px] leading-relaxed shadow-sm ${
                                  isVendor ? 'bg-indigo-600 text-white rounded-br-none' : 'bg-white text-slate-800 border border-slate-100 rounded-bl-none'
                                }`}>
                                  {h.text}
                                </div>
                                <span className="text-[6.5px] text-slate-400 font-mono mt-1 px-1">{h.time}</span>
                              </div>
                            );
                          })}
                        </div>

                        {/* CRM Preconfigured options */}
                        <div className="flex gap-1 overflow-x-auto p-2 bg-slate-100/50 border-t border-slate-150 border-slate-200/40">
                          {[
                            'سلام، سفارش شما بسته‌بندی شده و فردا به یوزآنلاین پست تحویل داده می‌شود.',
                            'عذرخواهی جهت تاخیر، کد رهگیری تا چند ساعت دیگر ثبت می‌شود.',
                            'بله کاملاً اصلی است و ۱۸ ماه گارانتی رسمی تعویض دارد.'
                          ].map((chip, chipIdx) => (
                            <button
                              key={chipIdx}
                              type="button"
                              onClick={() => setTypedMessage(chip)}
                              className="text-[7px] bg-white border border-slate-200 text-slate-500 font-black px-2 py-1 rounded-xl whitespace-nowrap active:scale-95 cursor-pointer hover:bg-indigo-50 hover:text-indigo-600"
                            >
                              {chip}
                            </button>
                          ))}
                        </div>

                        {/* Composer footer input */}
                        <div className="p-2.5 bg-white border-t border-slate-100 flex items-center gap-2">
                          <input 
                            type="text" 
                            placeholder="پیام خود را بنویسید..."
                            value={typedMessage}
                            onChange={(e) => setTypedMessage(e.target.value)}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleSendMessage();
                            }}
                            className="flex-1 bg-slate-50 border border-slate-100 rounded-xl px-3 py-2 text-[9px] focus:outline-none"
                          />
                          <button
                            type="button"
                            onClick={handleSendMessage}
                            className="bg-indigo-600 hover:bg-indigo-700 text-white p-2 rounded-xl active:scale-90 transition cursor-pointer"
                          >
                            <Send className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </>
                    );
                  })()}
                </div>
              </div>
            )}

            {/* SUBTAB 4: WALLETS AND WITHDRAW REQUESTS */}
            {activeTab === 4 && (
              <div className="flex flex-col gap-4 animate-fade-in text-right font-medium">
                
                {/* Available Balance block & Bank info */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm flex flex-col justify-between relative overflow-hidden">
                    <div className="absolute top-0 left-0 text-7xl select-none opacity-5 -translate-x-3 -translate-y-3">
                      💳
                    </div>
                    <div>
                      <span className="text-[10px] font-black text-slate-400 block mb-1">حمایت از توسعه چندفروشندگی یوزآنلاین</span>
                      <span className="text-[9px] text-slate-500 bg-slate-50 border border-slate-100 px-2 py-0.5 rounded font-black inline-block">صندوق صنف متصل به شبکه شتاب کشور</span>
                    </div>

                    <div className="mt-8">
                      <span className="text-[10px] text-slate-400 font-bold block">مجموع درآمد انبار (موجودی صندوق):</span>
                      <span className="text-xl font-black text-slate-900 font-mono mt-1 block">
                        {formatPrice(shop.balance)} <span className="text-[10px] text-slate-400 font-black">تومان</span>
                      </span>
                    </div>

                    <p className="text-[7.5px] text-slate-400 mt-4 border-t border-slate-50 pt-2.5">
                      درآمدهای حاصل از تسویه تراکنش‌ها پس از تحویل نهایی مرسولات، طبق آیین‌نامه مالی در کمتر از ۲۴ ساعت مستقیماً به کارت بانکی اریک واریز خواهد شد.
                    </p>
                  </div>

                  {/* Registered Bank representation (Card model) */}
                  <div className="bg-gradient-to-r from-teal-800 to-emerald-950 text-white rounded-3xl p-5 shadow-xl flex flex-col justify-between relative overflow-hidden select-none">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full select-none translate-x-5 -translate-y-5"></div>
                    <div className="flex justify-between items-center">
                      <span className="text-[10px] font-black tracking-widest text-emerald-100">یوزآنلاین بانک شتاب</span>
                      <CreditCard className="w-5 h-5 text-emerald-200" />
                    </div>

                    <div className="mt-6">
                      <span className="text-[7px] text-teal-200 uppercase tracking-widest block font-bold">شماره شبای شبکه‌ای (IBAN)</span>
                      <span className="text-[11px] font-bold font-mono tracking-widest block mt-0.5 text-emerald-100">
                        {shop.shaba || 'IR890120000000012345678901'}
                      </span>
                    </div>

                    <div className="flex justify-between items-center mt-6">
                      <div>
                        <span className="text-[6.5px] text-teal-200 block font-semibold">بومی صنف</span>
                        <span className="text-[9px] font-black block text-emerald-100">{shop.name}</span>
                      </div>
                      <span className="text-[9px] text-emerald-200 font-extrabold bg-white/10 px-2 py-0.5 rounded border border-white/5">مرچنت فعال</span>
                    </div>
                  </div>
                </div>

                {/* Submit withdraw payout forms */}
                <form onSubmit={handleWithdrawSubmit} className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm flex flex-col gap-4">
                  <div className="pb-1.5 border-b border-slate-50 mb-1">
                    <span className="text-[10px] font-black text-slate-800">فرم درخواست فوری تسویه صندوق</span>
                    <p className="text-[7.5px] text-slate-400 mt-1">مبلغ مورد نیاز برای واریز به کارت را وارد کنید</p>
                  </div>

                  {withdrawError && (
                    <div className="bg-rose-50 text-rose-600 text-[8px] p-2 rounded-xl border border-rose-100 font-bold text-center">
                      ⚠️ {withdrawError}
                    </div>
                  )}

                  {withdrawSuccess && (
                    <div className="bg-emerald-50 text-emerald-600 text-[8px] p-2.5 rounded-xl border border-emerald-100 font-bold text-center leading-relaxed">
                      🎉 {withdrawSuccess}
                    </div>
                  )}

                  <div className="flex flex-col md:flex-row gap-3">
                    <div className="flex-1">
                      <label className="text-[9.5px] font-black text-slate-700 block mb-1">مبلغ درخواستی تسویه (تومان)</label>
                      <input 
                        type="text"
                        required
                        placeholder="حداکثر معادل موجودی فعلی صندوق..."
                        value={withdrawAmount}
                        onChange={(e) => setWithdrawAmount(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2.5 text-[10px] font-bold rounded-xl text-left font-mono focus:outline-none"
                        dir="ltr"
                      />
                    </div>

                    <button
                      type="submit"
                      className="bg-emerald-600 hover:bg-emerald-700 text-white text-[9.5px] font-black px-6 py-2.5 rounded-xl shadow-md cursor-pointer h-11 flex items-center justify-center gap-1.5 self-end w-full md:w-auto"
                    >
                      ثبت درخواست تسویه و واریز شبا
                    </button>
                  </div>
                </form>

                {/* Historic payout logs */}
                <div className="bg-white border border-slate-100 rounded-3xl p-4 shadow-sm flex flex-col gap-3">
                  <span className="text-[10px] font-black text-slate-800 border-b border-slate-50 pb-2">تاریخچه تراکنش‌های مالی و درخواست‌های تسویه</span>
                  <div className="flex flex-col gap-2">
                    {withdrawRequests.map((req, idx) => (
                      <div key={idx} className="flex items-center justify-between py-2 border-b border-slate-50 last:border-0 text-[8.5px]">
                        <div className="flex flex-col text-right">
                          <span className="font-bold text-slate-800">کدرهگیری: {req.id}</span>
                          <span className="text-[7px] text-slate-400 mt-0.5">تاریخ ثبت: {req.date} | شبا: {req.shaba}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="font-heavy text-slate-900 font-mono">{formatPrice(req.amount)} تومان</span>
                          {req.status === 'PAID' ? (
                            <span className="bg-emerald-50 text-emerald-600 text-[7px] border border-emerald-100 font-black px-2 py-0.5 rounded-full">پرداخت شد</span>
                          ) : req.status === 'REJECTED' ? (
                            <span className="bg-red-50 text-red-600 text-[7px] border border-red-100 font-black px-2 py-0.5 rounded-full">لغو شد</span>
                          ) : (
                            <span className="bg-amber-50 text-amber-600 text-[7px] border border-amber-100 font-black px-2 py-0.5 rounded-full animate-pulse">در انتظار حسابداری</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

              </div>
            )}

            {/* SUBTAB 5: PROFILE SETTINGS & GORGEOUS LOGO MANAGER */}
            {activeTab === 5 && (
              <div className="flex flex-col gap-4 animate-fade-in text-right font-medium">
                
                {/* Logo and banner presets settings */}
                <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm flex flex-col gap-4">
                  <div className="pb-2 border-b border-slate-50 flex items-center justify-between">
                    <span className="text-[10px] font-black text-slate-800">ویرایش تابلوی سردر غرفه و عکس تجاری</span>
                    <Settings className="w-4 h-4 text-emerald-600" />
                  </div>

                  {!isEditingProfile ? (
                    <div className="flex flex-col gap-3">
                      {/* Read only Profile info overview */}
                      <div className="flex gap-4 items-center bg-slate-50 p-4 rounded-2xl border border-slate-100/70">
                        <div className="w-14 h-14 bg-indigo-600/10 text-indigo-700 border border-indigo-100 rounded-full flex items-center justify-center text-3xl select-none shrink-0 shadow-inner">
                          {shop.logo}
                        </div>
                        <div className="flex-1">
                          <h3 className="text-sm font-black text-slate-900">{shop.name}</h3>
                          <span className="text-[8px] bg-indigo-50 border border-indigo-100 text-indigo-600 font-extrabold px-2 py-0.5 rounded-md inline-block mt-1">
                            رنگ قالب بنر: {shop.bannerColor?.includes('emerald') ? 'سبز تیره ارگانیک' : 'آبی روشن زنده'}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[9px] text-slate-600 mt-2 bg-slate-50 p-4 rounded-xl border border-slate-100/70">
                        <div className="flex justify-between border-b border-slate-200/50 pb-1.5 md:col-span-2">
                          <span className="text-slate-400">توضیحات غرفه:</span>
                          <span className="font-bold text-slate-900">{shop.description}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-200/50 pb-1.5 font-bold">
                          <span className="text-slate-400">شماره تماس ثابت:</span>
                          <span className="text-slate-900 font-mono" dir="ltr">{shop.phone}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-200/50 pb-1.5 font-bold">
                          <span className="text-slate-400">صندوق ایمیل غرفه‌داری:</span>
                          <span className="text-slate-900 font-mono" dir="ltr">{shop.email}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-200/50 pb-1.5 font-bold">
                          <span className="text-slate-400">آدرس فیزیکی:</span>
                          <span className="text-slate-900 truncate">{shop.address}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-200/50 pb-1.5 font-bold">
                          <span className="text-slate-400">شناسه مالیاتی شتاب:</span>
                          <span className="text-slate-900 font-mono">#IR-TX-{toPersianDigits(95592)}</span>
                        </div>
                      </div>

                      <button
                        onClick={() => setIsEditingProfile(true)}
                        className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black py-2.5 rounded-2xl cursor-pointer mt-3"
                      >
                        ویرایش پیکربندی و اطلاعات غرفه
                      </button>
                    </div>
                  ) : (
                    /* Profile variables change form */
                    <form onSubmit={handleProfileSave} className="flex flex-col gap-3.5">
                      <div>
                        <label className="text-[10px] font-black text-slate-700 block mb-1">نام غرفه تجاری شما <span className="text-rose-500">*</span></label>
                        <input 
                          type="text" 
                          required
                          value={profName}
                          onChange={(e) => setProfName(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2.5 text-[10px] rounded-xl text-right"
                        />
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <label className="text-[10px] font-black text-slate-700 block mb-1">لوگوی سمبلیک <span className="text-rose-500">*</span></label>
                          <select 
                            value={profLogo}
                            onChange={(e) => setProfLogo(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 px-3 py-2.5 text-[10px] rounded-xl text-right focus:outline-none"
                          >
                            {LOGO_COLLECTION.map(l => (
                              <option key={l.char} value={l.char}>{l.char} {l.label}</option>
                            ))}
                          </select>
                        </div>

                        <div>
                          <label className="text-[10px] font-black text-slate-700 block mb-1">قالب رنگی تابلوی آنلاین <span className="text-rose-500">*</span></label>
                          <select 
                            value={profBanner}
                            onChange={(e) => setProfBanner(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 px-3 py-2.5 text-[10px] rounded-xl text-right focus:outline-none"
                          >
                            <option value="from-emerald-700 to-teal-800">سبز زمردین کلاسیک</option>
                            <option value="from-indigo-700 to-slate-900">آبی یاقوتی عمیق</option>
                            <option value="from-rose-700 to-pink-800">صورتی ارغوانی مدرن</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        <div>
                          <label className="text-[10px] font-black text-slate-700 block mb-1">شماره تلفن غرفه <span className="text-rose-500">*</span></label>
                          <input 
                            type="text" 
                            required
                            value={profPhone}
                            onChange={(e) => setProfPhone(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2.5 text-[10px] rounded-xl text-left font-mono"
                            dir="ltr"
                          />
                        </div>

                        <div>
                          <label className="text-[10px] font-black text-slate-700 block mb-1">ایمیل تجاری</label>
                          <input 
                            type="email" 
                            value={profEmail}
                            onChange={(e) => setProfEmail(e.target.value)}
                            className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2.5 text-[10px] rounded-xl text-left font-mono"
                            dir="ltr"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[10px] font-black text-slate-700 block mb-1">آدرس پستی دقیق انبار مرکزی</label>
                        <input 
                          type="text" 
                          value={profAddress}
                          onChange={(e) => setProfAddress(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2.5 text-[10px] rounded-xl text-right"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-black text-slate-700 block mb-1">شبای بانکی تسویه (IR)</label>
                        <input 
                          type="text" 
                          required
                          value={profShaba}
                          onChange={(e) => setProfShaba(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2.5 text-[10px] rounded-xl text-left font-mono"
                          dir="ltr"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-black text-slate-700 block mb-1">بیوگرافی و شرح برند غرفه آنلاین</label>
                        <textarea 
                          rows={2}
                          value={profDesc}
                          onChange={(e) => setProfDesc(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 px-3.5 py-2 text-[10px] rounded-xl text-right resize-none"
                        />
                      </div>

                      <div className="flex gap-2.5 border-t border-slate-50 pt-3 mt-1">
                        <button
                          type="submit"
                          className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[10px] py-2.5 rounded-xl cursor-pointer font-black transition active:scale-95"
                        >
                          تایید و به‌روزرسانی نهایی پروفایل
                        </button>
                        <button
                          type="button"
                          onClick={() => setIsEditingProfile(false)}
                          className="px-4 py-2 bg-slate-50 text-slate-400 border border-slate-200 rounded-xl text-[9px] hover:bg-slate-100 font-bold"
                        >
                          انصراف
                        </button>
                      </div>
                    </form>
                  )}
                </div>

                {/* Cloud Database replication test block */}
                <div className="bg-white border border-slate-100 rounded-3xl p-5 shadow-sm">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2.5 mb-2">
                    <span className="text-[10px] font-black text-slate-800">پشتیبانی پایگاه داده ابری و هسته Hilt</span>
                    <RefreshCw className="w-4 h-4 text-slate-500" />
                  </div>
                  
                  <p className="text-[8.5px] text-slate-400 leading-relaxed mb-3">
                    کنسول فروشندگی شما از معماری چندلایه کاملاً ساختاریافته بهره‌مند است که همگام‌سازی ابری سفارش صنف را با سرعت تراکنش بالا در دیتابیس لوکال تست شبیه‌سازی می‌کند.
                  </p>

                  <button
                    onClick={() => {
                      addLog('REPOSITORY', 'همگام‌سازی ابری فروشگاه فراخوانی شد', shop.name);
                      addLog('DATASOURCE', 'همدردی پایگاه داده اتاق (Room Cache Database Sync)', `شناسه برند: ${shop.name}`);
                    }}
                    className="w-full bg-slate-50 text-slate-600 hover:bg-slate-100 border border-slate-200/80 text-[10px] font-heavy py-2 rounded-2xl flex items-center justify-center gap-2 transition active:scale-95"
                  >
                    انجام تست همگام‌سازی جداول لوکال با دیتابیس ابری یوزآنلاین
                  </button>
                </div>

              </div>
            )}

          </div>

          {/* Dynamic Product editor Modal overlay wrapper */}
          {editingProduct && (
            <div className="absolute inset-0 bg-slate-950/80 flex items-center justify-center z-50 p-4 backdrop-blur-xs" id="product-editor-modal">
              <div className="bg-white border border-slate-200 rounded-3xl w-full max-w-sm p-5 text-right overflow-y-auto max-h-[96%]" dir="rtl">
                <div className="pb-2 border-b border-slate-100 flex items-center justify-between mb-3.5">
                  <span className="text-[11px] font-black text-slate-950">ویرایش پرونده شناسنامه کالا</span>
                  <button
                    onClick={() => setEditingProduct(null)}
                    className="text-slate-400 hover:text-slate-600 font-black text-[15px] cursor-pointer"
                  >
                    ×
                  </button>
                </div>

                {editError && (
                  <div className="bg-rose-50 text-rose-600 text-[8.5px] p-2 rounded-xl mb-3 border border-rose-100 text-center font-bold">
                    ⚠️ {editError}
                  </div>
                )}

                <form onSubmit={handleSaveEditedProduct} className="flex flex-col gap-3">
                  <div>
                    <label className="text-[9px] font-black text-slate-700 block mb-1">نام اختصاصی فارسی محصول (ستاره‌دار)</label>
                    <input
                      type="text"
                      required
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-100 px-3 py-2 text-[9.5px] rounded-xl"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[9px] font-black text-slate-700 block mb-1">مدل لاتین کالا</label>
                      <input
                        type="text"
                        value={editEngTitle}
                        onChange={(e) => setEditEngTitle(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-100 px-3 py-2 text-[9px] rounded-xl text-left font-mono"
                        dir="ltr"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-black text-slate-700 block mb-1">دسته‌بندی</label>
                      <select
                        value={editCategory}
                        onChange={(e) => setEditCategory(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-100 px-2.5 py-2 text-[9px] rounded-xl text-right focus:outline-none"
                      >
                        <option value="phones">گوشی موبایل</option>
                        <option value="laptops">لپ‌تاپ و تبلت</option>
                        <option value="audio">هدفون و پخش‌صوت</option>
                        <option value="shoes">کفش و کتانی ورزش</option>
                        <option value="kitchen">لوازم آشپزخانه</option>
                        <option value="perfume">عطر و ادکلن</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[9px] font-black text-slate-700 block mb-1">قیمت نقدی (تومان)</label>
                      <input
                        type="text"
                        required
                        value={editPrice}
                        onChange={(e) => setEditPrice(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-100 px-3 py-2 text-[9.5px] rounded-xl text-center font-mono font-bold"
                      />
                    </div>
                    <div>
                      <label className="text-[9px] font-black text-slate-700 block mb-1">موجود انبار</label>
                      <input
                        type="number"
                        required
                        min={0}
                        value={editStock}
                        onChange={(e) => setEditStock(parseInt(e.target.value, 10) || 0)}
                        className="w-full bg-slate-50 border border-slate-100 px-3 py-2 text-[9.5px] rounded-xl text-center font-mono font-bold"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[9px] font-black text-slate-700 block mb-1">آدرس عکس کالا (URL)</label>
                    <input
                      type="url"
                      required
                      value={editImgUrl}
                      onChange={(e) => setEditImgUrl(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-100 px-3 py-1.5 text-[8.5px] rounded-xl text-left font-mono"
                      dir="ltr"
                    />

                    {/* Preselected alternative presets */}
                    <div className="flex gap-1 overflow-x-auto py-1 mt-1.5 scrollbar-thin">
                      {(PRODUCT_IMAGE_PRESETS[editCategory] || PRODUCT_IMAGE_PRESETS['default']).map((p, pIdx) => (
                        <button
                          key={pIdx}
                          type="button"
                          onClick={() => setEditImgUrl(p.url)}
                          className={`text-[6.5px] font-black border px-2 py-0.5 rounded-lg whitespace-nowrap active:scale-95 transition ${
                            editImgUrl === p.url ? 'bg-indigo-50 border-indigo-400 text-indigo-700' : 'bg-slate-50 border-slate-100 text-slate-400'
                          }`}
                        >
                          {p.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Edit Variants options */}
                  <div className="bg-slate-50 border border-slate-100 p-2.5 rounded-2xl flex flex-col gap-2">
                    <span className="text-[8px] font-black text-slate-800">تنوع مشخصات فنی این کالا</span>
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        placeholder="مثال: گارانتی"
                        value={editVarKey}
                        onChange={(e) => setEditVarKey(e.target.value)}
                        className="flex-1 bg-white border border-slate-100 px-2 py-1 text-[8px] rounded"
                      />
                      <input
                        type="text"
                        placeholder="مثال: ۱۸ ماه پارس"
                        value={editVarVal}
                        onChange={(e) => setEditVarVal(e.target.value)}
                        className="flex-1 bg-white border border-slate-100 px-2 py-1 text-[8px] rounded"
                      />
                      <button
                        type="button"
                        onClick={() => {
                          if (editVarKey.trim() && editVarVal.trim()) {
                            setEditVariants(p => [...p, { name: editVarKey.trim(), value: editVarVal.trim() }]);
                            setEditVarKey('');
                            setEditVarVal('');
                          }
                        }}
                        className="bg-indigo-600 font-extrabold text-[8px] text-white px-2 rounded cursor-pointer"
                      >
                        درج
                      </button>
                    </div>

                    {editVariants.length > 0 && (
                      <div className="flex flex-wrap gap-1 max-h-16 overflow-y-auto font-bold mt-1">
                        {editVariants.map((v, idx) => (
                          <span key={idx} className="bg-white border border-slate-200 text-[6.5px] text-slate-500 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                            {v.name}: {v.value}
                            <button
                              type="button"
                              onClick={() => setEditVariants(p => p.filter((_, i) => i !== idx))}
                              className="text-red-500 font-black hover:text-red-700 text-[95px] shrink-0 cursor-pointer"
                            >
                              ×
                            </button>
                          </span>
                        ))}
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="text-[9px] font-black text-slate-700 block mb-1">نام یا چکیده نقد و بررسی محصول</label>
                    <textarea
                      rows={2}
                      value={editDesc}
                      onChange={(e) => setEditDesc(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-100 px-3 py-1.5 text-[9px] rounded-xl resize-none"
                    />
                  </div>

                  <div className="flex gap-2.5 border-t border-slate-50 pt-3.5 mt-1">
                    <button
                      type="submit"
                      className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white text-[9.5px] py-2.5 rounded-xl cursor-pointer font-black transition active:scale-95"
                    >
                      تایید دگرگونی و ارتقا
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditingProduct(null)}
                      className="px-4 py-2 border border-slate-200 text-slate-400 rounded-xl text-[9px]"
                    >
                      انصراف
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}

        </div>
      )}

    </div>
  );
}
