import React, { useState, useEffect, useMemo } from 'react';
import { 
  CreditCard, 
  Wallet, 
  ArrowLeft, 
  CheckCircle2, 
  XCircle, 
  RefreshCw, 
  History, 
  ShieldCheck, 
  Cpu, 
  CornerDownLeft, 
  Clock, 
  Send, 
  AlertTriangle, 
  Download, 
  Info,
  ExternalLink,
  ChevronRight,
  UserCheck,
  Search,
  Filter
} from 'lucide-react';
import { PaymentManager, createDefaultPaymentManager } from '../../services/payment/paymentService';
import { PaymentMethodInfo, PaymentSession, PaymentTransaction } from '../../services/payment/types';
import { CartItem, Order, ArchLog } from '../../types';

interface PaymentHubProps {
  amount: number;
  orderId: string;
  onPaymentSuccess: (transaction: PaymentTransaction) => void;
  onPaymentCancel: () => void;
  addLog: (layer: ArchLog['layer'], message: string, details: string) => void;
  // Optional parameters for direct transaction history viewer
  historyModeOnly?: boolean;
}

export function PaymentHub({
  amount,
  orderId,
  onPaymentSuccess,
  onPaymentCancel,
  addLog,
  historyModeOnly = false,
}: PaymentHubProps) {
  // Initialize dependency-injected payment manager
  const paymentManager = useMemo(() => {
    return createDefaultPaymentManager(addLog);
  }, [addLog]);

  const PersianDigits = (num: number | string) => {
    const p = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/[0-9]/g, (w) => p[+w]);
  };

  const formatPrice = (price: number) => {
    const formatted = price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return PersianDigits(formatted);
  };

  // State
  const [paymentStep, setPaymentStep] = useState<'SELECT_METHOD' | 'SANDBOX_GATEWAY' | 'STATUS_SCREEN' | 'HISTORY_VIEW'>(
    historyModeOnly ? 'HISTORY_VIEW' : 'SELECT_METHOD'
  );
  
  const [supportedMethods, setSupportedMethods] = useState<PaymentMethodInfo[]>([]);
  const [selectedMethodId, setSelectedMethodId] = useState<string>('zarinpal');
  const [paymentSession, setPaymentSession] = useState<PaymentSession | null>(null);
  const [currentTransaction, setCurrentTransaction] = useState<PaymentTransaction | null>(null);
  
  // Sandbox Card State
  const [cardNumber, setCardNumber] = useState('');
  const [cvv2, setCvv2] = useState('');
  const [expiryMonth, setExpiryMonth] = useState('');
  const [expiryYear, setExpiryYear] = useState('');
  const [staticPin, setStaticPin] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpSeconds, setOtpSeconds] = useState(120);
  const [simulatedOtp, setSimulatedOtp] = useState('');
  const [verifyMode, setVerifyMode] = useState<'SUCCESS' | 'FAIL' | 'CANCEL'>('SUCCESS');
  const [sandboxError, setSandboxError] = useState('');
  const [isProcessingVerify, setIsProcessingVerify] = useState(false);

  // OTP Toast Simulator
  const [otpNotification, setOtpNotification] = useState<string | null>(null);

  // History states
  const [transactions, setTransactions] = useState<PaymentTransaction[]>([]);
  const [searchHistory, setSearchHistory] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [refundDialogTxn, setRefundDialogTxn] = useState<PaymentTransaction | null>(null);
  const [refundReason, setRefundReason] = useState('');
  const [isProcessingRefund, setIsProcessingRefund] = useState(false);
  const [refundError, setRefundError] = useState('');

  // Auto load gateways
  useEffect(() => {
    setSupportedMethods(paymentManager.getSupportedMethods());
    setTransactions(paymentManager.getTransactions());
  }, [paymentManager]);

  // Expiry / Countdown timer inside sandbox gateway
  useEffect(() => {
    let interval: any;
    if (otpSent && otpSeconds > 0) {
      interval = setInterval(() => {
        setOtpSeconds((prev) => prev - 1);
      }, 1000);
    } else if (otpSeconds === 0) {
      setOtpSent(false);
    }
    return () => clearInterval(interval);
  }, [otpSent, otpSeconds]);

  // Clean OTP notification after 5 seconds
  useEffect(() => {
    if (otpNotification) {
      const t = setTimeout(() => {
        setOtpNotification(null);
      }, 7000);
      return () => clearTimeout(t);
    }
  }, [otpNotification]);

  // Method details dictionary
  const selectedMethod = useMemo(() => {
    return supportedMethods.find(m => m.id === selectedMethodId);
  }, [supportedMethods, selectedMethodId]);

  /**
   * Action: Start the secure payment tunnel (initialize payment session)
   */
  const handleInitiatePayment = async () => {
    try {
      addLog('UI', `تایید روش پرداخت و ایجاد تراکنش معلق شتاب`, `درگاه: ${selectedMethodId}`);
      
      const session = await paymentManager.checkout(amount, orderId, selectedMethodId);
      
      setPaymentSession(session);
      
      // Look up generated pending transaction
      const liveTxns = paymentManager.getTransactions();
      const currentTxn = liveTxns.find(t => t.token === session.token);
      setCurrentTransaction(currentTxn || null);
      
      // Reset card form parameters
      setCardNumber('');
      setCvv2('');
      setExpiryMonth('');
      setExpiryYear('');
      setStaticPin('');
      setOtpCode('');
      setOtpSent(false);
      setSandboxError('');
      setPaymentStep('SANDBOX_GATEWAY');
      
      addLog('VIEWMODEL', 'بارگذاری صفحه ارجاع امن درگاه سیمولاتور هوشمند', `مک‌آدرس توکن: ${session.token}`);
    } catch (err: any) {
      addLog('REPOSITORY', 'خطا در ثبت توکن تراکنش به لایه پایگاه‌داده', err.message || 'Error init');
      alert('متاسفانه در بارگذاری درگاه خطا رخ داد. لطفا دوباره تلاش کنید.');
    }
  };

  /**
   * Action: Mock Request OTP SMS code
   */
  const handleRequestOtp = () => {
    if (cardNumber.length < 16) {
      setSandboxError('لطفاً شماره کارت ۱۶ رقمی معتبر بانکی را وارد کنید.');
      return;
    }
    setSandboxError('');
    const randomOtp = Math.floor(100000 + Math.random() * 900000).toString();
    setSimulatedOtp(randomOtp);
    setOtpSent(true);
    setOtpSeconds(120);
    
    addLog('DATASOURCE', 'فراخوانی وب‌سرویس پویای رمزنگاری شاهکار/شتاب (OTP SMS Request)', `توکن: ${paymentSession?.token}`);

    // Trigger visual notification toast to help sandboxed simulator users check SMS instantly
    setOtpNotification(`📢 پیامک شتاب: رمز دوم پویای شما برای تراکنش یوزآنلاین: ${PersianDigits(randomOtp)} می‌باشد. (معتبر تا ۲ دقیقه)`);
  };

  /**
   * Action: Submit Card details and verify transaction
   */
  const handleVerifySubmission = async () => {
    if (!paymentSession || !currentTransaction) return;

    // Direct gateway banks require basic validations to demonstrate real security simulation
    if (selectedMethod?.type === 'BANK' || selectedMethod?.type === 'GATEWAY') {
      if (cardNumber.replace(/\D/g, '').length < 16) {
        setSandboxError('شماره کارت ۱۶ رقمی نامعتبر است.');
        return;
      }
      if (cvv2.length < 3) {
        setSandboxError('کد امنیتی CVV2 نامعتبر است.');
        return;
      }
      if (!expiryMonth || !expiryYear) {
        setSandboxError('تاریخ انقضای کارت معتبر نیست.');
        return;
      }
      if (otpSent && otpCode !== simulatedOtp) {
        setSandboxError('کد رمز پویا اشتباه است. لطفاً کد پیامک شده را وارد کنید.');
        return;
      }
    }

    setSandboxError('');
    setIsProcessingVerify(true);

    try {
      addLog('USECASE', 'ارسال درخواست امضا به توزیع‌کننده واسط پایانه بانکی', `تایید و صحت‌سنجی: ${currentTransaction.id}`);
      
      const finishedTxn = await paymentManager.verify(currentTransaction.id, verifyMode);
      
      setCurrentTransaction(finishedTxn);
      setTransactions(paymentManager.getTransactions());
      setPaymentStep('STATUS_SCREEN');
      
      if (finishedTxn.status === 'SUCCESSFUL') {
        addLog('UI', 'انتقال موفق به برگه پرداختی و صدور فاکتور الکترونیکی', `تراکنش تأیید شد: ${finishedTxn.id}`);
      } else {
        addLog('UI', 'ثبت خطای ناموفق روی تراکنش در فریم‌ورک سیمولاتور', `دلیل: ${finishedTxn.errorMessage}`);
      }
    } catch (e: any) {
      setSandboxError(e.message || 'خطا در ارزیابی تاییدیه شتاب');
    } finally {
      setIsProcessingVerify(false);
    }
  };

  /**
   * Action: Cancel on Gateway Page
   */
  const handleCancelGateway = async () => {
    if (!currentTransaction) {
      onPaymentCancel();
      return;
    }
    
    setIsProcessingVerify(true);
    addLog('UI', 'کاربر دکمه انصراف در درگاه شاپور بانک را فشرد', `ابطال تراکنش: ${currentTransaction.id}`);
    
    try {
      const canceledTxn = await paymentManager.verify(currentTransaction.id, 'CANCEL');
      setCurrentTransaction(canceledTxn);
      setTransactions(paymentManager.getTransactions());
      setPaymentStep('STATUS_SCREEN');
    } catch (err) {
      onPaymentCancel();
    } finally {
      setIsProcessingVerify(false);
    }
  };

  /**
   * Action: Refund Dialog and submit refund request
   */
  const handleRequestRefund = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!refundDialogTxn) return;
    if (!refundReason.trim()) {
      setRefundError('لطفاً دلیل استرداد وجه را توضیح دهید.');
      return;
    }

    setIsProcessingRefund(true);
    setRefundError('');
    try {
      addLog('UI', `اقدام مدیریت جهت استرداد وجه سفارش به مشتری`, `سفارش: ${refundDialogTxn.orderId}`);
      
      const updatedTxn = await paymentManager.refund(refundDialogTxn.id, refundReason);
      
      setTransactions(paymentManager.getTransactions());
      addLog('DATASOURCE', 'جدول مالی به‌روزرسانی شد (UPDATE payment_transactions SET status=REFUNDED)', updatedTxn.id);
      
      // Success Alert
      alert(`مبلغ ${formatPrice(updatedTxn.amount)} تومان با موفقیت به مبدأ غرفه‌دار و کیف پول کاربر بازگشت داده شد.`);
      setRefundDialogTxn(null);
      setRefundReason('');
    } catch (err: any) {
      setRefundError(err.message || 'خطا در استرداد تراکنش');
    } finally {
      setIsProcessingRefund(false);
    }
  };

  // Filter and search transactions
  const filteredTransactions = useMemo(() => {
    return transactions.filter(t => {
      const matchesSearch = t.id.toLowerCase().includes(searchHistory.toLowerCase()) || 
                            t.orderId.toLowerCase().includes(searchHistory.toLowerCase()) ||
                            (t.refId && t.refId.toLowerCase().includes(searchHistory.toLowerCase()));
      
      if (filterStatus === 'ALL') return matchesSearch;
      return matchesSearch && t.status === filterStatus;
    });
  }, [transactions, searchHistory, filterStatus]);

  return (
    <div className="flex flex-col h-full bg-slate-50 font-vazir text-right" dir="rtl" id="payment-architecture-module">
      
      {/* Dynamic OTP Alert Toast Simulator */}
      {otpNotification && (
        <div className="fixed top-14 left-4 right-4 z-50 bg-slate-900 text-white rounded-xl p-3.5 shadow-2xl border border-blue-500/30 text-xs animate-bounce leading-relaxed select-none">
          <div className="flex items-start gap-2.5">
            <span className="text-lg">💬</span>
            <div className="flex-1">
              <span className="font-extrabold text-blue-400 block mb-1">سیستم شبیه‌ساز بانک مرکزی (بانک همتا)</span>
              <p className="font-mono text-[11px] text-gray-200">{otpNotification}</p>
            </div>
            <button 
              className="text-gray-400 hover:text-white font-extrabold px-1"
              onClick={() => setOtpNotification(null)}
            >
              ×
            </button>
          </div>
        </div>
      )}

      {/* -------------------- STEP 1: METHOD SELECTION -------------------- */}
      {paymentStep === 'SELECT_METHOD' && (
        <div className="flex flex-col h-full overflow-hidden pb-16">
          <div className="bg-white border-b border-gray-100 px-4 py-3.5 flex items-center justify-between shadow-sm shrink-0">
            <div className="flex items-center gap-2">
              <div className="bg-blue-600/10 p-1.5 rounded-lg">
                <CreditCard className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <h2 className="text-xs font-black text-gray-900 leading-tight">انتخاب شیوه پرداخت</h2>
                <span className="text-[9px] text-gray-400 font-semibold block mt-0.5">زیرسیستم امن تراکنش‌های مالی یوزآنلاین</span>
              </div>
            </div>
            <button
              onClick={() => {
                addLog('UI', 'انصراف کاربر در مرحله انتخاب شیوه پرداخت', 'خروج');
                onPaymentCancel();
              }}
              className="text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1 font-extrabold py-1 px-2 rounded-lg hover:bg-slate-50 transition"
            >
              انصراف
              <ArrowLeft className="w-3.5 h-3.5 scale-x-[-1]" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-4">
            
            {/* Quick summary invoice */}
            <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm flex flex-col gap-2 relative overflow-hidden">
              <div className="absolute top-0 left-0 bg-blue-600 text-white font-mono text-[8px] px-2.5 py-0.5 rounded-br-2xl">
                ORDER: {orderId}
              </div>
              <span className="text-[10px] text-gray-400 font-bold block">مبلغ فاکتور خرید بازارچه</span>
              <div className="flex justify-between items-center mt-1">
                <div className="flex items-baseline gap-1">
                  <span className="text-lg font-black text-blue-600">{formatPrice(amount)}</span>
                  <span className="text-[10px] text-gray-400 font-bold">تومان</span>
                </div>
                <div className="bg-emerald-500/10 text-emerald-600 font-bold text-[9px] px-2.5 py-1 rounded-full flex items-center gap-1 border border-emerald-500/10">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  اتصال رمزگذاری‌شده SSL
                </div>
              </div>
            </div>

            <h3 className="text-[11px] font-black text-gray-800 flex items-center gap-1.5 px-1">
              <Wallet className="w-4 h-4 text-emerald-500" />
              لطفاً یکی از ۷ گیت‌وی/بستر زیر را انتخاب نمایید:
            </h3>

            {/* List of 7 Payment Methods with customized visual hierarchy */}
            <div className="flex flex-col gap-2.5">
              {supportedMethods.map((method) => {
                const isSelected = selectedMethodId === method.id;
                return (
                  <button
                    key={method.id}
                    onClick={() => setSelectedMethodId(method.id)}
                    className={`text-right p-3.5 rounded-2xl border-2 flex gap-3 items-start transition duration-200 cursor-pointer ${
                      isSelected 
                        ? 'bg-blue-50/40 border-blue-600 shadow-sm shadow-blue-100' 
                        : 'bg-white border-gray-100 hover:border-gray-200 shadow-xs'
                    }`}
                  >
                    {/* Method Icon Ring */}
                    <div className={`w-10 h-10 rounded-xl shrink-0 flex items-center justify-center text-xl shadow-xs transition-transform ${
                      isSelected ? 'scale-110' : ''
                    } ${method.accentColor}`}>
                      {method.logo}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <span className={`text-[10px] font-black leading-none ${
                          isSelected ? 'text-blue-700' : 'text-gray-900'
                        }`}>
                          {method.name}
                        </span>
                        
                        {/* Custom visual badge per type */}
                        <span className="text-[8px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-slate-100 text-gray-500 border border-slate-200">
                          {method.type === 'GATEWAY' && 'درگاه مستقیم واسط'}
                          {method.type === 'INSTALLMENT' && 'قسطی / اعتباری'}
                          {method.type === 'WALLET' && 'کیف پول شارژی'}
                          {method.type === 'BANK' && 'پایانه بانک عضو شتاب'}
                        </span>
                      </div>
                      
                      <p className="text-[9px] text-gray-400 mt-1.5 leading-relaxed font-medium">
                        {method.description}
                      </p>

                      {/* Display custom simulated specs for SnappPay and Tara */}
                      {isSelected && method.id === 'snapppay' && (
                        <div className="mt-2.5 bg-emerald-500/5 rounded-xl border border-emerald-500/10 p-2 text-[8.5px] text-emerald-700 leading-normal gap-1.5 flex flex-col">
                          <strong>📊 محاسبه خودکار اقساط ماهیانه:</strong>
                          <div className="grid grid-cols-2 gap-2 mt-0.5 font-mono">
                            <div className="bg-white/80 p-1.5 rounded-lg border border-emerald-500/10">
                              قسط اول (امروز): <strong>{formatPrice(Math.round(amount / 4))} تومان</strong>
                            </div>
                            <div className="bg-white/80 p-1.5 rounded-lg border border-emerald-500/10">
                              ۳ قسط باقی‌مانده: <strong>ماهانه {formatPrice(Math.round(amount / 4))}</strong>
                            </div>
                          </div>
                        </div>
                      )}

                      {isSelected && method.id === 'tara' && (
                        <div className="mt-2.5 bg-violet-500/5 rounded-xl border border-violet-500/10 p-2 text-[8.5px] text-violet-700 leading-normal gap-1 flex flex-col">
                          <span>💼 طرح سازمانی تارا: کسر مستقیم از فیش حقوقی با ۱۰٪ تخفیف مازاد بازارچه</span>
                        </div>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Dependency Injection & Architecture Spec Badge */}
            <div className="bg-slate-100/80 rounded-2xl p-3 border border-slate-200 text-[9px] text-gray-500 leading-relaxed flex items-start gap-2.5">
              <Cpu className="w-5 h-5 text-gray-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-gray-700 block">ساختار معماری پاک (Clean Payment Gateway DI):</strong>
                سیستم با بهره‌جستن از رابطه قراردادی <code>IPaymentGateway</code>، هر ۷ درگاه غرفه و پرداخت را به صورت سرویس‌های تزریق‌شده (IoC) مدیریت می‌کند. توکن صادر شده در سطح دیتاسورس رمزگذاری مضاعف می‌گردد.
              </div>
            </div>

          </div>

          <div className="bg-white border-t border-gray-100 p-3 flex gap-2 shadow-md hover:shadow-lg shrink-0">
            <button
              onClick={() => setPaymentStep('HISTORY_VIEW')}
              className="bg-slate-100 hover:bg-slate-200 text-gray-700 p-3 rounded-xl flex items-center justify-center gap-1.5 transition active:scale-95 text-[10px] font-black"
            >
              <History className="w-4 h-4 text-gray-500" />
              سوابق مالی
            </button>

            <button
              onClick={handleInitiatePayment}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-xl flex items-center justify-center gap-2 shadow-md shadow-blue-100 transition duration-200 active:scale-[0.98] text-[10px] font-black leading-none"
            >
              ادامه و انتقال به پایانه {selectedMethod?.name.split(' (')[0]}
              <ChevronRight className="w-4 h-4 text-white scale-x-[-1]" />
            </button>
          </div>
        </div>
      )}

      {/* -------------------- STEP 2: SANDBOX BANKING GATEWAY -------------------- */}
      {paymentStep === 'SANDBOX_GATEWAY' && paymentSession && (
        <div className="flex flex-col h-full bg-[#e1e2e6] overflow-y-auto font-sans text-right select-none pb-12" id="sandbox-shaparak-gateway">
          
          {/* PSP Top Header Bar */}
          <div className="bg-[#4d2222] text-[#ffdfdf] px-4 py-3 flex items-center justify-between shadow">
            <div className="flex items-center gap-2">
              <div className="bg-red-500 w-3 h-3 rounded-full animate-ping" />
              <div className="font-extrabold text-[11px] font-mono leading-none tracking-widest text-[#ffdfdf]">
                SADAD / BEHPARDAKHT MERCH SERVICES
              </div>
            </div>
            <div className="text-[10px] text-right font-black flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              پایانه امن شتاب (شبیه‌ساز)
            </div>
          </div>

          <div className="bg-white shadow px-4 py-3 flex justify-between items-center text-xs text-gray-600 border-b border-gray-200">
            <div className="flex items-center gap-1 text-[11px]">
              <span className="font-bold text-gray-800">پذیرنده سفارش:</span>
              <span className="text-blue-700 font-extrabold">بازارچه مرکزی یوزآنلاین (UseOnline)</span>
            </div>
            <div className="text-[11px] flex items-center gap-1 font-mono">
              <span className="font-extrabold text-red-600 underline">مبلغ تراکنش:</span>
              <span className="text-gray-900 font-extrabold">{formatPrice(paymentSession.amount)} تومان</span>
            </div>
          </div>

          <div className="p-4 flex flex-col gap-4">
            
            {/* Gateway Handshake diagnostics logs */}
            <div className="bg-slate-900 text-slate-300 p-3 rounded-xl border border-slate-800 text-[9.5px] leading-relaxed font-mono">
              <div className="flex items-center justify-between border-b border-slate-800 pb-1 mb-1.5 text-blue-400 font-bold">
                <span>🔐 هندشیک امن درگاه (Secure Session Key)</span>
                <span>STATE: IN_PROGRESS</span>
              </div>
              <div className="grid grid-cols-1 gap-1">
                <div>TOKEN_SECRET: <span className="text-yellow-400 font-extrabold">{paymentSession.token}</span></div>
                <div>AUTHORITY_KEY: <span className="text-emerald-400 font-bold">{paymentSession.authority}</span></div>
                <div>REDIRECT_LOC: <span className="text-gray-400 truncate block text-[8px]">{paymentSession.actionUrl}</span></div>
              </div>
            </div>

            {/* Simulated Checkout Card Input */}
            <div className="bg-white rounded-2xl shadow-md border border-gray-200 overflow-hidden">
              <div className="bg-slate-50 border-b border-gray-100 p-3 flex justify-between items-center">
                <span className="text-xs font-black text-gray-900">مشخصات کارت بانکی عضو شتاب را وارد نمایید</span>
                <span className="text-[8px] font-bold text-gray-400">SESSION ID: {currentTransaction?.id}</span>
              </div>

              <div className="p-4 flex flex-col gap-3">
                
                {/* Simulated testing mode picker to test failure resilience */}
                <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-2.5">
                  <span className="text-[9.5px] font-extrabold text-amber-800 block mb-1">🧪 شبیه‌ساز سناریوی تراکنش (انتخاب با شما):</span>
                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setVerifyMode('SUCCESS');
                        addLog('UI', 'تغییر فرضی خروجی شبیه‌ساز به: تراکنش موفق', 'کارت معتبر');
                      }}
                      className={`py-1.5 px-2 rounded-lg text-[9px] font-bold transition flex items-center justify-center gap-1 ${
                        verifyMode === 'SUCCESS' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-gray-600 hover:bg-slate-200'
                      }`}
                    >
                      <CheckCircle2 className="w-3 h-3" />
                      تراکنش موفق
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setVerifyMode('FAIL');
                        addLog('UI', 'تغییر فرضی خروجی شبیه‌ساز به: خطای شبکه', 'کارت منقضی / مسدودی');
                      }}
                      className={`py-1.5 px-2 rounded-lg text-[9px] font-bold transition flex items-center justify-center gap-1 ${
                        verifyMode === 'FAIL' ? 'bg-red-600 text-white' : 'bg-slate-100 text-gray-600 hover:bg-slate-200'
                      }`}
                    >
                      <AlertTriangle className="w-3 h-3" />
                      خطای سیستمی
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setVerifyMode('CANCEL');
                        addLog('UI', 'تغییر فرضی خروجی شبیه‌ساز به: انصراف خریدار', 'زدن دکمه لغو');
                      }}
                      className={`py-1.5 px-2 rounded-lg text-[9px] font-bold transition flex items-center justify-center gap-1 ${
                        verifyMode === 'CANCEL' ? 'bg-amber-600 text-white' : 'bg-slate-100 text-gray-600 hover:bg-slate-200'
                      }`}
                    >
                      <XCircle className="w-3 h-3" />
                      انصراف کاربر
                    </button>
                  </div>
                </div>

                {/* Card Number Field */}
                <div>
                  <label className="text-[10px] font-extrabold text-gray-700 block mb-1">شماره ۱۶ رقمی کارت بانکی</label>
                  <div className="relative">
                    <input
                      type="text"
                      maxLength={16}
                      placeholder="۶۰۳۷۹۹۱۸۲۷۳۶۴۵۱۸"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value.replace(/\D/g, ''))}
                      className="w-full text-center tracking-widest font-mono text-sm bg-slate-50 border border-gray-300 rounded-xl py-2.5 focus:outline-none focus:border-red-600 font-bold focus:bg-white"
                    />
                    <CreditCard className="w-4 h-4 text-gray-400 absolute left-3 top-3.5" />
                  </div>
                </div>

                {/* CVV2 and Expiration Month/Year */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-extrabold text-gray-700 block mb-1">کد امنیتی CVV2</label>
                    <input
                      type="password"
                      maxLength={4}
                      placeholder="۴۱۲"
                      value={cvv2}
                      onChange={(e) => setCvv2(e.target.value.replace(/\D/g, ''))}
                      className="w-full text-center tracking-wider font-mono text-xs bg-slate-50 border border-gray-300 rounded-xl py-2 focus:outline-none focus:border-red-600 font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-extrabold text-gray-700 block mb-1">تاریخ انقضاء (ماه / سال)</label>
                    <div className="flex gap-1.5">
                      <input
                        type="text"
                        maxLength={2}
                        placeholder="ما"
                        value={expiryMonth}
                        onChange={(e) => setExpiryMonth(e.target.value.replace(/\D/g, ''))}
                        className="w-1/2 text-center font-mono text-xs bg-slate-50 border border-gray-300 rounded-xl py-2 focus:outline-none focus:border-red-600"
                      />
                      <input
                        type="text"
                        maxLength={2}
                        placeholder="سا"
                        value={expiryYear}
                        onChange={(e) => setExpiryYear(e.target.value.replace(/\D/g, ''))}
                        className="w-1/2 text-center font-mono text-xs bg-slate-50 border border-gray-300 rounded-xl py-2 focus:outline-none focus:border-red-600"
                      />
                    </div>
                  </div>
                </div>

                {/* OTP SMS Request Simulator Field */}
                <div className="border-t border-gray-100 pt-3 relative">
                  <label className="text-[10px] font-extrabold text-gray-700 block mb-1">رمز اینترنتی (رمز پویا)</label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      maxLength={6}
                      placeholder="رمز دریافت شده با پیامک"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                      className="flex-1 text-center font-mono text-xs bg-slate-50 border border-gray-300 rounded-xl py-2 focus:outline-none focus:border-red-600"
                    />
                    <button
                      type="button"
                      onClick={handleRequestOtp}
                      disabled={otpSent}
                      className={`px-3.5 py-2 text-[9px] font-black rounded-xl transition flex items-center justify-center gap-1 ${
                        otpSent 
                          ? 'bg-gray-100 text-gray-400 cursor-not-allowed' 
                          : 'bg-red-600 hover:bg-red-700 text-white shadow-xs'
                      }`}
                    >
                      <Send className="w-3 h-3" />
                      {otpSent ? `ارسال مجدد (${otpSeconds} ثانیه)` : 'درخواست رمز پویا'}
                    </button>
                  </div>
                </div>

                {sandboxError && (
                  <p className="text-[10px] font-extrabold text-red-600 bg-red-50 p-2 rounded-lg border border-red-200 mt-1 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 animate-pulse" />
                    {sandboxError}
                  </p>
                )}

              </div>
            </div>

            {/* Sandbox Operations Action Footer */}
            <div className="flex gap-2">
              <button
                type="button"
                onClick={handleCancelGateway}
                disabled={isProcessingVerify}
                className="w-1/3 py-2.5 bg-gray-400 hover:bg-gray-500 text-white text-[10px] font-extrabold rounded-xl transition duration-150 active:scale-95"
              >
                انصراف و بازگشت
              </button>

              <button
                type="button"
                onClick={handleVerifySubmission}
                disabled={isProcessingVerify}
                className="flex-1 py-2.5 bg-[#4d2222] hover:bg-[#5b2a2a] text-[#ffdfdf] text-[10px] font-black rounded-xl transition duration-150 active:scale-95 flex items-center justify-center gap-1.5"
              >
                {isProcessingVerify ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    صحت‌سنجی تراکنش مالی...
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    تسویه نهایی شتاب و کسر وجه
                  </>
                )}
              </button>
            </div>

            {/* Shaparak Security notice */}
            <div className="p-3 bg-gray-100 rounded-xl border border-gray-200 text-[9px] text-gray-500 leading-normal flex items-start gap-2">
              <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <strong className="text-gray-700">راهنمای امنیت شتاب:</strong>
                شماره کارت و مشخصات ورودی در این سناریو به صورت نمونه جهت آزمایش کامل پورتال آماده شده و از اتصال به حساب‌های واقعی مستثنی است. توکن تایید و رهگیری بلافاصله رمزنگاری کریپتوگرافیک می‌گردد.
              </div>
            </div>

          </div>
        </div>
      )}

      {/* -------------------- STEP 3: TRANSACTION STATUS SCREEN -------------------- */}
      {paymentStep === 'STATUS_SCREEN' && currentTransaction && (
        <div className="flex-1 overflow-y-auto px-4 py-8 flex flex-col items-center justify-center p-8 text-center bg-white h-full pb-16">
          
          {currentTransaction.status === 'SUCCESSFUL' ? (
            <div className="flex flex-col items-center animate-fade-in" id="successful-payment-screen">
              <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mb-4 border border-emerald-200 shadow-sm shadow-emerald-500/10">
                <CheckCircle2 className="w-10 h-10" />
              </div>
              <h2 className="text-sm font-black text-emerald-600">پرداخت شما با موفقیت تایید شد!</h2>
              <p className="text-[10px] text-gray-500 mt-1 max-w-xs leading-normal">
                تراکنش خرید سفارش شما در ترمینال شتاب معتبر شد. کدهای تاییدیه الکترونیک در لاگ رپازیتوری کامیت شدند.
              </p>

              {/* Receipt Visual Presentation Card */}
              <div className="bg-slate-50 border border-gray-100 rounded-2xl p-4 w-full max-w-sm mt-5 text-right flex flex-col gap-2.5 shadow-xs relative">
                <div className="border-b border-gray-200/60 pb-2 mb-1 flex items-center justify-between">
                  <span className="text-[10px] font-black text-gray-800">رسید الکترونیکی پایانه یوزآنلاین</span>
                  <span className="font-mono text-[9px] text-gray-400">TXID: {currentTransaction.id}</span>
                </div>

                <div className="flex justify-between text-xs text-gray-500">
                  <span>نام درگاه مقصد:</span>
                  <span className="font-extrabold text-gray-800">
                    {paymentManager.getPaymentMethodById(currentTransaction.paymentMethodId)?.name || currentTransaction.paymentMethodId}
                  </span>
                </div>

                <div className="flex justify-between text-xs text-gray-500">
                  <span>شماره سفارش بازارچه:</span>
                  <span className="font-mono font-bold text-blue-600">{currentTransaction.orderId}</span>
                </div>

                <div className="flex justify-between text-xs text-gray-500">
                  <span>مبلغ کل پرداخت شده:</span>
                  <span className="font-black text-gray-900">{formatPrice(currentTransaction.amount)} تومان</span>
                </div>

                <div className="flex justify-between text-xs text-gray-500">
                  <span>شماره مرجع بانکی (RefID):</span>
                  <span className="font-mono font-bold text-gray-800">{currentTransaction.refId || 'نامشخص'}</span>
                </div>

                <div className="flex justify-between text-xs text-gray-500">
                  <span>کارت کسر کننده وجه:</span>
                  <span className="font-mono text-[11px] text-gray-800">{currentTransaction.cardPan || 'اعتبار سنجی مستقیم کیف پول'}</span>
                </div>

                <div className="flex justify-between text-xs text-gray-500">
                  <span>تاریخ تایید تراکنش:</span>
                  <span className="text-gray-800">
                    {new Date(currentTransaction.verifiedAt || '').toLocaleDateString('fa-IR')}، {new Date(currentTransaction.verifiedAt || '').toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>

                {/* Authenticity tag */}
                <div className="mt-2.5 bg-emerald-50 border border-emerald-100/60 py-1.5 px-2.5 rounded-lg text-[9px] text-emerald-800 text-center flex items-center justify-center gap-1 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  شناسه توکن مرجع شتاب تصدیق صلاحیت گردید
                </div>
              </div>

              {/* Success Action Buttons */}
              <div className="flex gap-2.5 w-full max-w-sm mt-6">
                <button
                  onClick={() => {
                    addLog('UI', 'کاربر رسید تراکنش را به اشتراک گذاشت / دانلود کرد', currentTransaction.id);
                    alert(`رسید پرداخت شماره ${currentTransaction.refId} در حافظه موقت کپی شد.`);
                  }}
                  className="bg-slate-100 hover:bg-slate-200 text-gray-700 px-3 py-3.5 rounded-xl border border-gray-200 text-[10px] font-black transition active:scale-95 flex items-center gap-1 shrink-0"
                >
                  <Download className="w-4 h-4 text-gray-500" />
                  دانلود رسید
                </button>

                <button
                  onClick={() => onPaymentSuccess(currentTransaction)}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-5 py-3.5 rounded-xl text-[10px] font-extrabold shadow-md shadow-blue-100 transition active:scale-95 flex items-center justify-center gap-1"
                >
                  بازگشت به برنامه و پیگیری سفارش
                  <ChevronRight className="w-4 h-4 scale-x-[-1]" />
                </button>
              </div>

            </div>
          ) : (
            <div className="flex flex-col items-center animate-fade-in" id="failed-payment-screen">
              <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mb-4 border border-red-200 shadow-sm shadow-red-500/10">
                <XCircle className="w-10 h-10 animate-pulse" />
              </div>
              <h2 className="text-sm font-black text-red-600">پرداخت شما ناموفق بود یا لغو گردید</h2>
              <p className="text-[10px] text-gray-500 mt-1 max-w-sm leading-normal">
                علت عمده قطعی تراکنش یا عدم ثبت موفق: <strong>{currentTransaction.errorMessage || 'وقوع خطا در اتصال سرویس شتاب'}</strong>
              </p>

              {/* Failed Invoice Card */}
              <div className="bg-slate-50 border border-gray-100 rounded-2xl p-4 w-full max-w-sm mt-5 text-right flex flex-col gap-2.5 shadow-xs">
                <div className="flex justify-between text-xs text-gray-500">
                  <span>شناسه موقت تراکنش مالی:</span>
                  <span className="font-mono text-gray-700">{currentTransaction.id}</span>
                </div>
                <div className="flex justify-between text-xs text-gray-500">
                  <span>درگاه مورد مراجعه خریدار:</span>
                  <span className="font-extrabold text-gray-800">
                    {paymentManager.getPaymentMethodById(currentTransaction.paymentMethodId)?.name || currentTransaction.paymentMethodId}
                  </span>
                </div>
                <div className="flex justify-between text-xs text-gray-500">
                  <span>مبلغ تعهد شده:</span>
                  <span className="font-black text-gray-900">{formatPrice(currentTransaction.amount)} تومان</span>
                </div>
                <div className="flex justify-between text-xs text-gray-500">
                  <span>علت سیستمی خطا:</span>
                  <span className="text-red-600 font-extrabold">{currentTransaction.errorMessage || 'انصراف عمدی مشتری'}</span>
                </div>
              </div>

              {/* Failure Action: Retry Payment or Select Another Gateway */}
              <div className="flex flex-col gap-2 w-full max-w-sm mt-6">
                <button
                  onClick={handleInitiatePayment}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3.5 rounded-xl text-[10px] font-black shadow-md shadow-blue-100 transition active:scale-[0.98] flex items-center justify-center gap-1.5"
                >
                  <RefreshCw className="w-4 h-4 animate-spin-slow" />
                  تلاش مجدد (پرداخت مجدد فاکتور جاری)
                </button>

                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      addLog('UI', 'تغییر روش پرداخت در مرحله خطا', 'بازگشت به انتخاب گیت');
                      setPaymentStep('SELECT_METHOD');
                    }}
                    className="flex-1 bg-slate-100 hover:bg-slate-200 text-gray-700 py-2.5 rounded-xl text-[10px] font-extrabold border border-gray-200 transition active:scale-95"
                  >
                    تغییر شیوه پرداخت
                  </button>
                  <button
                    onClick={() => {
                      addLog('UI', 'کاربر پس از شکست تراکنش سفارش را کاملاً لغو نمود', 'خروج');
                      onPaymentCancel();
                    }}
                    className="flex-1 bg-white hover:bg-red-50 text-red-500 py-2.5 rounded-xl text-[10px] font-extrabold border border-red-100 transition active:scale-95"
                  >
                    لغو خرید بازارچه
                  </button>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

      {/* -------------------- STEP 4: TRANSACTION HISTORY & REFUNDS -------------------- */}
      {paymentStep === 'HISTORY_VIEW' && (
        <div className="flex flex-col h-full overflow-hidden pb-16">
          
          {/* Header */}
          <div className="bg-white border-b border-gray-100 px-4 py-3 flex items-center justify-between shadow-sm shrink-0">
            <div className="flex items-center gap-2">
              <div className="bg-blue-600/10 p-1.5 rounded-lg">
                <History className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <h2 className="text-xs font-black text-gray-900 leading-tight">دفترچه لاگ‌های مالی شتاب</h2>
                <span className="text-[8.5px] text-gray-400 font-bold block mt-0.5">تاریخچه تراکنش‌های درگاه به درگاه</span>
              </div>
            </div>
            
            {!historyModeOnly ? (
              <button
                onClick={() => setPaymentStep('SELECT_METHOD')}
                className="text-xs text-blue-600 hover:text-blue-700 flex items-center gap-1 font-black py-1 px-2.5 rounded-xl bg-blue-50/50"
              >
                بازگشت به فاکتور
                <ArrowLeft className="w-3.5 h-3.5 scale-x-[-1]" />
              </button>
            ) : (
              <button
                onClick={onPaymentCancel}
                className="text-xs text-gray-400 hover:text-gray-600 flex items-center gap-1 font-bold"
              >
                بازگشت
                <ArrowLeft className="w-3.5 h-3.5 scale-x-[-1]" />
              </button>
            )}
          </div>

          {/* Search and filter toolbar */}
          <div className="bg-white border-b border-gray-100 p-3 flex gap-2.5 items-center shrink-0">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="جستجو با کد تراکنش، شماره سفارش یا RefID..."
                value={searchHistory}
                onChange={(e) => setSearchHistory(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 pr-8 py-1.5 rounded-xl text-[10px] focus:outline-none focus:border-blue-500 font-medium text-right text-gray-800"
              />
              <Search className="w-3.5 h-3.5 text-gray-400 absolute right-2.5 top-2.5" />
            </div>

            <div className="flex items-center gap-1 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1 shrink-0">
              <Filter className="w-3 h-3 text-gray-500" />
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="bg-transparent text-[9.5px] font-semibold text-gray-700 focus:outline-none cursor-pointer"
              >
                <option value="ALL">همه تراکنش‌ها</option>
                <option value="SUCCESSFUL">فقط تراکنش‌های موفق</option>
                <option value="FAILED">فقط مسدود و ناموفق</option>
                <option value="REFUNDED">استرداد وجه شده</option>
                <option value="PENDING">در انتظار پرداخت</option>
              </select>
            </div>
          </div>

          {/* Refund Dialog drawer input if active */}
          {refundDialogTxn && (
            <div className="bg-amber-500/10 border-b border-amber-500/20 p-3 shrink-0 animate-slide-down">
              <form onSubmit={handleRequestRefund} className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-black text-amber-900 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                    استرداد وجه تراکنش {refundDialogTxn.id} (مبلغ: {formatPrice(refundDialogTxn.amount)} تومان)
                  </span>
                  <button 
                    type="button" 
                    onClick={() => setRefundDialogTxn(null)}
                    className="text-amber-800 text-xs font-black px-1.5 hover:bg-amber-200 rounded"
                  >
                    انصراف
                  </button>
                </div>

                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="علت استرداد را توضیح دهید (مثلاً کسر اشتباه، لغو سفارش)"
                    value={refundReason}
                    onChange={(e) => setRefundReason(e.target.value)}
                    className="flex-1 bg-white border border-amber-500/30 rounded-xl px-3 py-1.5 text-[10px] focus:outline-none focus:border-amber-600"
                  />
                  <button
                    type="submit"
                    disabled={isProcessingRefund}
                    className="bg-amber-600 hover:bg-amber-700 text-white font-black text-[10px] px-4 py-1.5 rounded-xl transition duration-150 active:scale-95 shrink-0 flex items-center gap-1"
                  >
                    {isProcessingRefund ? <RefreshCw className="w-3 h-3 animate-spin" /> : <CornerDownLeft className="w-3 h-3" />}
                    انجام برگشت وجه
                  </button>
                </div>
                {refundError && <p className="text-[9px] text-red-600 font-bold">{refundError}</p>}
              </form>
            </div>
          )}

          {/* Transactions list */}
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3">
            {filteredTransactions.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-gray-400">
                <span className="text-3xl mb-2">📒</span>
                <span className="text-[10px] font-black text-gray-800">هیچ تراکنش منطبق بر فیلتر ثبت نگردیده است</span>
                <p className="text-[9px] text-gray-400 mt-1 max-w-xs">
                  تراکنش‌های شبیه‌ساز پس از مراجع درگاه بلافاصله در این بخش نمایان می‌شوند.
                </p>
              </div>
            ) : (
              filteredTransactions.map((t) => (
                <div 
                  key={t.id} 
                  className="bg-white border border-gray-100 rounded-2xl p-3.5 shadow-xs flex flex-col gap-2 hover:shadow transition"
                >
                  <div className="flex justify-between items-center border-b border-slate-50 pb-2">
                    <div className="flex items-center gap-1.5">
                      <span className={`w-2.5 h-2.5 rounded-full ${
                        t.status === 'SUCCESSFUL' ? 'bg-emerald-500' :
                        t.status === 'FAILED' ? 'bg-red-500' :
                        t.status === 'REFUNDED' ? 'bg-amber-500' :
                        'bg-blue-500'
                      }`} />
                      
                      <span className="text-[10px] font-black text-gray-900">سفارش {t.orderId}</span>
                      
                      <span className="font-mono text-[9px] text-gray-400">({t.id})</span>
                    </div>

                    <div className="text-[8px] font-black text-gray-400 flex items-center gap-1 font-mono">
                      <Clock className="w-3 h-3" />
                      {new Date(t.createdAt).toLocaleDateString('fa-IR')}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-y-2 text-[10px] text-gray-500 leading-normal">
                    <div>درگاه استفاده شده: <strong className="text-gray-800">{paymentManager.getPaymentMethodById(t.paymentMethodId)?.name.split(' (')[0] || t.paymentMethodId}</strong></div>
                    <div>مبلغ: <strong className="text-gray-900">{formatPrice(t.amount)} تومان</strong></div>
                    
                    {t.refId && <div className="col-span-2">کد رهگیری بانک (RefID): <strong className="text-blue-600 font-mono text-[10px]">{t.refId}</strong></div>}
                    {t.cardPan && <div className="col-span-2">کارت بانکی: <strong className="text-gray-800 font-mono text-[11px]">{t.cardPan}</strong></div>}
                    {t.refundReason && <div className="col-span-2 bg-amber-50/50 p-1.5 border border-amber-500/10 text-amber-800 rounded-lg text-[9px]">علت استرداد: <strong>{t.refundReason}</strong></div>}
                    {t.errorMessage && <div className="col-span-2 bg-red-50/50 p-1.5 border border-red-500/10 text-red-700 rounded-lg text-[9px]">علت خطا: <strong>{t.errorMessage}</strong></div>}
                  </div>

                  {/* Actions (Refund Support for live simulation demo) */}
                  {t.status === 'SUCCESSFUL' && (
                    <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[8px] text-emerald-600 font-bold flex items-center gap-0.5">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        تراکنش بابت سفارش با موفقیت ثبت گردیده
                      </span>

                      <button
                        onClick={() => {
                          setRefundDialogTxn(t);
                          setRefundReason('');
                          setRefundError('');
                          addLog('UI', 'بازشدن منوی درخواست استرداد وجه تراکنش', t.id);
                        }}
                        className="bg-amber-50 hover:bg-amber-100 text-amber-700 hover:text-amber-800 font-extrabold text-[9px] px-2.5 py-1.5 rounded-lg border border-amber-200/50 transition active:scale-95"
                      >
                        درخواست استرداد وجه (Refund)
                      </button>
                    </div>
                  )}

                  {t.status === 'REFUNDED' && (
                    <div className="mt-2 text-right">
                      <span className="text-[8.5px] text-amber-600 font-black bg-amber-50 border border-amber-100 px-2 py-1 rounded">
                        ✓ وجوه تراکنش ارجاع شد (برگشت داده شده)
                      </span>
                    </div>
                  )}
                  
                  {t.status === 'FAILED' && (
                    <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between">
                      <span className="text-[8px] text-red-500 font-bold flex items-center gap-0.5">
                        <XCircle className="w-3.5 h-3.5" />
                        تراکنش با شکست به پایان رسید
                      </span>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

    </div>
  );
}
