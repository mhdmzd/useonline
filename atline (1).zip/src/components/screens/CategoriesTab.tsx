import React, { useState } from 'react';
import { Smartphone, Shirt, Home as HomeIcon, Sparkles, ShoppingBag, Terminal, Laptop, ArrowLeft } from 'lucide-react';
import { Category, Product, ArchLog } from '../../types';

interface CategoriesTabProps {
  onProductSelect: (p: Product) => void;
  favorites: string[];
  toggleFavorite: (p: Product) => void;
  addLog: (layer: ArchLog['layer'], message: string, details: string) => void;
  products: Product[];
  categories: Category[];
}

export function CategoriesTab({
  onProductSelect,
  favorites,
  toggleFavorite,
  addLog,
  products = [],
  categories = [],
}: CategoriesTabProps) {
  const [activeCategoryId, setActiveCategoryId] = useState('digital');
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(null);

  const activeCategory = categories.find((c) => c.id === activeCategoryId) || categories[0] || { id: '', name: '', icon: '', subcategories: [] };

  const handleCategorySidebarClick = (category: Category) => {
    addLog('UI', 'تغییر دسته‌بندی ستون راست در صفحه آرشیو', `انتخاب: ${category.name}`);
    addLog('VIEWMODEL', 'به‌روزرسانی و فیلتر اطلاعات در CatalogViewModel', `CategoryId: ${category.id}`);
    addLog('USECASE', 'فراخوانی GetProductsUseCase(categoryId)', `categoryId = ${category.id}`);
    
    setActiveCategoryId(category.id);
    setSelectedSubcategory(null);
  };

  const handleSubcategoryClick = (subId: string, subName: string) => {
    addLog('UI', 'کلیک بر روی زیرشاخه‌ دسته‌بندی متمایز', `زیرشاخه: ${subName}`);
    setSelectedSubcategory(subId);
  };

  const getProductsForFilters = () => {
    if (selectedSubcategory) {
      return products.filter((p) => p.categoryId === selectedSubcategory);
    }
    const subIds = activeCategory.subcategories.map((sc) => sc.id);
    return products.filter((p) => subIds.includes(p.categoryId));
  };

  const toPersianDigits = (num: number | string) => {
    const id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/[0-9]/g, (w) => id[+w]);
  };

  const formatPrice = (price: number) => {
    const formatted = price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return toPersianDigits(formatted);
  };

  const filteredProducts = getProductsForFilters();

  return (
    <div className="flex bg-white h-full pb-20 font-vazir text-right" dir="rtl" id="categories-tab-scroller">
      {/* 1. Sidebar Column */}
      <div className="w-20 border-l border-gray-100 flex flex-col pt-4 bg-slate-50 overflow-y-auto shrink-0 items-center gap-1.5">
        {categories.map((cat) => {
          const isActive = cat.id === activeCategoryId;
          return (
            <button
              key={cat.id}
              onClick={() => handleCategorySidebarClick(cat)}
              className={`w-16 py-3.5 rounded-2xl flex flex-col items-center gap-1.5 transition ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-100 font-extraboldScale'
                  : 'text-gray-500 hover:bg-slate-100'
              }`}
            >
              <CategoryIcon name={cat.icon} className="w-4 h-4" />
              <span className="text-[8px] text-center font-bold px-1 line-clamp-2 leading-tight">{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* 2. Content view */}
      <div className="flex-1 flex flex-col p-4 overflow-y-auto">
        {selectedSubcategory ? (
          <div>
            <button
              onClick={() => setSelectedSubcategory(null)}
              className="flex items-center gap-1 bg-slate-100 text-gray-700 text-[10px] font-bold px-3 py-1.5 rounded-lg mb-3 self-start"
            >
              <ArrowLeft className="w-3.5 h-3.5 scale-x-[-1]" />
              برگشت به شاخه‌های اصلی
            </button>
            <h3 className="text-xs font-black text-gray-900 border-b border-gray-100 pb-2 mb-3">
              محصولات زیرشاخه {activeCategory.subcategories.find((s) => s.id === selectedSubcategory)?.name}
            </h3>
          </div>
        ) : (
          <>
            {/* Banner Category header */}
            <div className="relative h-24 rounded-2xl overflow-hidden bg-slate-900 mb-4 shadow-sm text-white flex items-center p-4">
              <div className="absolute inset-0 opacity-40">
                <img src={activeCategory.subcategories[0]?.image} alt={activeCategory.name} className="w-full h-full object-cover" />
              </div>
              <div className="relative z-10">
                <h2 className="text-sm font-black tracking-tight">{activeCategory.name}</h2>
                <p className="text-[9px] text-gray-200 mt-0.5">ضمانت اصالت و برترین فروشنده‌های کشور</p>
              </div>
            </div>

            {/* Subcategories Horizontal/Grid List */}
            <h3 className="text-[10px] font-black text-gray-800 mb-3.5">زیرشاخه‌های اصلی</h3>
            <div className="grid grid-cols-2 gap-2 mb-6">
              {activeCategory.subcategories.map((sub) => (
                <div
                  key={sub.id}
                  onClick={() => handleSubcategoryClick(sub.id, sub.name)}
                  className="bg-slate-50 border border-slate-100 rounded-xl p-2.5 flex items-center gap-2 cursor-pointer hover:border-blue-400 active:scale-95 transition"
                >
                  <img src={sub.image} alt={sub.name} className="w-10 h-10 object-cover rounded-lg bg-slate-200" />
                  <span className="text-[9px] font-extrabold text-gray-900 line-clamp-2 leading-tight">{sub.name}</span>
                </div>
              ))}
            </div>

            <h3 className="text-[10px] font-black text-gray-800 border-b border-gray-100 pb-1.5 mb-3">کالاهای پرطرفدار دسته‌بندی</h3>
          </>
        )}

        {/* Product listings filtered */}
        {filteredProducts.length > 0 ? (
          <div className="flex flex-col gap-3">
            {filteredProducts.map((product) => {
              const isFavorite = favorites.includes(product.id);
              return (
                <div
                  key={product.id}
                  onClick={() => {
                    addLog('UI', 'انتخاب محصول فیلترشده در شاخه‌ها', `عنوان: ${product.title}`);
                    onProductSelect(product);
                  }}
                  className="flex gap-3 bg-slate-50 border border-slate-100/50 p-2.5 rounded-2xl cursor-pointer hover:border-gray-200 active:scale-[0.99] transition"
                >
                  <img src={product.image} alt={product.title} className="w-16 h-16 object-cover rounded-xl shrink-0 bg-white" />
                  <div className="flex-1 flex flex-col justify-between py-0.5">
                    <div>
                      <h4 className="text-[10px] font-bold text-gray-800 line-clamp-1 leading-snug">{product.title}</h4>
                      <div className="flex items-center gap-1.5 mt-1 text-[9px] text-gray-400">
                        <span>رتبه: {toPersianDigits(product.rating.toFixed(1))} ★</span>
                        <span>•</span>
                        <span>فروشگاه: {product.vendor.name}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-1">
                      {product.discountPercentage && (
                        <span className="bg-[#ff4d4f] text-white text-[8px] font-bold px-1.5 rounded-full">
                          {toPersianDigits(product.discountPercentage)}٪-
                        </span>
                      )}
                      <span className="text-[11px] font-black text-gray-900 flex items-center gap-0.5 mr-auto">
                        {formatPrice(product.price)} <span className="text-[8px] font-medium text-gray-500">تومان</span>
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-[10px] text-gray-400">محصولی در این زیرشاخه تعریف نشده است.</p>
          </div>
        )}
      </div>
    </div>
  );
}

// Icon helper to represent categories
function CategoryIcon({ name, className }: { name: string; className?: string }) {
  switch (name) {
    case 'Smartphone':
      return <Smartphone className={className} />;
    case 'Shirt':
      return <Shirt className={className} />;
    case 'Home':
      return <HomeIcon className={className} />;
    case 'Sparkles':
      return <Sparkles className={className} />;
    case 'ShoppingBag':
      return <ShoppingBag className={className} />;
    default:
      return <Smartphone className={className} />;
  }
}
