import React, { useState, useEffect } from 'react';
import { Smartphone, Wifi, Battery, Star, ShoppingCart, Heart, User, Sparkles, X, ShoppingBag, ShieldCheck, Mail, Clock, HelpCircle, ArrowLeft, Share2, Copy, Check, Send, MessageSquare, Bell } from 'lucide-react';
import { Product, CartItem, Order, NotificationItem, ArchLog } from '../types';
import { mockNotifications } from '../data/mockProducts';
import { ZoomableImage } from './ZoomableImage';

interface DeviceFrameProps {
  children: React.ReactNode;
  activeTab: number;
  setActiveTab: (tab: number) => void;
  isLoggedIn: boolean;
  cartCount: number;
  favoritesCount: number;
  showNotificationShade: boolean;
  setShowNotificationShade: (show: boolean) => void;
  notifications: NotificationItem[];
  onClearNotification: (id: string) => void;
  onClearAllNotifications: () => void;
  onAddNotification?: (notif: NotificationItem) => void;
  selectedProduct: Product | null;
  onCloseProductDetails: () => void;
  onAddToCart: (p: Product) => void;
  onToggleFavorite: (p: Product) => void;
  favorites: string[];
  addLog: (layer: ArchLog['layer'], message: string, details: string) => void;
  vendorMode?: boolean;
}

export function DeviceFrame({
  children,
  activeTab,
  setActiveTab,
  isLoggedIn,
  cartCount,
  favoritesCount,
  showNotificationShade,
  setShowNotificationShade,
  notifications,
  onClearNotification,
  onClearAllNotifications,
  onAddNotification,
  selectedProduct,
  onCloseProductDetails,
  onAddToCart,
  onToggleFavorite,
  favorites,
  addLog,
  vendorMode,
}: DeviceFrameProps) {
  const [deviceTime, setDeviceTime] = useState('۱۲:۰۰');
  const [isShareOpen, setIsShareOpen] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [shareToast, setShareToast] = useState<string | null>(null);
  const [priceDropSubscriptions, setPriceDropSubscriptions] = useState<string[]>([]);

  // Clear share panel states when product details are closed
  useEffect(() => {
    if (!selectedProduct) {
      setIsShareOpen(false);
      setIsCopied(false);
      setShareToast(null);
    }
  }, [selectedProduct]);

  // Sync real-world clock time and translate to Persian numbers
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      let hrs = now.getHours().toString().padStart(2, '0');
      let mins = now.getMinutes().toString().padStart(2, '0');
      
      const id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
      const persianHrs = hrs.replace(/[0-9]/g, (w) => id[+w]);
      const persianMins = mins.replace(/[0-9]/g, (w) => id[+w]);
      
      setDeviceTime(`${persianHrs}:${persianMins}`);
    };
    
    updateTime();
    const timer = setInterval(updateTime, 60000);
    return () => clearInterval(timer);
  }, []);

  const toPersianDigits = (num: number | string) => {
    const id = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return num.toString().replace(/[0-9]/g, (w) => id[+w]);
  };

  const formatPrice = (price: number) => {
    const formatted = price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return toPersianDigits(formatted);
  };

  const isSelectedProductFavorite = selectedProduct ? favorites.includes(selectedProduct.id) : false;

  return (
    <div className="relative mx-auto w-[330px] h-[670px] bg-slate-900 rounded-[50px] p-3 shadow-2xl border-4 border-slate-800 ring-12 ring-slate-950/20 flex flex-col items-center justify-center select-none shrink-0" id="android-device-container">
      {/* Dynamic Camera Hole Notch */}
      <div className="absolute top-5 left-1/2 transform -translate-x-1/2 w-32 h-6 bg-black rounded-full z-40 flex items-center justify-between px-3">
        <div className="w-2.5 h-2.5 bg-zinc-900 rounded-full border border-zinc-950 flex-shrink-0" /> {/* Speaker grill */}
        <div className="w-1.5 h-1.5 bg-blue-900 rounded-full flex-shrink-0" /> {/* Selfie camera */}
      </div>

      {/* Vol buttons on physical device sides */}
      <div className="absolute -left-1.5 top-28 w-1 h-12 bg-slate-800 rounded-l" />
      <div className="absolute -left-1.5 top-44 w-1 h-12 bg-slate-800 rounded-l" />
      <div className="absolute -right-1.5 top-36 w-1 h-16 bg-slate-800 rounded-r" />

      {/* Smartphone display stage */}
      <div className="w-full h-full bg-white rounded-[40px] overflow-hidden relative flex flex-col shadow-inner select-none">
        
        {/* State 1: Native Android System Bar */}
        <div 
          onClick={() => {
            addLog('UI', 'کشیدن استاتوس بار برای احضار پنل نوتیفیکیشن', 'نمایش لیست اعلانات');
            setShowNotificationShade(!showNotificationShade);
          }}
          className="bg-white/80 backdrop-blur-md h-8 px-5 flex items-center justify-between text-[10px] font-bold text-gray-800 z-30 cursor-pointer border-b border-gray-100"
          dir="rtl"
        >
          <div className="flex items-center gap-1">
            <span className="font-sans text-[9px] tracking-tight text-gray-500">4G</span>
            <Wifi className="w-3.5 h-3.5 text-gray-700" />
            <Battery className="w-4 h-4 text-gray-700 mt-0.5 rotate-180" />
          </div>
          <div className="text-[10px] text-gray-800 font-extrabold font-mono mt-0.5">{deviceTime}</div>
        </div>

        {/* State 2: Pull-down Android Notification shade */}
        {showNotificationShade && (
          <div className="absolute top-8 inset-x-0 bottom-0 bg-slate-950/80 backdrop-blur-md z-30 flex flex-col p-4 animate-fade-in text-right font-vazir" dir="rtl" id="notification-shade-content">
            <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-3 text-white">
              <span className="text-xs font-black flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-blue-400" />
                مرکز کنترل اعلانات یوزآنلاین
              </span>
              <button 
                onClick={() => setShowNotificationShade(false)}
                className="text-gray-400 hover:text-white p-1 hover:bg-white/10 rounded-lg transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {notifications.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center text-gray-400 py-10">
                <span className="text-3xl mb-1">🔔</span>
                <p className="text-[10px] font-bold">هیچ اعلان جدیدی وجود ندارد.</p>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto flex flex-col gap-2">
                <div className="flex justify-between items-center px-1 mb-1.5 text-[9px]">
                  <span className="text-gray-400">اعلانات خوانده نشده ({toPersianDigits(notifications.filter(n=>!n.isRead).length)})</span>
                  <button 
                    onClick={() => {
                      addLog('UI', 'کلیک روی دکمه حذف تمامی اعلانات شید', 'انتقال رویداد به ClearAllNotificationsUseCase');
                      onClearAllNotifications();
                    }}
                    className="text-blue-400 hover:underline font-bold"
                  >
                    پاک کردن همه
                  </button>
                </div>

                {notifications.map((notif) => (
                  <div 
                    key={notif.id}
                    className={`bg-white/10 border border-white/5 p-3 rounded-xl relative flex flex-col transition hover:bg-white/15 ${!notif.isRead ? 'border-r-4 border-r-blue-500 bg-white/15' : ''}`}
                  >
                    <button
                      onClick={() => {
                        addLog('UI', 'پاکسازی یک نوتیفیکیشن خاص', `شناسه: ${notif.id}`);
                        onClearNotification(notif.id);
                      }}
                      className="absolute left-2.5 top-2 p-1 text-gray-400 hover:text-white rounded"
                    >
                      <X className="w-3 h-3" />
                    </button>
                    <span className="text-[10px] font-bold text-blue-400">{notif.title}</span>
                    <p className="text-[9px] text-zinc-300 mt-1 pl-4 leading-relaxed font-medium">{notif.body}</p>
                    <span className="text-[8px] text-zinc-500 mt-1.5 self-start">{notif.time}</span>
                  </div>
                ))}
              </div>
            )}
            
            <button
              onClick={() => setShowNotificationShade(false)}
              className="mt-4 bg-white/10 hover:bg-white/20 text-white font-bold text-center py-2.5 rounded-xl text-xs active:scale-95 transition border border-white/10"
            >
              بستن پنل اعلان‌ها
            </button>
          </div>
        )}

        {/* State 3: Active Canvas Content (renders Tab views) */}
        <div className="flex-1 relative overflow-hidden bg-slate-50">
          {children}
        </div>

        {/* State 4: Jetpack Compose Material 3 Bottom Navigation bar */}
        {isLoggedIn && !vendorMode && (
          <div 
            className="absolute bottom-0 inset-x-0 h-16 bg-white border-t border-gray-100 flex items-center justify-around z-20 shadow-[0_-2px_10px_rgba(0,0,0,0.02)] px-2 font-vazir"
            dir="rtl"
            id="android-bottom-nav"
          >
            {[
              { label: 'خانه', icon: Smartphone, index: 0 },
              { label: 'دسته‌ها', icon: Sparkles, index: 1 },
              { label: 'سبد خرید', icon: ShoppingCart, index: 2, badge: cartCount },
              { label: 'علاقه‌ها', icon: Heart, index: 3, badge: favoritesCount },
              { label: 'پروفایل', icon: User, index: 4 }
            ].map((tab) => {
              const isActive = activeTab === tab.index;
              return (
                <button
                  key={tab.index}
                  onClick={() => {
                    addLog('UI', `تغییر تب ناوبری پایینی به ${tab.label}`, `آدرس لودینگ تبار: index ${tab.index}`);
                    setActiveTab(tab.index);
                  }}
                  className="flex flex-col items-center justify-center flex-1 h-full relative cursor-pointer group"
                >
                  <div className={`relative px-4 py-1 rounded-xl flex items-center justify-center transition-all duration-300 ${
                    isActive ? 'bg-blue-100/80 text-blue-600 scale-105' : 'text-gray-400 hover:text-gray-600'
                  }`}>
                    <tab.icon className="w-4 h-4 transition" />
                    
                    {tab.badge !== undefined && tab.badge > 0 && (
                      <span className="absolute -top-1.5 -right-1 bg-[#ff4d4f] text-white text-[8px] font-sans font-bold w-4 h-4 flex items-center justify-center rounded-full shadow-sm ring-2 ring-white animate-pulse">
                        {tab.badge}
                      </span>
                    )}
                  </div>
                  <span className={`text-[8px] mt-1 transition font-bold ${
                    isActive ? 'text-blue-600 font-extrabold' : 'text-gray-400'
                  }`}>
                    {tab.label}
                  </span>
                </button>
              );
            })}
          </div>
        )}

        {/* State 5: Floating Custom Product Details Modal (Slide Bottom Sheet emulation) */}
        {selectedProduct && (
          <div className="absolute inset-0 bg-black/60 z-30 flex flex-col justify-end animate-fade-in font-vazir" dir="rtl" id="product-bottom-sheet">
            <div className="bg-white rounded-t-[2.5rem] max-h-[90%] overflow-y-auto p-4 flex flex-col gap-4 animate-slide-up relative">
              <button
                onClick={onCloseProductDetails}
                className="absolute left-4 top-4 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-gray-600 hover:bg-slate-200 transition"
              >
                <X className="w-4 h-4" />
              </button>

              <button
                onClick={() => {
                  setIsShareOpen(true);
                  addLog('UI', 'کلیک روی دکمه اشتراک‌گذاری کالا در شید کالا', `کالا: ${selectedProduct.title}`);
                }}
                className="absolute left-14 top-4 w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-gray-600 hover:bg-slate-200 transition"
                title="اشتراک‌گذاری این کالا"
              >
                <Share2 className="w-4 h-4" />
              </button>

              {/* Cover Image inside Dialog screen */}
              <div className="relative mt-2">
                <ZoomableImage src={selectedProduct.image} alt={selectedProduct.title} addLog={addLog} />
                <span className="absolute bottom-3 right-3 bg-blue-600 text-white text-[9px] font-black px-2.5 py-1 rounded-full shadow z-10">
                  دسته‌بندی: {selectedProduct.category}
                </span>
                {selectedProduct.discountPercentage && (
                  <span className="absolute top-3 right-3 bg-[#ff4d4f] text-white text-xs font-black px-2 py-0.5 rounded-full shadow z-10">
                    تخفیف دارد ({toPersianDigits(selectedProduct.discountPercentage)}٪)
                  </span>
                )}
              </div>

              {/* Title & English translations */}
              <div>
                <h3 className="text-xs font-black text-gray-950 leading-relaxed text-right">{selectedProduct.title}</h3>
                <span className="text-[9px] text-gray-400 font-mono tracking-tight block mt-1 text-left" dir="ltr">{selectedProduct.englishTitle}</span>
              </div>

              {/* Ratings and dynamic Vendor card */}
              <div className="bg-slate-50 border border-slate-100/50 p-3 rounded-2.5xl flex items-center justify-between text-right">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-blue-600 font-bold text-xs text-white flex items-center justify-center shadow-sm">
                    {selectedProduct.vendor.logo}
                  </div>
                  <div>
                    <span className="text-[8px] text-gray-400 block font-semibold">فروشگاه عرضه‌کننده</span>
                    <span className="text-[10px] font-extrabold text-blue-600 flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 inline" />
                      {selectedProduct.vendor.name}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1 text-[10px] bg-amber-50 text-amber-600 font-bold px-2.5 py-1 rounded-lg border border-amber-100">
                  <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                  <span>{toPersianDigits(selectedProduct.rating.toFixed(1))} ({toPersianDigits(selectedProduct.reviewsCount)} دیدگاه)</span>
                </div>
              </div>

              {/* Product specifications mapping */}
              <div>
                <h4 className="text-[10px] font-black text-gray-800 mb-2 border-b border-gray-100 pb-1">شناسه و مشخصات فنی کالا</h4>
                <div className="flex flex-col gap-1.5">
                  {Object.entries(selectedProduct.specifications).map(([key, value]) => (
                    <div key={key} className="flex justify-between text-[9px] py-1 border-b border-gray-50/70 font-medium text-gray-500">
                      <span className="text-gray-400">{key}</span>
                      <span className="text-gray-800 text-left font-semibold">{toPersianDigits(value)}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Farsi descriptions detail */}
              <div>
                <h4 className="text-[10px] font-black text-gray-800 mb-1.5 border-b border-gray-100 pb-1">معرفی اجمالی محصول</h4>
                <p className="text-[10px] text-gray-500 leading-relaxed font-medium text-right bg-slate-50/60 p-2.5 rounded-xl border border-slate-100/50">
                  {selectedProduct.description}
                </p>
              </div>

              {/* Price Drop Alert Subscription Section */}
              <div className="bg-slate-50 border border-slate-100 rounded-2xl p-3 flex items-center justify-between gap-3 text-right">
                <div className="flex items-center gap-2 flex-1">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center transition border ${
                    priceDropSubscriptions.includes(selectedProduct.id)
                      ? 'bg-emerald-50 text-emerald-500 border-emerald-100 font-extrabold'
                      : 'bg-blue-50 text-blue-600 border-blue-100'
                  }`}>
                    <Bell className={`w-4 h-4 ${priceDropSubscriptions.includes(selectedProduct.id) ? 'animate-bounce' : ''}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-[10px] font-black text-slate-800 block leading-tight">خبرم کن اگر ارزان شد</span>
                    <span className="text-[8px] text-gray-400 block font-bold mt-1 overflow-hidden truncate">اشتراک در هشدار کاهش قیمت کالا</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    const isSubbed = priceDropSubscriptions.includes(selectedProduct.id);
                    if (isSubbed) {
                      setPriceDropSubscriptions((prev) => prev.filter((id) => id !== selectedProduct.id));
                      addLog('UI', 'لغو اشتراک در سیستم ثبت کاهش قیمت', `محصول: ${selectedProduct.title}`);
                      setShareToast('اطلاع‌رسانی کاهش قیمت این کالا غیرفعال شد.');
                      setTimeout(() => setShareToast(null), 3000);
                    } else {
                      setPriceDropSubscriptions((prev) => [...prev, selectedProduct.id]);
                      addLog('UI', 'ثبت اشتراک فعال شدن هشدار کاهش قیمت', `محصول: ${selectedProduct.title}`);
                      
                      const newNotif: NotificationItem = {
                        id: Math.random().toString(),
                        title: 'اشتراک کاهش قیمت فعال شد 🔔',
                        body: `به محض افت قیمت محصول "${selectedProduct.title}" با اعلان سراسری باخبر خواهید شد.`,
                        time: 'هم‌اکنون',
                        type: 'SYSTEM',
                        isRead: false
                      };

                      onAddNotification?.(newNotif);
                      setShareToast('اشتراک شما با موفقیت ثبت گردید.');
                      setTimeout(() => setShareToast(null), 3000);
                    }
                  }}
                  className={`px-3 py-1.5 rounded-xl text-[9px] font-black transition-all active:scale-95 border shrink-0 ${
                    priceDropSubscriptions.includes(selectedProduct.id)
                      ? 'bg-emerald-500 text-white border-emerald-600 shadow-sm shadow-emerald-500/10'
                      : 'bg-white text-blue-600 border-blue-200 hover:bg-slate-50'
                  }`}
                  id="notify-price-drop-btn"
                >
                  {priceDropSubscriptions.includes(selectedProduct.id) ? 'فعال است' : 'فعال‌سازی'}
                </button>
              </div>

              {/* Shopping operations section (Price labels, Add to Cart, Favorite Toggle) */}
              <div className="sticky bottom-0 bg-white border-t border-gray-100 pt-3 flex items-center gap-2 mt-2">
                <div className="flex flex-col justify-center min-w-[90px]">
                  {selectedProduct.originalPrice && (
                    <span className="text-[9px] text-gray-400 line-through text-right">
                      {formatPrice(selectedProduct.originalPrice)}
                    </span>
                  )}
                  <span className="text-sm font-black text-gray-950 text-right leading-tight block">
                    {formatPrice(selectedProduct.price)}<span className="text-[9px] text-gray-400 font-bold mr-0.5">تومان</span>
                  </span>
                </div>

                <button
                  onClick={() => {
                    addLog('UI', 'افزودن مستقیم کالا به سبد خرید از شید کالا', `کالا: ${selectedProduct.title}`);
                    addLog('VIEWMODEL', 'بارگذاری متد addProduct() در CartViewModel', `id = ${selectedProduct.id}`);
                    onAddToCart(selectedProduct);
                  }}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 active:scale-95 transition text-white font-extrabold text-xs py-3 rounded-2xl flex items-center justify-center gap-1.5 shadow-lg shadow-blue-100"
                >
                  <ShoppingCart className="w-4 h-4" />
                  افزودن به سبد خرید
                </button>

                <button
                  onClick={() => {
                    addLog('UI', 'تغییر وضعیت علاقه‌مندی از برگه کالا', `محصول: ${selectedProduct.title}`);
                    onToggleFavorite(selectedProduct);
                  }}
                  className={`p-3 rounded-2xl flex items-center justify-center transition border ${
                    isSelectedProductFavorite
                      ? 'bg-red-50 text-[#ff4d4f] border-red-200'
                      : 'bg-slate-50 text-gray-400 border-gray-100 hover:text-[#ff4d4f]'
                  }`}
                  title="نشان کردن محصول"
                >
                  <Heart className="w-4 h-4" fill={isSelectedProductFavorite ? 'currentColor' : 'none'} />
                </button>
              </div>
            </div>

            {/* Mock Share Intent Drawer overlay */}
            {isShareOpen && selectedProduct && (
              <div className="absolute inset-0 bg-slate-900/60 z-40 flex flex-col justify-end animate-fade-in font-vazir" onClick={() => setIsShareOpen(false)}>
                <div 
                  className="bg-white rounded-t-[2rem] p-5 flex flex-col gap-4 animate-slide-up shadow-2xl relative"
                  onClick={(e) => e.stopPropagation()}
                >
                  {/* Top notch indicator bar */}
                  <div className="w-10 h-1 bg-slate-200 rounded-full mx-auto mb-1"></div>

                  {/* Title Header */}
                  <div className="flex items-center justify-between border-b border-gray-150 pb-3">
                    <div className="flex items-center gap-2">
                      <Share2 className="w-4 h-4 text-blue-600 animate-pulse" />
                      <span className="text-xs font-black text-gray-950">اشتراک‌گذاری کالا</span>
                    </div>
                    <button 
                      onClick={() => setIsShareOpen(false)}
                      className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-gray-400 hover:text-gray-700"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* URL Copy section */}
                  <div className="flex flex-col gap-1.5 text-right">
                    <label className="text-[9px] font-bold text-gray-400">لینک اختصاصی کالا</label>
                    <div className="flex items-center gap-2 bg-slate-50 border border-slate-100 rounded-xl p-2">
                      <span className="flex-1 text-[9px] text-slate-600 font-mono text-left tracking-wider truncate" dir="ltr">
                        https://useonline.ir/p/{selectedProduct.id}
                      </span>
                      <button
                        onClick={async () => {
                          const shareUrl = `https://useonline.ir/p/${selectedProduct.id}`;
                          try {
                            await navigator.clipboard.writeText(shareUrl);
                          } catch (err) {
                            // fallback
                          }
                          setIsCopied(true);
                          addLog('UI', 'کپی آدرس سفارشی کالا از برگه اشتراک‌گذاری', `کالا: ${selectedProduct.title}`);
                          setShareToast('لینک کالا با موفقیت در کلیپ‌بورد کپی شد.');
                          setTimeout(() => setIsCopied(false), 2000);
                          setTimeout(() => setShareToast(null), 3000);
                        }}
                        className={`px-3 py-1.5 rounded-lg text-[9px] font-black transition flex items-center gap-1.5 shadow-sm active:scale-95 shrink-0 ${
                          isCopied 
                            ? 'bg-emerald-500 text-white' 
                            : 'bg-white border border-gray-200 text-slate-700 hover:border-slate-300'
                        }`}
                      >
                        {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{isCopied ? 'کپی شد' : 'کپی لینک'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Social Channels Flow */}
                  <div className="flex flex-col gap-2 text-right">
                    <span className="text-[9px] font-bold text-gray-400">اشتراک در شبکه‌های اجتماعی</span>
                    <div className="grid grid-cols-4 gap-2.5 mt-1">
                      {[
                        { id: 'telegram', name: 'تلگرام', icon: Send, color: 'bg-blue-50 text-blue-600 hover:bg-blue-100 border-blue-200/50' },
                        { id: 'whatsapp', name: 'واتس‌اپ', icon: MessageSquare, color: 'bg-emerald-50 text-emerald-600 hover:bg-emerald-100 border-emerald-200/50' },
                        { id: 'twitter', name: 'توئیتر / X', icon: Share2, color: 'bg-slate-50 text-slate-900 border-slate-200' },
                        { id: 'sms', name: 'پیامک', icon: Mail, color: 'bg-amber-50 text-amber-600 hover:bg-amber-105 border-amber-200/50' }
                      ].map((platform) => {
                        const IconComponent = platform.icon;
                        return (
                          <button
                            key={platform.id}
                            onClick={() => {
                              addLog('UI', `کلیک روی اشتراک‌گذاری در ${platform.name}`, `پلتفرم: ${platform.id} - کالا: ${selectedProduct.title}`);
                              setShareToast(`لینک کالا برای ارسال در ${platform.name} آماده شد`);
                              setIsShareOpen(false);
                              setTimeout(() => setShareToast(null), 3000);
                            }}
                            className={`flex flex-col items-center justify-center p-2.5 rounded-2xl border transition active:scale-95 ${platform.color}`}
                          >
                            <div className="w-7 h-7 rounded-full flex items-center justify-center mb-1.5 bg-white shadow-sm shrink-0">
                              <IconComponent className="w-3.5 h-3.5" />
                            </div>
                            <span className="text-[8px] font-black">{platform.name}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Floating Share Screen Notification Toast */}
            {shareToast && (
              <div className="absolute top-16 left-4 right-4 z-50 bg-slate-900/95 backdrop-blur-md text-white text-[9px] font-black px-4 py-3 rounded-2xl flex items-center gap-2 shadow-2xl animate-fade-in font-vazir" dir="rtl">
                <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></div>
                <span>{shareToast}</span>
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
}
